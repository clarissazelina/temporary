---
description: "TERUNGKAP! Inilah Resep Rahasia Lapis Selai Nenas Enak"
title: "TERUNGKAP! Inilah Resep Rahasia Lapis Selai Nenas Enak"
slug: 1597-masakan-sederhana-terungkap-inilah-resep-rahasia-lapis-selai-nenas-enak
date: 2020-08-22T02:00:58.014Z
image: https://img-global.cpcdn.com/recipes/d501e5e2dc09be25/751x532cq70/lapis-selai-nenas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/d501e5e2dc09be25/751x532cq70/lapis-selai-nenas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/d501e5e2dc09be25/751x532cq70/lapis-selai-nenas-foto-resep-utama.jpg
author: Troy Holt
ratingvalue: 4
reviewcount: 15
recipeingredient:
- "12 butir kuning telur"
- "2 butir putih telur"
- "250 gr butter me 200gr palmia royal  50gr Wijsman"
- "150 gr gula pasir"
- "100 gr terigu me segitiga ayak"
- "100 ml skm"
- "1 sachet susu bubuk me dancow"
- "250 gr selai nenas"
recipeinstructions:
- "Kocok butter hingga mengembang, sisihkan lalu cuci alat mixer lalu lap kering."
- "Di wadah lain, kocok telur dan gula pasir hingga pucat, kental dan mengembang."
- "Masukkan butter dengan bantuan spatula, aduk2 hingga rata."
- "Masukkan terigu, skm dan susu bubuk, lalu mixer dengan kecepatan paling rendah. Mixer adonan hingga tercampur rata."
- "Masukkan 3-4 sdm adonan ke dalam loyang ukuran 18x18 yg telah di beri kertas baking dan margarin, ratakan adonan lalu panggang hingga matang."
- "Setelah matang, keluarkan dan oles dengan selai nenas. Ngolesin selai nenasnya tipis2 aja ya guys biar nanti lapisnya ga lepas2 waktu di irisnya."
- "Setalah di oles selai langsung timpa dengan 3 sdm adonan, ratakan lalu panggang, lalukan hingga adonan habis."
categories:
- Resep
tags:
- lapis
- selai
- nenas

katakunci: lapis selai nenas 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT41M"
recipeyield: "4"
recipecategory: Dinner

---


![Lapis Selai Nenas](https://img-global.cpcdn.com/recipes/d501e5e2dc09be25/751x532cq70/lapis-selai-nenas-foto-resep-utama.jpg)

Lagi mencari ide resep lapis selai nenas yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal lapis selai nenas yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari lapis selai nenas, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan lapis selai nenas enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah lapis selai nenas yang siap dikreasikan. Anda bisa menyiapkan Lapis Selai Nenas memakai 8 bahan dan 7 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam mengolah Lapis Selai Nenas:

1. Siapkan 12 butir kuning telur
1. Sediakan 2 butir putih telur
1. Ambil 250 gr butter (me 200gr palmia royal + 50gr Wijsman)
1. Ambil 150 gr gula pasir
1. Ambil 100 gr terigu (me segitiga), ayak
1. Gunakan 100 ml skm
1. Sediakan 1 sachet susu bubuk (me dancow)
1. Siapkan 250 gr selai nenas




##### Langkah-langkah membuat Lapis Selai Nenas:

1. Kocok butter hingga mengembang, sisihkan lalu cuci alat mixer lalu lap kering.
1. Di wadah lain, kocok telur dan gula pasir hingga pucat, kental dan mengembang.
1. Masukkan butter dengan bantuan spatula, aduk2 hingga rata.
1. Masukkan terigu, skm dan susu bubuk, lalu mixer dengan kecepatan paling rendah. Mixer adonan hingga tercampur rata.
1. Masukkan 3-4 sdm adonan ke dalam loyang ukuran 18x18 yg telah di beri kertas baking dan margarin, ratakan adonan lalu panggang hingga matang.
1. Setelah matang, keluarkan dan oles dengan selai nenas. Ngolesin selai nenasnya tipis2 aja ya guys biar nanti lapisnya ga lepas2 waktu di irisnya.
1. Setalah di oles selai langsung timpa dengan 3 sdm adonan, ratakan lalu panggang, lalukan hingga adonan habis.




Gimana nih? Gampang kan? Itulah cara membuat lapis selai nenas yang bisa Anda praktikkan di rumah. Selamat mencoba!
