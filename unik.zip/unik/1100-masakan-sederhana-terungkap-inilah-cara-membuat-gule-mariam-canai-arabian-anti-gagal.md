---
description: "TERUNGKAP! Inilah Cara Membuat Gule Mariam/Canai Arabian Anti Gagal"
title: "TERUNGKAP! Inilah Cara Membuat Gule Mariam/Canai Arabian Anti Gagal"
slug: 1100-masakan-sederhana-terungkap-inilah-cara-membuat-gule-mariam-canai-arabian-anti-gagal
date: 2020-06-04T22:58:55.780Z
image: https://img-global.cpcdn.com/recipes/6210e285f65914ca/751x532cq70/gule-mariamcanai-arabian-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6210e285f65914ca/751x532cq70/gule-mariamcanai-arabian-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6210e285f65914ca/751x532cq70/gule-mariamcanai-arabian-foto-resep-utama.jpg
author: Della Clayton
ratingvalue: 3
reviewcount: 6
recipeingredient:
- " Roti canaimariam fozenfood"
- "1/4 kg Daging sapi tetelan lulur dalam"
- "8 biji Bawang merah"
- "4-5 biji Bawang putih"
- "1 ruas jari Kunyit"
- "3 cm Jahe"
- "1 tangkai Daun kare"
- "secukupnya Daun jeruk"
- "5 Cabe merah besar"
- "secukupnya Gula"
- "secukupnya Totole"
- "secukupnya Garem"
- "1 buah Tomat segar"
- "2 ruas jari Keningar"
- " Bumbu angge2ketumbar jintan pala disangrai dan dihaluskan"
- " Santan kelapa perut secukupnya  setara santan 1 syaset sasa"
- " topping"
- " Bawang goreng"
- " Bawang pre iris kasar"
- "3 biji kapulaga dibela jadi 2keluarkan isinya"
- " Bahan Tambahan lain"
- " Kacang hijau 12 ons direbus kemudian masuk bareng santan"
recipeinstructions:
- "Cuci bersih daging sapi"
- "Siapkan bumbu halus terdiri dari (bawang putih, jahe, kunyit, lombok merah)kemudian bawang merah dicincang kasar lalu di tumis bareng keningar setelah harum masukkan bumbu halus yang sudah di uleg/blender tadi"
- "Setelah harum bumbu yang sudah ditumis tadi, masukkan irisan daging kedalam bumbu aduk rata tutup. Setelah keluar air agak layu tambhakan air sedikit lalu jika daging dirasa sudah empuk masukkan bumbu angge2 dan irisan tomat, daun kare, daun jeruk"
- "Siapkan santan kelapa peras"
- "Campurkan perasan santan dengan daging yg sudah dimasak dengan bumbu diawal proses sebelumnya. Kebetulan disini kami tidak menggunakan campuran kacang hijau karena request ada yg gak suka kacang hijau, jika mau bisa dicampurkan saat proses pencampuran dengan santan seperti ini"
- "Masak dengan api sedang dan beri bumbu pelengkap seperti totole, gula sedikit, garam dan taburi irisan bawang pre, bawang goreng serta isian dari kapulaga yg sudah dibela jadi dua bagian"
- "Goreng mariam tanpa minyak tp dengan sedikit margarin"
- "Tuangkan daging dan kua gule ke atas mariam/canai yg sudah digoreng"
categories:
- Resep
tags:
- gule
- mariamcanai
- arabian

katakunci: gule mariamcanai arabian 
nutrition: 184 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT55M"
recipeyield: "1"
recipecategory: Lunch

---


![Gule Mariam/Canai Arabian](https://img-global.cpcdn.com/recipes/6210e285f65914ca/751x532cq70/gule-mariamcanai-arabian-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gule mariam/canai arabian yang unik? Cara membuatnya memang susah-susah gampang. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gule mariam/canai arabian yang enak selayaknya punya aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gule mariam/canai arabian, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan gule mariam/canai arabian yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah gule mariam/canai arabian yang siap dikreasikan. Anda bisa membuat Gule Mariam/Canai Arabian menggunakan 22 jenis bahan dan 8 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Gule Mariam/Canai Arabian:

1. Siapkan  Roti canai/mariam fozenfood
1. Gunakan 1/4 kg Daging sapi (tetelan /lulur dalam)
1. Siapkan 8 biji Bawang merah
1. Siapkan 4-5 biji Bawang putih
1. Gunakan 1 ruas jari Kunyit
1. Sediakan 3 cm Jahe
1. Gunakan 1 tangkai Daun kare
1. Gunakan secukupnya Daun jeruk
1. Gunakan 5 Cabe merah besar
1. Ambil secukupnya Gula
1. Gunakan secukupnya Totole
1. Sediakan secukupnya Garem
1. Siapkan 1 buah Tomat segar
1. Sediakan 2 ruas jari Keningar
1. Ambil  Bumbu angge2(ketumbar, jintan, pala disangrai dan dihaluskan)
1. Siapkan  Santan kelapa perut secukupnya / setara santan 1 syaset sasa
1. Ambil  topping
1. Sediakan  Bawang goreng
1. Gunakan  Bawang pre iris kasar
1. Ambil 3 biji kapulaga (dibela jadi 2,keluarkan isinya)
1. Gunakan  Bahan Tambahan lain
1. Siapkan  Kacang hijau 1/2 ons (direbus kemudian masuk bareng santan)




##### Langkah-langkah menyiapkan Gule Mariam/Canai Arabian:

1. Cuci bersih daging sapi
1. Siapkan bumbu halus terdiri dari (bawang putih, jahe, kunyit, lombok merah)kemudian bawang merah dicincang kasar lalu di tumis bareng keningar setelah harum masukkan bumbu halus yang sudah di uleg/blender tadi
1. Setelah harum bumbu yang sudah ditumis tadi, masukkan irisan daging kedalam bumbu aduk rata tutup. Setelah keluar air agak layu tambhakan air sedikit lalu jika daging dirasa sudah empuk masukkan bumbu angge2 dan irisan tomat, daun kare, daun jeruk
1. Siapkan santan kelapa peras
1. Campurkan perasan santan dengan daging yg sudah dimasak dengan bumbu diawal proses sebelumnya. Kebetulan disini kami tidak menggunakan campuran kacang hijau karena request ada yg gak suka kacang hijau, jika mau bisa dicampurkan saat proses pencampuran dengan santan seperti ini
1. Masak dengan api sedang dan beri bumbu pelengkap seperti totole, gula sedikit, garam dan taburi irisan bawang pre, bawang goreng serta isian dari kapulaga yg sudah dibela jadi dua bagian
1. Goreng mariam tanpa minyak tp dengan sedikit margarin
1. Tuangkan daging dan kua gule ke atas mariam/canai yg sudah digoreng




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Gule Mariam/Canai Arabian yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berjualan makanan. Selamat mencoba!
