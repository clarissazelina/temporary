---
description: "TERUNGKAP! Ternyata Ini Cara Membuat Cucur Bunga Telang "
title: "TERUNGKAP! Ternyata Ini Cara Membuat Cucur Bunga Telang "
slug: 1836-masakan-sederhana-terungkap-ternyata-ini-cara-membuat-cucur-bunga-telang
date: 2020-06-01T11:45:09.862Z
image: https://img-global.cpcdn.com/recipes/12fdd6447180bc93/751x532cq70/cucur-bunga-telang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/12fdd6447180bc93/751x532cq70/cucur-bunga-telang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/12fdd6447180bc93/751x532cq70/cucur-bunga-telang-foto-resep-utama.jpg
author: Cynthia Jackson
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "125 gr tepung beras"
- "100 gr terigu"
- "180 gr gulpas"
- "200 ml air kelapa"
- "1/4 sdt garam"
- "2 lembar daun pandan"
- "5 gr bunga telang"
recipeinstructions:
- "Masukan gula + garam + bunga telang + air kelapa + pandan.. Masak pakai api kecil hingga mendidih. Matikan biarkan suam kuku (maaf fotonya tadi udah bekas sya tuang jadi tinggal sisa sndikit airnya) nyaris lupa foto😁"
- "Campur terigu + tepung beras aduk rata.. Tuangi bahan cair.. Sambil di saring aduk pakai whisk hingga rata.. Tuang bertahap.. Aduk terus sampai licin.. (boleh di mixer speed rendah 5 menit) Lalu keplok\"pakai whisk / centong hingga keluar gelembung\" kecil.. Diamkan minimal 1 jam. Saya bikin jam 11 goreng jam 2.."
- "Goreng di wajan cekung (saya g punya wajan yang cekung banget).. Tuangu minyak panaskan pakai api kecil hingga panas. Goreng 1 centong biatkan hingga sertnya naik.. Balik sebentar.. Siap"
- "Notes : Goreng menggunakan api kecil minyak panas.. Tunggu hingga beserat lalu siram\"kan minyak panas ke bagian tengahnya.. Angkat tiriskan"
- "Siap hidangkan.. Seratnya cantik dan empuk. Bagian bawahnya melengkung ya.. Cm saya pakai wajan agak datar dan guede jadi cucurbya kurang cekung. Tpi keseluruhan enak bgt kok"
categories:
- Resep
tags:
- cucur
- bunga
- telang

katakunci: cucur bunga telang 
nutrition: 150 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Lunch

---


![Cucur Bunga Telang](https://img-global.cpcdn.com/recipes/12fdd6447180bc93/751x532cq70/cucur-bunga-telang-foto-resep-utama.jpg)

Sedang mencari inspirasi resep cucur bunga telang yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal cucur bunga telang yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cucur bunga telang, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan cucur bunga telang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat cucur bunga telang yang siap dikreasikan. Anda dapat menyiapkan Cucur Bunga Telang memakai 7 bahan dan 5 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Cucur Bunga Telang:

1. Gunakan 125 gr tepung beras
1. Gunakan 100 gr terigu
1. Siapkan 180 gr gulpas
1. Siapkan 200 ml air kelapa
1. Sediakan 1/4 sdt garam
1. Siapkan 2 lembar daun pandan
1. Siapkan 5 gr bunga telang




##### Cara menyiapkan Cucur Bunga Telang:

1. Masukan gula + garam + bunga telang + air kelapa + pandan.. Masak pakai api kecil hingga mendidih. Matikan biarkan suam kuku (maaf fotonya tadi udah bekas sya tuang jadi tinggal sisa sndikit airnya) nyaris lupa foto😁
1. Campur terigu + tepung beras aduk rata.. Tuangi bahan cair.. Sambil di saring aduk pakai whisk hingga rata.. Tuang bertahap.. Aduk terus sampai licin.. (boleh di mixer speed rendah 5 menit) Lalu keplok\"pakai whisk / centong hingga keluar gelembung\" kecil.. Diamkan minimal 1 jam. Saya bikin jam 11 goreng jam 2..
1. Goreng di wajan cekung (saya g punya wajan yang cekung banget).. Tuangu minyak panaskan pakai api kecil hingga panas. Goreng 1 centong biatkan hingga sertnya naik.. Balik sebentar.. Siap
1. Notes : - Goreng menggunakan api kecil minyak panas.. Tunggu hingga beserat lalu siram\"kan minyak panas ke bagian tengahnya.. Angkat tiriskan
1. Siap hidangkan.. Seratnya cantik dan empuk. Bagian bawahnya melengkung ya.. Cm saya pakai wajan agak datar dan guede jadi cucurbya kurang cekung. Tpi keseluruhan enak bgt kok




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Cucur Bunga Telang yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
