---
description: "BIKIN NGILER! Begini Resep Rahasia Kremes Kriuk Pasti Berhasil"
title: "BIKIN NGILER! Begini Resep Rahasia Kremes Kriuk Pasti Berhasil"
slug: 1413-masakan-sederhana-bikin-ngiler-begini-resep-rahasia-kremes-kriuk-pasti-berhasil
date: 2020-04-10T06:04:07.038Z
image: https://img-global.cpcdn.com/recipes/7528e4a46e88023a/751x532cq70/kremes-kriuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7528e4a46e88023a/751x532cq70/kremes-kriuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7528e4a46e88023a/751x532cq70/kremes-kriuk-foto-resep-utama.jpg
author: Landon Pittman
ratingvalue: 4.5
reviewcount: 3
recipeingredient:
- "2 siung bawang putih haluskan"
- "1 sdm ketumbar bubuk"
- "1 1/2 sdt garam"
- "1 sdt kaldu jamur"
- "20 sdm tepung tapioka"
- "1 sdt baking powder"
- "2 sdm tepung beras"
- "1 butir kuning telur"
- "secukupnya Air"
- " Minyak goreng untuk menggoreng"
recipeinstructions:
- "Campur tepung tapioka, tepung beras, baking powder, bumbu, dan air. Aduk hingga rata. Adonan dibuat encer jadi air banyak gapapa. Kalo kurang asin bisa tambah garam."
- "Kemudian masukkan kuning telur ke adonan tadi. Aduk lagi hingga rata. Panaskan minyak goreng. Minyak juga agak banyak soalnya kremes ini nyerap minyak. Dan hasil bagus kalo minyak emang banyak."
- "Tuang adonan sedikit demi sedikit dengan diciprat-cipratkan ke wajan agar kremes tidak menggumpal dan hasilnya seperti bersarang. Goreng hingga kering dan warna kuning keemasan. Angkat lalu tiriskan. Taruh diatas nampan yang sudah dilapisi dengan tisu. Agar minyak terserap. Ulangi hal yg sama hingga adonan habis. Jika kremes sudah tidak panas bisa disimpan dalam toples."
categories:
- Resep
tags:
- kremes
- kriuk

katakunci: kremes kriuk 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT20M"
cooktime: "PT33M"
recipeyield: "1"
recipecategory: Dessert

---


![Kremes Kriuk](https://img-global.cpcdn.com/recipes/7528e4a46e88023a/751x532cq70/kremes-kriuk-foto-resep-utama.jpg)

Sedang mencari ide resep kremes kriuk yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal kremes kriuk yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari kremes kriuk, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika hendak menyiapkan kremes kriuk enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah kremes kriuk yang siap dikreasikan. Anda dapat membuat Kremes Kriuk menggunakan 10 jenis bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Kremes Kriuk:

1. Siapkan 2 siung bawang putih haluskan
1. Siapkan 1 sdm ketumbar bubuk
1. Gunakan 1 1/2 sdt garam
1. Sediakan 1 sdt kaldu jamur
1. Gunakan 20 sdm tepung tapioka
1. Sediakan 1 sdt baking powder
1. Gunakan 2 sdm tepung beras
1. Sediakan 1 butir kuning telur
1. Ambil secukupnya Air
1. Gunakan  Minyak goreng untuk menggoreng




##### Langkah-langkah membuat Kremes Kriuk:

1. Campur tepung tapioka, tepung beras, baking powder, bumbu, dan air. Aduk hingga rata. Adonan dibuat encer jadi air banyak gapapa. Kalo kurang asin bisa tambah garam.
1. Kemudian masukkan kuning telur ke adonan tadi. Aduk lagi hingga rata. Panaskan minyak goreng. Minyak juga agak banyak soalnya kremes ini nyerap minyak. Dan hasil bagus kalo minyak emang banyak.
1. Tuang adonan sedikit demi sedikit dengan diciprat-cipratkan ke wajan agar kremes tidak menggumpal dan hasilnya seperti bersarang. Goreng hingga kering dan warna kuning keemasan. Angkat lalu tiriskan. Taruh diatas nampan yang sudah dilapisi dengan tisu. Agar minyak terserap. Ulangi hal yg sama hingga adonan habis. Jika kremes sudah tidak panas bisa disimpan dalam toples.




Bagaimana? Mudah bukan? Itulah cara menyiapkan kremes kriuk yang bisa Anda lakukan di rumah. Selamat mencoba!
