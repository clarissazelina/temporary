---
description: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Selai nenas Enak"
title: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Selai nenas Enak"
slug: 1592-masakan-sederhana-wajib-dicoba-ternyata-ini-resep-rahasia-selai-nenas-enak
date: 2020-08-09T23:14:36.900Z
image: https://img-global.cpcdn.com/recipes/65b6699c3f09165f/751x532cq70/selai-nenas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/65b6699c3f09165f/751x532cq70/selai-nenas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/65b6699c3f09165f/751x532cq70/selai-nenas-foto-resep-utama.jpg
author: Linnie Bowers
ratingvalue: 5
reviewcount: 10
recipeingredient:
- "1 bh Nenas"
- "4 sm Gula pasir"
- "sedikit Garam"
recipeinstructions:
- "Bersihkan nenas,kemudian parut"
- "Masukkan nenas,gula,garam ke dalam wajan teplon"
- "Masak hingga airnya menyusut,angkat dan siap buat pelengkap roti tawar ataupun bolu gulung"
categories:
- Resep
tags:
- selai
- nenas

katakunci: selai nenas 
nutrition: 282 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT33M"
recipeyield: "4"
recipecategory: Dessert

---


![Selai nenas](https://img-global.cpcdn.com/recipes/65b6699c3f09165f/751x532cq70/selai-nenas-foto-resep-utama.jpg)

Anda sedang mencari ide resep selai nenas yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal selai nenas yang enak harusnya sih memiliki aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan selai nenas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.

Jika suka selai bertekstur, anda bisa mencincang buah nanas jadi kasar. Sebaliknya jika suka selai lembut, anda tinggal memblendernya hingga halus. Selain selai cokelat, selai nanas juga sering digunakan untuk isian roti dan kue lho.


Nah, kali ini kita coba, yuk, variasikan selai nenas sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Selai nenas memakai 3 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Selai nenas:

1. Gunakan 1 bh Nenas
1. Gunakan 4 sm Gula pasir
1. Gunakan sedikit Garam


Buah nenas [Ananas comosus (L) Merr] selain dikonsumsi segar juga dapat diolah menjadi berbagai produk makanan dan minuman, seperti dibuat jam (selai), sari buah, dodol, manisan. Selai nanas memang paling nikmat dijadikan topping roti atau isian kue. Nastar adalah salah satu kue yang selalu menggunakan selai nanas sebagai isiannya. Kali ini Cosmos mau share resep Selai Nanas Homemade yang nikmat banget buat disantap jadi olesan roti ataupun buat isian nastar. 

##### Langkah-langkah meracik Selai nenas:

1. Bersihkan nenas,kemudian parut
1. Masukkan nenas,gula,garam ke dalam wajan teplon
1. Masak hingga airnya menyusut,angkat dan siap buat pelengkap roti tawar ataupun bolu gulung


Pastinya bikin selai sendiri akan lebih. Nastar isian selai nanas ini mudah dibuat, lho. Bagi yang tidak memiliki oven bisa juga membuat nastar dengan menggunakan wajan anti lengket. Selai seperti selai nanas pada dasarnya cukup mudah untuk dibuat. Namun bagi sebagian orang yang tidak memiliki banyak waktu, membuat selai nanas sendiri di rumah bisa. 

Gimana nih? Mudah bukan? Itulah cara membuat selai nenas yang bisa Anda lakukan di rumah. Selamat mencoba!
