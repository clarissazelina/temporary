---
description: "BIKIN NGILER! Begini Resep Rahasia Lamang Srikaya Enak"
title: "BIKIN NGILER! Begini Resep Rahasia Lamang Srikaya Enak"
slug: 1271-masakan-sederhana-bikin-ngiler-begini-resep-rahasia-lamang-srikaya-enak
date: 2020-04-25T22:16:10.487Z
image: https://img-global.cpcdn.com/recipes/90ef750258176582/751x532cq70/lamang-srikaya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/90ef750258176582/751x532cq70/lamang-srikaya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/90ef750258176582/751x532cq70/lamang-srikaya-foto-resep-utama.jpg
author: Minnie Bowen
ratingvalue: 3.4
reviewcount: 10
recipeingredient:
- " Bahan lamang"
- "1 liter Ketan putih"
- "1/2 kg Santan"
- " Daun pisang"
- "Batang lidi"
- " Bahan srikaya"
- "4 butir Telur"
- " Gula aren 2  atau sesuai selera"
- "4 helai Daun pandan"
- "1/2 sdt Garam"
- " Santan 150gr  setengah bungkus seperapatan"
recipeinstructions:
- "Cuci ketan putih lalu aron dengan santan"
- "Panaskan dandang, lalu taruh daun pisang agar lemas (untuk mudah saat menggulung lamang)"
- "Setelah aronan ketan tercampur rata, angkat lalu masukkan ke daun pisang yg sudah di lemaskan. Bentuk seperti lontong. Lakukan smpai bahan habis"
- "Panaskan dandang hingga mendidih lalu kukus lamangnya ±1 jam atau liat sampai daun berubah warna"
- "Sambil menunggu lamang, siapkan adonan srikaya"
- "Masukkan telur, gula aren yg sudah di iris2 halus, daun pandan ke dalam satu wadah"
- "Remat2 dengan tangan sampai tercampur rata lalu masukkan santan dan ½sdt garam, aduk hingga rata"
- "Siapkan daun pisang bentuk seperti mangkuk until wadah mengukus srikaya"
- "Masukkan adonan ke wadah lalu kukus sampai matang ±25 menit atau cek2 sampai adonan mengeras"
- "Setelah srikaya matang, dan lanang matang sajikan di piring, lamang srikaya siap dihidangkan"
categories:
- Resep
tags:
- lamang
- srikaya

katakunci: lamang srikaya 
nutrition: 146 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Dinner

---


![Lamang Srikaya](https://img-global.cpcdn.com/recipes/90ef750258176582/751x532cq70/lamang-srikaya-foto-resep-utama.jpg)

Sedang mencari ide resep lamang srikaya yang unik? Cara menyiapkannya memang susah-susah gampang. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal lamang srikaya yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari lamang srikaya, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan lamang srikaya yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, buat lamang srikaya sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Lamang Srikaya menggunakan 11 bahan dan 10 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Lamang Srikaya:

1. Siapkan  Bahan lamang
1. Gunakan 1 liter Ketan putih
1. Ambil 1/2 kg Santan
1. Sediakan  Daun pisang
1. Siapkan Batang lidi
1. Ambil  Bahan srikaya
1. Gunakan 4 butir Telur
1. Siapkan  Gula aren 2 ½ (atau sesuai selera)
1. Sediakan 4 helai Daun pandan
1. Gunakan 1/2 sdt Garam
1. Ambil  Santan 150gr / setengah bungkus seperapatan




##### Cara menyiapkan Lamang Srikaya:

1. Cuci ketan putih lalu aron dengan santan
1. Panaskan dandang, lalu taruh daun pisang agar lemas (untuk mudah saat menggulung lamang)
1. Setelah aronan ketan tercampur rata, angkat lalu masukkan ke daun pisang yg sudah di lemaskan. Bentuk seperti lontong. Lakukan smpai bahan habis
1. Panaskan dandang hingga mendidih lalu kukus lamangnya ±1 jam atau liat sampai daun berubah warna
1. Sambil menunggu lamang, siapkan adonan srikaya
1. Masukkan telur, gula aren yg sudah di iris2 halus, daun pandan ke dalam satu wadah
1. Remat2 dengan tangan sampai tercampur rata lalu masukkan santan dan ½sdt garam, aduk hingga rata
1. Siapkan daun pisang bentuk seperti mangkuk until wadah mengukus srikaya
1. Masukkan adonan ke wadah lalu kukus sampai matang ±25 menit atau cek2 sampai adonan mengeras
1. Setelah srikaya matang, dan lanang matang sajikan di piring, lamang srikaya siap dihidangkan




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Lamang Srikaya yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
