---
description: "WAJIB DICOBA! Begini Cara Membuat Nagasari atau sumpil Spesial"
title: "WAJIB DICOBA! Begini Cara Membuat Nagasari atau sumpil Spesial"
slug: 1078-masakan-sederhana-wajib-dicoba-begini-cara-membuat-nagasari-atau-sumpil-spesial
date: 2020-05-24T02:00:26.762Z
image: https://img-global.cpcdn.com/recipes/2ffc6602dee019e9/751x532cq70/nagasari-atau-sumpil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ffc6602dee019e9/751x532cq70/nagasari-atau-sumpil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ffc6602dee019e9/751x532cq70/nagasari-atau-sumpil-foto-resep-utama.jpg
author: Winifred Weber
ratingvalue: 4.6
reviewcount: 10
recipeingredient:
- " Bahan "
- "500 gr tepung beras"
- "secukupnya Garam"
- "12 sendok Gula"
- "1 liter Santan kelapa atau setengah kelapa diblender"
- " Daun pisang"
- " Pisang Makassar"
recipeinstructions:
- "Siapkan kelapa setengah lingkaran. Potong dadu kecil siapkan air blender sampai kelapa tidak mengeluarkan santan lagi kira2 3/4 kali"
- "Siapkan santan kelapa, masukkan gula dan garam dan tepung beras dalam panci,aduk sampai mendidih,kemudian dimasak di api kecil.aduk terus biar tidak ada kerak di dasar panci. Setelah masak,kalis dan tidak lengket di centong,matikan kompor."
- "Potong pisang jadi dua bagian. Lalu siapkan plastik bening tuk membuat lapisan sumpil."
- "Ambil sedikit adonan sumpil taruh diatas plastik. Lalu tekan menjadi lapisan tipis masukan pisang lalu tutup dengan adonan. Lalu taruh diatas daun pisang gulung dengan daun sampai tertutup rata dan lipat pada dua sisinya"
- "Kukus pisang sampai daun pisang berubah warna hijau tua kira2 20 menitan dan siap disajikan. Taruh diatas nampan jangan ditumpuk agar tidak cepat bau. Selamat menikmati dan mencoba 🌼 #5resepterbaruku"
- "."
categories:
- Resep
tags:
- nagasari
- atau
- sumpil

katakunci: nagasari atau sumpil 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Lunch

---


![Nagasari atau sumpil](https://img-global.cpcdn.com/recipes/2ffc6602dee019e9/751x532cq70/nagasari-atau-sumpil-foto-resep-utama.jpg)

Lagi mencari ide resep nagasari atau sumpil yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal nagasari atau sumpil yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari nagasari atau sumpil, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan nagasari atau sumpil yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.

Sumpil adalah lipatan daun berbentuk segitiga. Berbeda dengan pincuk, sumpil merupakan lipatan yang rapat. Cara buatnya, pakai daun panjang atau persegi panjang.


Nah, kali ini kita coba, yuk, variasikan nagasari atau sumpil sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat membuat Nagasari atau sumpil memakai 7 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk meracik Nagasari atau sumpil:

1. Siapkan  Bahan :
1. Sediakan 500 gr tepung beras
1. Sediakan secukupnya Garam
1. Gunakan 12 sendok Gula
1. Gunakan 1 liter Santan kelapa atau setengah kelapa diblender
1. Ambil  Daun pisang
1. Sediakan  Pisang Makassar


Yuk tunggu apalagi, langsung buat kreasi nagasari berbagai bahan seperti deretan resep yang sudah brilio.net rangkum dari berbagai sumber, Selasa. SUMPIL : pembungkus lopis, nagasari, bacang, berbentuk segitiga & disemat dengan lidi. TAKIR : wadah / tempat berbagai macam lauk nasi tumpeng. SAMIR : sebagai alas sajian makanan di atas. 

##### Langkah-langkah meracik Nagasari atau sumpil:

1. Siapkan kelapa setengah lingkaran. Potong dadu kecil siapkan air blender sampai kelapa tidak mengeluarkan santan lagi kira2 3/4 kali
1. Siapkan santan kelapa, masukkan gula dan garam dan tepung beras dalam panci,aduk sampai mendidih,kemudian dimasak di api kecil.aduk terus biar tidak ada kerak di dasar panci. Setelah masak,kalis dan tidak lengket di centong,matikan kompor.
1. Potong pisang jadi dua bagian. Lalu siapkan plastik bening tuk membuat lapisan sumpil.
1. Ambil sedikit adonan sumpil taruh diatas plastik. Lalu tekan menjadi lapisan tipis masukan pisang lalu tutup dengan adonan. Lalu taruh diatas daun pisang gulung dengan daun sampai tertutup rata dan lipat pada dua sisinya
1. Kukus pisang sampai daun pisang berubah warna hijau tua kira2 20 menitan dan siap disajikan. Taruh diatas nampan jangan ditumpuk agar tidak cepat bau. Selamat menikmati dan mencoba 🌼 #5resepterbaruku
1. .


Nagasari adalah kue basah tradisional Indonesia yang cukup mudah dibuat di rumah. Faktanya tidak semua kue tradisional sulit pembuatannya loh. Lihat juga resep Nagasari pisang enak lainnya. SUMPIL Biasanya digunakan utk membungkus tempe, kue lupis atau penganan sejenis nagasari. Tanaman nagasari adalah nama tumbuhan yang baru pertama kali kami dengar ceriteranya dari nenek, saat ia menceriterakan tentang R. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Nagasari atau sumpil yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Selamat mencoba!
