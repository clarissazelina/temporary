---
description: "WAJIB DICOBA! Inilah Resep Padamaran, jajanan pasar khas Jambi Pasti Berhasil"
title: "WAJIB DICOBA! Inilah Resep Padamaran, jajanan pasar khas Jambi Pasti Berhasil"
slug: 1631-masakan-sederhana-wajib-dicoba-inilah-resep-padamaran-jajanan-pasar-khas-jambi-pasti-berhasil
date: 2020-09-22T22:17:27.600Z
image: https://img-global.cpcdn.com/recipes/ea8387e7b7a6272e/751x532cq70/padamaran-jajanan-pasar-khas-jambi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ea8387e7b7a6272e/751x532cq70/padamaran-jajanan-pasar-khas-jambi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ea8387e7b7a6272e/751x532cq70/padamaran-jajanan-pasar-khas-jambi-foto-resep-utama.jpg
author: Sadie McDonald
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- " Bahan A"
- "800 gr santan 400 ml santan kental  400 ml santan cair"
- "160 gr tepung beras"
- "40 gr tepung terigu"
- "1/2 sdt garam"
- "100 ml air  9 lembar pandan di blender"
- " Bahan B"
- "secukupnya Gula pasir"
- "250-300 gr Gula merah"
recipeinstructions:
- "Siapkan daun pisang yg telah dilayukan menggunakan kompor/api.cetak membentuk persegi. Gunakan steples atau lidi untuk membuat kotak"
- "Siapkan jus pandan, blender daun pandan. Lai saring, sisihkan"
- "Masukan santan, tepung, dan garam, dan jus pandan. Aduk menggunakan balon wisk hingga rata, saring adonan agar tidak ada tepung yg menggumpal."
- "Iris cacah halus gula merah, tambahkan sejumput gula pasir."
- "Tuang adonan ke kecetakan yang telah di beri gula merah. Lalu kukus +- 25 menit"
- "Biarkan disuhu ruang, lalu sajikan"
categories:
- Resep
tags:
- padamaran
- jajanan
- pasar

katakunci: padamaran jajanan pasar 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT44M"
recipeyield: "4"
recipecategory: Lunch

---


![Padamaran, jajanan pasar khas Jambi](https://img-global.cpcdn.com/recipes/ea8387e7b7a6272e/751x532cq70/padamaran-jajanan-pasar-khas-jambi-foto-resep-utama.jpg)

Lagi mencari inspirasi resep padamaran, jajanan pasar khas jambi yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal padamaran, jajanan pasar khas jambi yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Kue yg susah susah gampang dicari. Kl Saya ingin membuatkan cemilan yang sudah dirindukannya setelah sekian bulan purnama, KOPYOR ROTI makanan khas banyuwangi yang adanya di Bulan Ramadhan. Makanan khas Jambi tempoyak merupakan sajian kuliner yang terkenal di seantero Jambi.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari padamaran, jajanan pasar khas jambi, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan padamaran, jajanan pasar khas jambi enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan padamaran, jajanan pasar khas jambi sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Padamaran, jajanan pasar khas Jambi memakai 9 jenis bahan dan 6 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Padamaran, jajanan pasar khas Jambi:

1. Gunakan  Bahan A
1. Gunakan 800 gr santan (400 ml santan kental + 400 ml santan cair)
1. Sediakan 160 gr tepung beras
1. Siapkan 40 gr tepung terigu
1. Ambil 1/2 sdt garam
1. Gunakan 100 ml air + 9 lembar pandan di blender
1. Siapkan  Bahan B
1. Ambil secukupnya Gula pasir
1. Ambil 250-300 gr Gula merah


Padamaran adalah kue tradisional Jambi yang terbuat dari campuran tepung beras dan santan yang dikemas di dalam takir Kue gandus merupakan salah satu jajanan pasar yang dimiliki oleh jambi. Resep jajanan pasar yang pertama adalah Klepon ubi ungu. Kue ini termasuk pada aneka kue tradisional yang khas. Dimana pada umumnya kue ini dibuat menggunakan tepung ketan yang diberikan pewarna alami atau pewarna makanan dan juga terdapat isi gula merah di dalamnya. 

##### Cara menyiapkan Padamaran, jajanan pasar khas Jambi:

1. Siapkan daun pisang yg telah dilayukan menggunakan kompor/api.cetak membentuk persegi. Gunakan steples atau lidi untuk membuat kotak
1. Siapkan jus pandan, blender daun pandan. Lai saring, sisihkan
1. Masukan santan, tepung, dan garam, dan jus pandan. Aduk menggunakan balon wisk hingga rata, saring adonan agar tidak ada tepung yg menggumpal.
1. Iris cacah halus gula merah, tambahkan sejumput gula pasir.
1. Tuang adonan ke kecetakan yang telah di beri gula merah. Lalu kukus +- 25 menit
1. Biarkan disuhu ruang, lalu sajikan


Jajanan pasar merupakan penganan yang bisa dibeli dari pasar tradisional. Jenisnya pun beragam, mulai dari yang rasanya manis hingga gurih. Tapi jajanan pasar tradisional ini masih tetap eksis kok, meskipun zaman telah berubah. Berikut ini Seruni akan membagikan artikel jajanan tradisional. Resep Anti Gagal - Padamaran merupakan kue tradisional yang digemari karena rasanya yang manis dan tekstur nya yang lembur. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Padamaran, jajanan pasar khas Jambi yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
