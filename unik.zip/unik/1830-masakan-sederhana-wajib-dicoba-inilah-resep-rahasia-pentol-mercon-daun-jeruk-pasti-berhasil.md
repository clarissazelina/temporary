---
description: "WAJIB DICOBA! Inilah Resep Rahasia Pentol mercon daun jeruk Pasti Berhasil"
title: "WAJIB DICOBA! Inilah Resep Rahasia Pentol mercon daun jeruk Pasti Berhasil"
slug: 1830-masakan-sederhana-wajib-dicoba-inilah-resep-rahasia-pentol-mercon-daun-jeruk-pasti-berhasil
date: 2020-06-18T13:41:54.542Z
image: https://img-global.cpcdn.com/recipes/83a31ea006cba602/751x532cq70/pentol-mercon-daun-jeruk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/83a31ea006cba602/751x532cq70/pentol-mercon-daun-jeruk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/83a31ea006cba602/751x532cq70/pentol-mercon-daun-jeruk-foto-resep-utama.jpg
author: Johanna Stanley
ratingvalue: 4.6
reviewcount: 7
recipeingredient:
- "50 butir bakso"
- "40 buah cabe rawit merah"
- "20 buah cabe merah keriting"
- "10 butir bawang putih"
- "5 siung bawang merah"
- "3 buah kemiri"
- "10 lembar daun jeruk remes2"
- " Minyak goreng"
- "1 sdm gula pasir"
- "1 sdt garam"
- "secukupnya Penyedap rasa"
recipeinstructions:
- "Rebus bakso sampai mengambang/ matang, sisihkan"
- "Tumis dengan sedikit minyak semua bumbunya kecuali daun jeruk hingga layu, lalu blender kasar2 aja, mau diulek juga boleh"
- "Tumis bumbu yg sudah diblender dengan minyak panas, masukan daun jeruk, tambahkan garam dan penyedap rasa, tumis sampai harum"
- "Masukkan bakso dan tumis lagi sampai bakso tercampur bumbu, tambahkan gula pasir, aduk rata, angkat, sajikan"
categories:
- Resep
tags:
- pentol
- mercon
- daun

katakunci: pentol mercon daun 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Pentol mercon daun jeruk](https://img-global.cpcdn.com/recipes/83a31ea006cba602/751x532cq70/pentol-mercon-daun-jeruk-foto-resep-utama.jpg)

Sedang mencari inspirasi resep pentol mercon daun jeruk yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal pentol mercon daun jeruk yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Haii hari ini aku masak pentol bakso mercon Aduuuh ini pedeeessss banget banget banget !! Cara membuat pentol mercon: Tumis bumbu ulek bersama jahe, lengkuas, daun jeruk dan daun salam hingga harum dan matang. Pentol sendiri merupakan salah satu kuliner yang disukai oleh banyak orang, sebelum memulai tentukan target pasar sesuai kemampuan ataupun lokasi anda di.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari pentol mercon daun jeruk, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan pentol mercon daun jeruk enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah pentol mercon daun jeruk yang siap dikreasikan. Anda bisa menyiapkan Pentol mercon daun jeruk menggunakan 11 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk meracik Pentol mercon daun jeruk:

1. Sediakan 50 butir bakso
1. Ambil 40 buah cabe rawit merah
1. Ambil 20 buah cabe merah keriting
1. Sediakan 10 butir bawang putih
1. Siapkan 5 siung bawang merah
1. Gunakan 3 buah kemiri
1. Siapkan 10 lembar daun jeruk, remes2
1. Siapkan  Minyak goreng
1. Sediakan 1 sdm gula pasir
1. Ambil 1 sdt garam
1. Gunakan secukupnya Penyedap rasa


Namun, tak semua penjual membuatnya dengan bahan-bahan yang higienis dan benar. Daun jeruk nipis dikenal sebagai daun yang bisa mengeluarkan aroma yang sangat kuat. Ternyata dalam setiap helai darin jeruk nipis mengandung ekstrak aroma yang terdiri dari berbagai jenis minyak esensial. Beberapa jenis aroma yang khas itu antara lain adalah seperti aroma citrus dan sitronelal. 

##### Cara membuat Pentol mercon daun jeruk:

1. Rebus bakso sampai mengambang/ matang, sisihkan
1. Tumis dengan sedikit minyak semua bumbunya kecuali daun jeruk hingga layu, lalu blender kasar2 aja, mau diulek juga boleh
1. Tumis bumbu yg sudah diblender dengan minyak panas, masukan daun jeruk, tambahkan garam dan penyedap rasa, tumis sampai harum
1. Masukkan bakso dan tumis lagi sampai bakso tercampur bumbu, tambahkan gula pasir, aduk rata, angkat, sajikan


Tahukah Anda bedanya bakso dan pentol? Perbedaannya pada bakso hanya sedikit menggunakan tepung tapioka sedangkan pada pentol ditambahkan tepung tapioka yang lebih banyak. Lalu, tambahkan daun salam, lengkuas, jahe, dan daun jeruk. Setelah itu, masukan air, masak sampai mendidih. Nah, salah satu jajanan pinggir jalan yang lagi kekinian adalah bakso pentol. 

Bagaimana? Mudah bukan? Itulah cara membuat pentol mercon daun jeruk yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
