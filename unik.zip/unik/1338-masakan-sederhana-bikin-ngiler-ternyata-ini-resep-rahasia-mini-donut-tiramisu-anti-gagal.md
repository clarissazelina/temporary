---
description: "BIKIN NGILER! Ternyata Ini Resep Rahasia Mini Donut Tiramisu Anti Gagal"
title: "BIKIN NGILER! Ternyata Ini Resep Rahasia Mini Donut Tiramisu Anti Gagal"
slug: 1338-masakan-sederhana-bikin-ngiler-ternyata-ini-resep-rahasia-mini-donut-tiramisu-anti-gagal
date: 2020-04-04T21:58:55.290Z
image: https://img-global.cpcdn.com/recipes/2ca23f902e802471/751x532cq70/mini-donut-tiramisu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2ca23f902e802471/751x532cq70/mini-donut-tiramisu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2ca23f902e802471/751x532cq70/mini-donut-tiramisu-foto-resep-utama.jpg
author: Jordan Sherman
ratingvalue: 4.1
reviewcount: 7
recipeingredient:
- "250 gr tepung terigu saya cakra"
- "50 gr gula pasir"
- "3 gr ragi"
- "Seujung sdt baking powder"
- "1 sachet susu bubuk"
- "1 kuning telur"
- "125 ml airsusu cair dingin"
- "35 gr margarin"
- "Sejumput garam"
- "Secukupnya glaze tiramisu dan bubuk oreo"
recipeinstructions:
- "Dalam wadah masukkan tepung, gula, ragi, susu bubuk dan baking powder, aduk rata, masukkan kuning telur, aduk rata lagi, beri air sedikit demi sedikit (jika adonan sudah pas, stop air), uleni sampai setengah kalis, lalu beri margarin dan garam"
- "Uleni adonan sampai kalis elastis, dan diamkan selama 10 menit"
- "Bagi adonan menjadi 25 bagian, setelah itu bulat\"kan dan letakkan di baking paper yg sudah di beri tepung terigu agar donat tidak lengket, diamkan sampai mengembang ringan kira\" 1 jam"
- "Setelah donat mengembang, goreng dengan api kecil, balik sekali saja"
- "Setelah donat dingin, beri olesan glaze dan taburan bubuk oreo.. Yummm"
categories:
- Resep
tags:
- mini
- donut
- tiramisu

katakunci: mini donut tiramisu 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Lunch

---


![Mini Donut Tiramisu](https://img-global.cpcdn.com/recipes/2ca23f902e802471/751x532cq70/mini-donut-tiramisu-foto-resep-utama.jpg)

Anda sedang mencari ide resep mini donut tiramisu yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal mini donut tiramisu yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari mini donut tiramisu, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan mini donut tiramisu yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan mini donut tiramisu sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Mini Donut Tiramisu menggunakan 10 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk membuat Mini Donut Tiramisu:

1. Gunakan 250 gr tepung terigu (saya cakra)
1. Ambil 50 gr gula pasir
1. Gunakan 3 gr ragi
1. Sediakan Seujung sdt baking powder
1. Ambil 1 sachet susu bubuk
1. Ambil 1 kuning telur
1. Siapkan 125 ml air/susu cair dingin
1. Ambil 35 gr margarin
1. Ambil Sejumput garam
1. Ambil Secukupnya glaze tiramisu dan bubuk oreo




##### Langkah-langkah meracik Mini Donut Tiramisu:

1. Dalam wadah masukkan tepung, gula, ragi, susu bubuk dan baking powder, aduk rata, masukkan kuning telur, aduk rata lagi, beri air sedikit demi sedikit (jika adonan sudah pas, stop air), uleni sampai setengah kalis, lalu beri margarin dan garam
1. Uleni adonan sampai kalis elastis, dan diamkan selama 10 menit
1. Bagi adonan menjadi 25 bagian, setelah itu bulat\"kan dan letakkan di baking paper yg sudah di beri tepung terigu agar donat tidak lengket, diamkan sampai mengembang ringan kira\" 1 jam
1. Setelah donat mengembang, goreng dengan api kecil, balik sekali saja
1. Setelah donat dingin, beri olesan glaze dan taburan bubuk oreo.. Yummm




Gimana nih? Mudah bukan? Itulah cara menyiapkan mini donut tiramisu yang bisa Anda lakukan di rumah. Selamat mencoba!
