---
description: "RECOMMENDED! Begini Resep Rahasia Santan lombok ijo rebung mix krecek(kerupuk kulit) Enak"
title: "RECOMMENDED! Begini Resep Rahasia Santan lombok ijo rebung mix krecek(kerupuk kulit) Enak"
slug: 1183-masakan-sederhana-recommended-begini-resep-rahasia-santan-lombok-ijo-rebung-mix-krecekkerupuk-kulit-enak
date: 2020-04-05T05:48:05.961Z
image: https://img-global.cpcdn.com/recipes/4713861daf156308/751x532cq70/santan-lombok-ijo-rebung-mix-krecekkerupuk-kulit-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4713861daf156308/751x532cq70/santan-lombok-ijo-rebung-mix-krecekkerupuk-kulit-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4713861daf156308/751x532cq70/santan-lombok-ijo-rebung-mix-krecekkerupuk-kulit-foto-resep-utama.jpg
author: Trevor Austin
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "500 gr rebungsudah beli rebus"
- "5 bks krecek"
- "1 batang tempe"
- "1-2 bks kara"
- " bumbu halus"
- "10 cabe merah"
- "20 secukupnya rawit"
- "3 kemiri"
- "1 ruas jahe"
- "6 bawang merah"
- "4 bawang putih"
- " bumbu kasar"
- "10 cabe hijau besariris2"
- "5 cabe merah iris2"
- "Secukupnya rawit iris2"
- "3 daun salam"
- "1 batang serai"
- "2 masako ayam"
- "1 sdm gula"
- "1 sdt micin"
- "secukupnya Air"
recipeinstructions:
- "Siapkan bumbu halus, iris bumbu kasar, dan rebus lagi rebung yang sudah dibeli, lalu tiriskan"
- "Iris tempe memanjang, lalu tumis bumbu kasar hingga wangi, lalu masukan bumbu halus tumis hingga matang"
- "Jika bumbu sudah matang masukan tempe, aduk hingga merata beri air sedikit, siapkan krecek"
- "Lalu masukan rebung dan krecek, beri penyedap, dan santan kara, masukan air secukupnya, aduk2 hingga mendidih dan matang, jika kematangan pas krecek lembut, icip sesuai selera, lalu matikan kompor, tiriskan"
categories:
- Resep
tags:
- santan
- lombok
- ijo

katakunci: santan lombok ijo 
nutrition: 239 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dinner

---


![Santan lombok ijo rebung mix krecek(kerupuk kulit)](https://img-global.cpcdn.com/recipes/4713861daf156308/751x532cq70/santan-lombok-ijo-rebung-mix-krecekkerupuk-kulit-foto-resep-utama.jpg)

Sedang mencari ide resep santan lombok ijo rebung mix krecek(kerupuk kulit) yang unik? Cara menyiapkannya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal santan lombok ijo rebung mix krecek(kerupuk kulit) yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Di mana saya bisa membeli Pelatihan Lezat Santan lombok ijo rebung mix krecek(kerupuk kulit) Studi. Pembelian hebat Treat Lezat Ayam kampung lombok ijo kemangi Murah. Harga tinggi Unik Yummy Ayam Suwir Kemangi Kiat.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari santan lombok ijo rebung mix krecek(kerupuk kulit), pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau hendak menyiapkan santan lombok ijo rebung mix krecek(kerupuk kulit) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Nah, kali ini kita coba, yuk, variasikan santan lombok ijo rebung mix krecek(kerupuk kulit) sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Santan lombok ijo rebung mix krecek(kerupuk kulit) menggunakan 21 jenis bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk meracik Santan lombok ijo rebung mix krecek(kerupuk kulit):

1. Ambil 500 gr rebung(sudah beli rebus)
1. Ambil 5 bks krecek
1. Gunakan 1 batang tempe
1. Siapkan 1-2 bks kara
1. Sediakan  bumbu halus
1. Gunakan 10 cabe merah
1. Siapkan 20 /secukupnya rawit
1. Siapkan 3 kemiri
1. Ambil 1 ruas jahe
1. Gunakan 6 bawang merah
1. Sediakan 4 bawang putih
1. Sediakan  bumbu kasar
1. Ambil 10 cabe hijau besar(iris2)
1. Ambil 5 cabe merah (iris2)
1. Ambil Secukupnya rawit (iris2)
1. Gunakan 3 daun salam
1. Siapkan 1 batang serai
1. Gunakan 2 masako ayam
1. Gunakan 1 sdm gula
1. Ambil 1 sdt micin
1. Gunakan secukupnya Air


Masukkan santan, terasi yang telah dihaluskan, garam, air asam, lengkuas, dan gula ke dalam wajan dengan tumisan. Krecek atau kerupuk kulit juga bisa dijadikan sajian istimewa seperti sayur santan atau sambal goreng ini. Masukkan kerupuk kulit, kacang kapri, kentang goreng, garam, dan gula merah. Bahan krecek terbuat dari kulit sapi yang dipotong kecil kecil dan di goreng sehingga menjadi kerupuk kulit sapi di Sunda, Bandung biasa disebut dorokdok. 

##### Langkah-langkah meracik Santan lombok ijo rebung mix krecek(kerupuk kulit):

1. Siapkan bumbu halus, iris bumbu kasar, dan rebus lagi rebung yang sudah dibeli, lalu tiriskan
1. Iris tempe memanjang, lalu tumis bumbu kasar hingga wangi, lalu masukan bumbu halus tumis hingga matang
1. Jika bumbu sudah matang masukan tempe, aduk hingga merata beri air sedikit, siapkan krecek
1. Lalu masukan rebung dan krecek, beri penyedap, dan santan kara, masukan air secukupnya, aduk2 hingga mendidih dan matang, jika kematangan pas krecek lembut, icip sesuai selera, lalu matikan kompor, tiriskan


Setelah menjadi kerupuk kulit kemudian dicampurkan pada masakan tertentu, bisa bersama tahu atau tempe atau oncom. hidangan rebung yang dipadukan dengan kerupuk kulit dan dibalut bumbu gulai memang sangatlah menggugah selera, mau tahu resepnya? simak! oelh karena itu kali ini ada sebuah sajian sederhana yang menggunakan rebung sebagai bahan dasar sajiannya, yakni gulai rebung kerupuk kulit. Masukkan daun salam, serai, santan encer, dan krecek. Tambahkan gula merah dan air asam jawa. Untuk lauk pendamping gudeg yang super komplit, maka dalam penyajian bisa tambahkan tahu tempe bacem, sambal pedas cabai merah, dan kerupuk. Resep sambal krecek kerupuk kulit dengan campuran kentang dan kacang tolo pas untuk sajian pesta hajatan Resep krecek kerupuk kulit bahkan menjadi menu alternatif paling di cari di pesta pernikahan atau hidangan Tunggu sebentar hingga mendidih. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Santan lombok ijo rebung mix krecek(kerupuk kulit) yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
