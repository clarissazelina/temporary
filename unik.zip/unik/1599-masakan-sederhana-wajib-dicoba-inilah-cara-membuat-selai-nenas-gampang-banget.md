---
description: "WAJIB DICOBA! Inilah Cara Membuat Selai Nenas Gampang Banget"
title: "WAJIB DICOBA! Inilah Cara Membuat Selai Nenas Gampang Banget"
slug: 1599-masakan-sederhana-wajib-dicoba-inilah-cara-membuat-selai-nenas-gampang-banget
date: 2020-04-04T16:32:33.540Z
image: https://img-global.cpcdn.com/recipes/57547725987100de/751x532cq70/selai-nenas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/57547725987100de/751x532cq70/selai-nenas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/57547725987100de/751x532cq70/selai-nenas-foto-resep-utama.jpg
author: Frank Fisher
ratingvalue: 3.7
reviewcount: 6
recipeingredient:
- "1 buah nanas muda"
- "4 sdm gula pasir sesuai selera"
- "1/2 sdm bubuk kayu manis"
recipeinstructions:
- "Kupas dan cuci bersih nanas kemudian parut atau blender"
- "Masak nanas yang sudah diparut atau diblender hingga airnya hampir kering"
- "Masukan gula pàsir dan bubuk kayu manis, aduk rata dan masak hingga airnya mengering"
- "Angkat dan dinginkan"
categories:
- Resep
tags:
- selai
- nenas

katakunci: selai nenas 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT47M"
recipeyield: "4"
recipecategory: Dessert

---


![Selai Nenas](https://img-global.cpcdn.com/recipes/57547725987100de/751x532cq70/selai-nenas-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep selai nenas yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal selai nenas yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan selai nenas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Nah, kali ini kita coba, yuk, ciptakan selai nenas sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Selai Nenas memakai 3 bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam membuat Selai Nenas:

1. Gunakan 1 buah nanas muda
1. Sediakan 4 sdm gula pasir (sesuai selera)
1. Sediakan 1/2 sdm bubuk kayu manis




##### Cara mengolah Selai Nenas:

1. Kupas dan cuci bersih nanas kemudian parut atau blender
1. Masak nanas yang sudah diparut atau diblender hingga airnya hampir kering
1. Masukan gula pàsir dan bubuk kayu manis, aduk rata dan masak hingga airnya mengering
1. Angkat dan dinginkan




Bagaimana? Gampang kan? Itulah cara menyiapkan selai nenas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
