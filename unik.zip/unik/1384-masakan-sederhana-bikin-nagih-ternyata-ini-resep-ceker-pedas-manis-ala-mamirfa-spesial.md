---
description: "BIKIN NAGIH! Ternyata Ini Resep Ceker Pedas Manis ala MamIrfa Spesial"
title: "BIKIN NAGIH! Ternyata Ini Resep Ceker Pedas Manis ala MamIrfa Spesial"
slug: 1384-masakan-sederhana-bikin-nagih-ternyata-ini-resep-ceker-pedas-manis-ala-mamirfa-spesial
date: 2020-04-15T05:56:58.711Z
image: https://img-global.cpcdn.com/recipes/b64e5ded944c539b/751x532cq70/ceker-pedas-manis-ala-mamirfa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b64e5ded944c539b/751x532cq70/ceker-pedas-manis-ala-mamirfa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b64e5ded944c539b/751x532cq70/ceker-pedas-manis-ala-mamirfa-foto-resep-utama.jpg
author: Derek Nash
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "6 siung Bawang Putih"
- "4 siung Bawang Merah"
- "3 buah Kemiri"
- "1 buah Cabe Merah Besar"
- "4 buah Cabe Rawit Merah"
- "secukupnya Penyedap Rasa"
- "secukupnya Merica"
- "secukupnya Kecap Manis"
- "12 potong Ceker Ayam"
- "1 lembar daun jeruk"
recipeinstructions:
- "Bersihkan ceker ayam dari kulit dan kukunya"
- "Rendam dalam air jeruk nipis"
- "Haluskan bumbu (bawang merah, bawang putih, kemiri)"
- "Panaskan minyak, tumis bumbu yang telah dihaluskan hingga harum"
- "Masukan ceker tanpa air, tumis sebentar"
- "Tambahkan air matang 100ml/secukupnya sampai ceker terendam"
- "Tunggu hingga mendidih. Tambahkan kecap manis secukupnya, masukan penyedap dan merica secukupnya. Aduk hingga merata"
- "Tutup wajan. Dan diamkan selama kurang lebih 3 menit. Masukan potongan cabe merah, cabe rawit, daun jeruk"
- "Tutup kembali. Dan tunggu hingga air dan bumbu meresap kedalam ceker"
- "Ceker pedas manis siap disajikan"
categories:
- Resep
tags:
- ceker
- pedas
- manis

katakunci: ceker pedas manis 
nutrition: 295 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Dessert

---


![Ceker Pedas Manis ala MamIrfa](https://img-global.cpcdn.com/recipes/b64e5ded944c539b/751x532cq70/ceker-pedas-manis-ala-mamirfa-foto-resep-utama.jpg)

Lagi mencari ide resep ceker pedas manis ala mamirfa yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal ceker pedas manis ala mamirfa yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ceker pedas manis ala mamirfa, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan ceker pedas manis ala mamirfa enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.




Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah ceker pedas manis ala mamirfa yang siap dikreasikan. Anda bisa membuat Ceker Pedas Manis ala MamIrfa memakai 10 bahan dan 10 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Ceker Pedas Manis ala MamIrfa:

1. Gunakan 6 siung Bawang Putih
1. Ambil 4 siung Bawang Merah
1. Gunakan 3 buah Kemiri
1. Gunakan 1 buah Cabe Merah Besar
1. Sediakan 4 buah Cabe Rawit Merah
1. Sediakan secukupnya Penyedap Rasa
1. Ambil secukupnya Merica
1. Siapkan secukupnya Kecap Manis
1. Gunakan 12 potong Ceker Ayam
1. Gunakan 1 lembar daun jeruk




##### Langkah-langkah mengolah Ceker Pedas Manis ala MamIrfa:

1. Bersihkan ceker ayam dari kulit dan kukunya
1. Rendam dalam air jeruk nipis
1. Haluskan bumbu (bawang merah, bawang putih, kemiri)
1. Panaskan minyak, tumis bumbu yang telah dihaluskan hingga harum
1. Masukan ceker tanpa air, tumis sebentar
1. Tambahkan air matang 100ml/secukupnya sampai ceker terendam
1. Tunggu hingga mendidih. Tambahkan kecap manis secukupnya, masukan penyedap dan merica secukupnya. Aduk hingga merata
1. Tutup wajan. Dan diamkan selama kurang lebih 3 menit. Masukan potongan cabe merah, cabe rawit, daun jeruk
1. Tutup kembali. Dan tunggu hingga air dan bumbu meresap kedalam ceker
1. Ceker pedas manis siap disajikan




Gimana nih? Gampang kan? Itulah cara membuat ceker pedas manis ala mamirfa yang bisa Anda praktikkan di rumah. Selamat mencoba!
