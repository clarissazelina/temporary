---
description: "RECOMMENDED! Inilah Resep Rahasia Glotak Ceker Khas Tegal Pasti Berhasil"
title: "RECOMMENDED! Inilah Resep Rahasia Glotak Ceker Khas Tegal Pasti Berhasil"
slug: 1559-masakan-sederhana-recommended-inilah-resep-rahasia-glotak-ceker-khas-tegal-pasti-berhasil
date: 2020-07-15T12:24:27.462Z
image: https://img-global.cpcdn.com/recipes/6ba487c66b841e0e/751x532cq70/glotak-ceker-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ba487c66b841e0e/751x532cq70/glotak-ceker-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ba487c66b841e0e/751x532cq70/glotak-ceker-khas-tegal-foto-resep-utama.jpg
author: Lee McDaniel
ratingvalue: 3
reviewcount: 15
recipeingredient:
- "1/4 kg Ceker ayam"
- "1 papan Tempe"
- "3 lonjor Gembus"
- "3 siung Bawang merah iris tipis"
- "10 buah Cabe Ijo iris serong"
- "300 ml Kaldu Ayam"
- "1 bungkus Masako Ayam"
- "Secukupnya Minyak untuk menumis"
- " Bumbu halus"
- "5 buah Cabe Kering Merah"
- "3 buah Cabe Merah"
- "5 buah Cabe Rawit"
- "5 siung Bawang Putih"
- "5 siung Bawang Merah"
- "2 butir Kemiri"
- "1 ruas Lengkuas"
- "1 cm Jahe"
- "Secukupnya Merica"
- "Secukupnya Garam"
- " Bahan Cemplung"
- "1 ruas Sereh"
- "1 ruas Lengkuas"
- "4 lembar daun salam"
recipeinstructions:
- "Rebus Ceker ayam kurleb 30 menit"
- "Tumbuk Tempe dan Gembus hingga halus"
- "Siapkan bumbu halus dan bumbu cemplung"
- "Tumis bawang merah sampai harum, masukan bumbu halus, aduk perlahan"
- "Bila warna minyak sudah berubah kemerahan dan mengering, masukan Cabe ijo, dan Bumbu Cemplung, tumis hingga layu"
- "Masukan Ceker yang sudah di rebus, aduk rata, lalu masukan air kaldu 200 ml dulu (me : sisa rebusan ceker)"
- "Tunggu hingga mendidih, dan masukan tempe dan gembus yang sudah di haluskan, aduk rata, bila air sudah meresap tambahkan lagi sisa air rebusan"
- "Tunggu hingga air tersisa sedikit dan minyak keluar, tes rasa, tambahkan 1 bngkus masako, garam dan gula sesuai selera"
- "Glotak ceker siap di hidangkan, bisa dimakan dengan kerupuk mie atau kerupuk batok"
categories:
- Resep
tags:
- glotak
- ceker
- khas

katakunci: glotak ceker khas 
nutrition: 297 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Glotak Ceker Khas Tegal](https://img-global.cpcdn.com/recipes/6ba487c66b841e0e/751x532cq70/glotak-ceker-khas-tegal-foto-resep-utama.jpg)

Sedang mencari inspirasi resep glotak ceker khas tegal yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal glotak ceker khas tegal yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari glotak ceker khas tegal, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan glotak ceker khas tegal enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah glotak ceker khas tegal yang siap dikreasikan. Anda bisa membuat Glotak Ceker Khas Tegal menggunakan 23 jenis bahan dan 9 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk membuat Glotak Ceker Khas Tegal:

1. Sediakan 1/4 kg Ceker ayam
1. Ambil 1 papan Tempe
1. Ambil 3 lonjor Gembus
1. Siapkan 3 siung Bawang merah iris tipis
1. Ambil 10 buah Cabe Ijo iris serong
1. Ambil 300 ml Kaldu Ayam
1. Siapkan 1 bungkus Masako Ayam
1. Ambil Secukupnya Minyak untuk menumis
1. Siapkan  Bumbu halus
1. Sediakan 5 buah Cabe Kering Merah
1. Siapkan 3 buah Cabe Merah
1. Sediakan 5 buah Cabe Rawit
1. Ambil 5 siung Bawang Putih
1. Sediakan 5 siung Bawang Merah
1. Gunakan 2 butir Kemiri
1. Sediakan 1 ruas Lengkuas
1. Ambil 1 cm Jahe
1. Sediakan Secukupnya Merica
1. Gunakan Secukupnya Garam
1. Sediakan  Bahan Cemplung
1. Ambil 1 ruas Sereh
1. Sediakan 1 ruas Lengkuas
1. Ambil 4 lembar daun salam




##### Cara mengolah Glotak Ceker Khas Tegal:

1. Rebus Ceker ayam kurleb 30 menit
1. Tumbuk Tempe dan Gembus hingga halus
1. Siapkan bumbu halus dan bumbu cemplung
1. Tumis bawang merah sampai harum, masukan bumbu halus, aduk perlahan
1. Bila warna minyak sudah berubah kemerahan dan mengering, masukan Cabe ijo, dan Bumbu Cemplung, tumis hingga layu
1. Masukan Ceker yang sudah di rebus, aduk rata, lalu masukan air kaldu 200 ml dulu (me : sisa rebusan ceker)
1. Tunggu hingga mendidih, dan masukan tempe dan gembus yang sudah di haluskan, aduk rata, bila air sudah meresap tambahkan lagi sisa air rebusan
1. Tunggu hingga air tersisa sedikit dan minyak keluar, tes rasa, tambahkan 1 bngkus masako, garam dan gula sesuai selera
1. Glotak ceker siap di hidangkan, bisa dimakan dengan kerupuk mie atau kerupuk batok




Bagaimana? Gampang kan? Itulah cara menyiapkan glotak ceker khas tegal yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
