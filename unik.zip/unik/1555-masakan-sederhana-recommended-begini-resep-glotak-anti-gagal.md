---
description: "RECOMMENDED! Begini Resep Glotak Anti Gagal"
title: "RECOMMENDED! Begini Resep Glotak Anti Gagal"
slug: 1555-masakan-sederhana-recommended-begini-resep-glotak-anti-gagal
date: 2020-04-02T11:37:21.498Z
image: https://img-global.cpcdn.com/recipes/86753385770f8449/751x532cq70/glotak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86753385770f8449/751x532cq70/glotak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86753385770f8449/751x532cq70/glotak-foto-resep-utama.jpg
author: Benjamin Oliver
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- " Bahan air kaldu "
- "10 ceker ayam bs diganti tulang ayamsapi"
- "1000-1500 ml air"
- " Bahan utama "
- "4 papan gembus kukus lalu haluskan"
- " Bumbu halus "
- "5 bawang putih"
- "8 bawang merah"
- "9 cabe merah keriting"
- "6 cabe rawit merah"
- "1 sdt ketumbar"
- "5 kemiri"
- "1/2 sdt garam"
- " Bahan tumis "
- "2 cm lengkuas geprek"
- "1 serai geprek"
- "2 daun salam"
- "3 daun jeruk sobek2"
- "8 cabe hijau gendutpotong memanjang"
- "Sedikit gula Jawa"
- "8 cabe rawit merah dan hijau rawit utuhglondongan"
- " Bahan tambahan "
- " Garam"
- " Gula"
- " Masako"
- "1 sdm kecap manis"
- " Minyak goreng untuk menumis"
recipeinstructions:
- "Rebus air dan ceker hingga mendidih,jika sudah mendidih sisihkan.kukus Gembus lalu haluskan"
- "Siapkan bahan bumbu halus,dan bahan yang di potong."
- "Tuang minyak tumis bumbu halus hingga harum,lalu masukkan daun jeruk, daun salam,serai, gula Jawa dan lengkuas tumis hingga harum"
- "Jika harum masukan cabe hijau potong,cabe rawit utuh/glondongan,tumis hingga setengah layu lalu masukkan air kaldu dan cekernya.masak hingga mendidih"
- "Jika sudah mendidih masukkan gembus,garam, gula,Masako dan kecap manis masak sampe air menyusut dan kental.."
- "Glotak sudah matang"
- "Sajikan dengan nasi putih hangat."
categories:
- Resep
tags:
- glotak

katakunci: glotak 
nutrition: 199 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT50M"
recipeyield: "2"
recipecategory: Dessert

---


![Glotak](https://img-global.cpcdn.com/recipes/86753385770f8449/751x532cq70/glotak-foto-resep-utama.jpg)

Lagi mencari inspirasi resep glotak yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal glotak yang enak harusnya sih punya aroma dan rasa yang mampu memancing selera kita.

Lokasinya sendiri berada di lereng Gunung Kawi. Glotak adalah makanan tradisional dari Tegal. Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari glotak, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan glotak enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat glotak yang siap dikreasikan. Anda dapat menyiapkan Glotak memakai 27 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk mengolah Glotak:

1. Siapkan  Bahan air kaldu :
1. Gunakan 10 ceker ayam (bs diganti tulang ayam/sapi)
1. Sediakan 1000-1500 ml air
1. Sediakan  Bahan utama :
1. Siapkan 4 papan gembus (kukus lalu haluskan)
1. Ambil  Bumbu halus :
1. Gunakan 5 bawang putih
1. Ambil 8 bawang merah
1. Siapkan 9 cabe merah keriting
1. Gunakan 6 cabe rawit merah
1. Siapkan 1 sdt ketumbar
1. Gunakan 5 kemiri
1. Ambil 1/2 sdt garam
1. Sediakan  Bahan tumis :
1. Ambil 2 cm lengkuas geprek
1. Sediakan 1 serai geprek
1. Sediakan 2 daun salam
1. Sediakan 3 daun jeruk (sobek2)
1. Ambil 8 cabe hijau gendut(potong memanjang)
1. Ambil Sedikit gula Jawa
1. Ambil 8 cabe rawit merah dan hijau rawit utuh/glondongan
1. Ambil  Bahan tambahan :
1. Sediakan  Garam
1. Ambil  Gula
1. Ambil  Masako
1. Ambil 1 sdm kecap manis
1. Gunakan  Minyak goreng untuk menumis


Coban Glotak Wagir Malang, Keindahan Air Terjun Tersembunyi. Blog Diah Didi berisi resep masakan praktis yang mudah dipraktekkan di rumah. Coban Glotak, Track Tepat Bagi Jiwa Petualang. 

##### Cara meracik Glotak:

1. Rebus air dan ceker hingga mendidih,jika sudah mendidih sisihkan.kukus Gembus lalu haluskan
1. Siapkan bahan bumbu halus,dan bahan yang di potong.
1. Tuang minyak tumis bumbu halus hingga harum,lalu masukkan daun jeruk, daun salam,serai, gula Jawa dan lengkuas tumis hingga harum
1. Jika harum masukan cabe hijau potong,cabe rawit utuh/glondongan,tumis hingga setengah layu lalu masukkan air kaldu dan cekernya.masak hingga mendidih
1. Jika sudah mendidih masukkan gembus,garam, gula,Masako dan kecap manis masak sampe air menyusut dan kental..
1. Glotak sudah matang
1. Sajikan dengan nasi putih hangat.




Bagaimana? Gampang kan? Itulah cara menyiapkan glotak yang bisa Anda lakukan di rumah. Selamat mencoba!
