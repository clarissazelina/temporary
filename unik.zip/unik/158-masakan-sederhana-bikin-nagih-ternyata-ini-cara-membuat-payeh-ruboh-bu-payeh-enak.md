---
description: "BIKIN NAGIH! Ternyata Ini Cara Membuat Payeh Ruboh (Bu Payeh) Enak"
title: "BIKIN NAGIH! Ternyata Ini Cara Membuat Payeh Ruboh (Bu Payeh) Enak"
slug: 158-masakan-sederhana-bikin-nagih-ternyata-ini-cara-membuat-payeh-ruboh-bu-payeh-enak
date: 2020-06-15T10:52:35.729Z
image: https://img-global.cpcdn.com/recipes/c40bc56597b2011c/751x532cq70/payeh-ruboh-bu-payeh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c40bc56597b2011c/751x532cq70/payeh-ruboh-bu-payeh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c40bc56597b2011c/751x532cq70/payeh-ruboh-bu-payeh-foto-resep-utama.jpg
author: Christian Floyd
ratingvalue: 3.7
reviewcount: 7
recipeingredient:
- "1 kg Beras Ketan Putih"
- "350 gr Gula Pasir manis sesuai selera"
- "2 buah Kelapa peras ambil santan yang kental"
- "2 sachet Vanili Powder"
- "Secukupnya Pisang AyamWakRaja"
- "Secukupnya Daun Pandan"
- "Secukupnya Garam"
- "Secukupnya Daun Pisang Muda untuk membungkus"
recipeinstructions:
- "Ambil beras lalu cuci yang bersih."
- "Lalu ambil wajan, masukkan beras kedalam wajan berserta dengan santan, gula, garam, vanili powder dan daun pandan. Lalu aduk yang rata."
- "Setelah diaduk rata lalu masak campuran beras tadi dengan api sedang sampai santannya menyusut dan kering tapi tidak gosong. Aduk terus agar santannya tidak pecah."
- "Masak terus sampai matang dan santannya meresap dan kering. Jika sudah matang lalu angkat dan dinginkan."
- "Kemudian ambil daun pisang lalu potong sesuai selera ukuran payeh ruboh (bu payeh) nya. Jika sudah sisihkan."
- "Lalu ambil pisang dan kupas kulinya. Setelah dikupas kulitnya lalu belas dua pisangnya sampai putus."
- "Jika semuanya sudah sekarang saatnya membuat payeh ruboh (bu payeh) nya. Cara membuatnya sama seperti membuat timphan cuma beda bahan dan isinya saja dan payeh ruboh (bu payeh) juga tidak memerlukan minyak untuk diolesi pada daun pisang."
- "Cara membuat bu payeh yaitu pertama ambil daun pisang yang sudah dipotong-potong tadi lalu susun yang rapi diatas piring/wadah setelah itu ambil 2 sendok makan (atau lebih sesuai selera ukurannya) adonan berasnya taruh diatas daun pisang lembaran pertama lalu pipihkan. Jika sudah dipipihkan lalu taruh 1 potong pisang yang sudah dibelah tadi diatasnya lalu digulung (lakukan terus hal yang sama sampai semuanya habis)."
- "Jika sudah selesai digulung semuanya langsung susun yang rapi payeh ruboh (bu payeh) nya ke dalam dandang pengukusan. Lalu kukus sampai matang kurang lebih 35 menit."
- "Jika sudah matang lalu angkat dan pindahkan ke wadah yang lain. Dan payeh ruboh (bu payeh) pun siap dinikmati."
- "Selamat Mencoba !!!."
categories:
- Resep
tags:
- payeh
- ruboh
- bu

katakunci: payeh ruboh bu 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Payeh Ruboh (Bu Payeh)](https://img-global.cpcdn.com/recipes/c40bc56597b2011c/751x532cq70/payeh-ruboh-bu-payeh-foto-resep-utama.jpg)

Sedang mencari inspirasi resep payeh ruboh (bu payeh) yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal payeh ruboh (bu payeh) yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari payeh ruboh (bu payeh), mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan payeh ruboh (bu payeh) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.


Nah, kali ini kita coba, yuk, variasikan payeh ruboh (bu payeh) sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Payeh Ruboh (Bu Payeh) menggunakan 8 bahan dan 11 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Payeh Ruboh (Bu Payeh):

1. Sediakan 1 kg Beras Ketan Putih
1. Gunakan 350 gr Gula Pasir (manis sesuai selera)
1. Sediakan 2 buah Kelapa (peras ambil santan yang kental)
1. Ambil 2 sachet Vanili Powder
1. Gunakan Secukupnya Pisang Ayam/Wak/Raja
1. Sediakan Secukupnya Daun Pandan
1. Siapkan Secukupnya Garam
1. Siapkan Secukupnya Daun Pisang Muda (untuk membungkus)




##### Cara meracik Payeh Ruboh (Bu Payeh):

1. Ambil beras lalu cuci yang bersih.
1. Lalu ambil wajan, masukkan beras kedalam wajan berserta dengan santan, gula, garam, vanili powder dan daun pandan. Lalu aduk yang rata.
1. Setelah diaduk rata lalu masak campuran beras tadi dengan api sedang sampai santannya menyusut dan kering tapi tidak gosong. Aduk terus agar santannya tidak pecah.
1. Masak terus sampai matang dan santannya meresap dan kering. Jika sudah matang lalu angkat dan dinginkan.
1. Kemudian ambil daun pisang lalu potong sesuai selera ukuran payeh ruboh (bu payeh) nya. Jika sudah sisihkan.
1. Lalu ambil pisang dan kupas kulinya. Setelah dikupas kulitnya lalu belas dua pisangnya sampai putus.
1. Jika semuanya sudah sekarang saatnya membuat payeh ruboh (bu payeh) nya. Cara membuatnya sama seperti membuat timphan cuma beda bahan dan isinya saja dan payeh ruboh (bu payeh) juga tidak memerlukan minyak untuk diolesi pada daun pisang.
1. Cara membuat bu payeh yaitu pertama ambil daun pisang yang sudah dipotong-potong tadi lalu susun yang rapi diatas piring/wadah setelah itu ambil 2 sendok makan (atau lebih sesuai selera ukurannya) adonan berasnya taruh diatas daun pisang lembaran pertama lalu pipihkan. Jika sudah dipipihkan lalu taruh 1 potong pisang yang sudah dibelah tadi diatasnya lalu digulung (lakukan terus hal yang sama sampai semuanya habis).
1. Jika sudah selesai digulung semuanya langsung susun yang rapi payeh ruboh (bu payeh) nya ke dalam dandang pengukusan. Lalu kukus sampai matang kurang lebih 35 menit.
1. Jika sudah matang lalu angkat dan pindahkan ke wadah yang lain. Dan payeh ruboh (bu payeh) pun siap dinikmati.
1. Selamat Mencoba !!!.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Payeh Ruboh (Bu Payeh) yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
