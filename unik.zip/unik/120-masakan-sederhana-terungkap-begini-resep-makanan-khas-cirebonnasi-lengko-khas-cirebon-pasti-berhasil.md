---
description: "TERUNGKAP! Begini Resep Makanan Khas Cirebon~Nasi Lengko Khas Cirebon Pasti Berhasil"
title: "TERUNGKAP! Begini Resep Makanan Khas Cirebon~Nasi Lengko Khas Cirebon Pasti Berhasil"
slug: 120-masakan-sederhana-terungkap-begini-resep-makanan-khas-cirebonnasi-lengko-khas-cirebon-pasti-berhasil
date: 2020-09-02T07:07:25.088Z
image: https://img-global.cpcdn.com/recipes/3e33403ef008e480/751x532cq70/makanan-khas-cirebonnasi-lengko-khas-cirebon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/3e33403ef008e480/751x532cq70/makanan-khas-cirebonnasi-lengko-khas-cirebon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/3e33403ef008e480/751x532cq70/makanan-khas-cirebonnasi-lengko-khas-cirebon-foto-resep-utama.jpg
author: Isabel Carter
ratingvalue: 4.7
reviewcount: 14
recipeingredient:
- "Sepiring nasi"
- "1 buah tahu"
- "1 buah tempe"
- " Ikan tongkol siap goreng"
- "Secukupnya kecap"
- "Secukupnya daun bawang goreng"
- "Secukupnya daun kucai"
- "Secukupnya mentimun"
- "Secukupnya tauge rebus"
- " Bahan bumbu "
- "150 gr kacang tanah"
- "3 siung bawang putih"
- "2 buah cabe merah"
- "5 cabe rawit sesuai selera"
- "1 sdm gula merah disisir"
- "1 lembar daun jeruk"
- "Secukupnya garam  penyedap rasa"
- " Bahan sambal "
- "1 buah tomat"
- "2 buah cabai merah"
- "5 cabe rawit sesuai selera"
- "Sejumput terasi"
- "2 siung bawang merah"
- "Secukupnya garam"
recipeinstructions:
- "Siapkan semua bahan, goreng kacang tanah kemudian blender semua bahan bumbu. Sisihkan"
- "Goreng tahu & tempe dg dicelupkan air yg diberi garam & bawang putih geprek. Sisihkan"
- "Goreng bahan sambal kemudian ulek halus. Goreng jg ikan tongkolnya kemudian Sisihkan"
- "Nah mari kita susun urutan nasi lengko nya. Sajikan nasi dalam piring, letakkan tauge yg sdh direbus tadi diatasnya, tambahkan tahu, tempe, bumbu kacang, daun bawang goreng dan daun kucai."
- "Letakkan sambal goreng, ikan tongkol dan jg irisan mentimun. Tambahkan kecap diatasnya"
- "Nasi Lengko Khas Cirebon siap dihidangkan 😍"
categories:
- Resep
tags:
- makanan
- khas
- cirebonnasi

katakunci: makanan khas cirebonnasi 
nutrition: 134 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Dinner

---


![Makanan Khas Cirebon~Nasi Lengko Khas Cirebon](https://img-global.cpcdn.com/recipes/3e33403ef008e480/751x532cq70/makanan-khas-cirebonnasi-lengko-khas-cirebon-foto-resep-utama.jpg)

Sedang mencari ide resep makanan khas cirebon~nasi lengko khas cirebon yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal makanan khas cirebon~nasi lengko khas cirebon yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari makanan khas cirebon~nasi lengko khas cirebon, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan makanan khas cirebon~nasi lengko khas cirebon enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Menikmati makanan khas nasi lengko di Alun-alun Kejaksan, Kota Cirebon. Kuliner khas dari Cirebon yang satu ini mungkin masih terdengar asing di telinga orang, tapi Bubur Sop Ayam juga termasuk salah satu makanan khas Berbeda dengan nasi khas daerah lain yang seringkali menggunakan daun pisang. Awal mula Nasi Jamblang menjadi terkenal adalah cita rasa.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat makanan khas cirebon~nasi lengko khas cirebon yang siap dikreasikan. Anda dapat menyiapkan Makanan Khas Cirebon~Nasi Lengko Khas Cirebon memakai 24 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Makanan Khas Cirebon~Nasi Lengko Khas Cirebon:

1. Siapkan Sepiring nasi
1. Sediakan 1 buah tahu
1. Siapkan 1 buah tempe
1. Gunakan  Ikan tongkol siap goreng
1. Siapkan Secukupnya kecap
1. Sediakan Secukupnya daun bawang goreng
1. Sediakan Secukupnya daun kucai
1. Sediakan Secukupnya mentimun
1. Ambil Secukupnya tauge rebus
1. Gunakan  Bahan bumbu :
1. Sediakan 150 gr kacang tanah
1. Siapkan 3 siung bawang putih
1. Gunakan 2 buah cabe merah
1. Gunakan 5 cabe rawit (sesuai selera)
1. Sediakan 1 sdm gula merah disisir
1. Sediakan 1 lembar daun jeruk
1. Siapkan Secukupnya garam & penyedap rasa
1. Gunakan  Bahan sambal :
1. Ambil 1 buah tomat
1. Gunakan 2 buah cabai merah
1. Sediakan 5 cabe rawit (sesuai selera)
1. Sediakan Sejumput terasi
1. Gunakan 2 siung bawang merah
1. Siapkan Secukupnya garam


Sega lengko atau nasi lengko, makanan khas yang sederhana, berupa nasi putih, tempe goreng, tahu goreng, mentimun cacah, dan taoge Nah, di Cirebon, ada satu kuliner unik yang memadukan bubur dengan kuah sup ayam yang gurih dan melimpah. Salah satunya kios terkenal yang sudah. Nasi lengko adalah sajian kuliner khas Cirebon yang terkenal selain makanan khas Cirebon docang. Makanan ciri khas Cirebon yang satu ini berbahan utama singkong. 

##### Cara meracik Makanan Khas Cirebon~Nasi Lengko Khas Cirebon:

1. Siapkan semua bahan, goreng kacang tanah kemudian blender semua bahan bumbu. Sisihkan
1. Goreng tahu & tempe dg dicelupkan air yg diberi garam & bawang putih geprek. Sisihkan
1. Goreng bahan sambal kemudian ulek halus. Goreng jg ikan tongkolnya kemudian Sisihkan
1. Nah mari kita susun urutan nasi lengko nya. Sajikan nasi dalam piring, letakkan tauge yg sdh direbus tadi diatasnya, tambahkan tahu, tempe, bumbu kacang, daun bawang goreng dan daun kucai.
1. Letakkan sambal goreng, ikan tongkol dan jg irisan mentimun. Tambahkan kecap diatasnya
1. Nasi Lengko Khas Cirebon siap dihidangkan 😍


Bentuknya bulat dengan tambahan isi berupa oncom atau dage lalu digoreng hingga matang. Termasuk juga untuk makanan khas Cirebon yang terhitung ada puluhan jumlahnya. Nah, beberapa yang paling terkenal adalah Empal Gentong dan Nasi Kalau Nasi Lengko mirip dengan pecel, maka Docang identik dengan kupat tahu Singaparna. Hal ini dikarenakan isian Docang yang berupa tauge. Makanan Khas Cirebon - Sahabat kulineria kali ini kita akan membahas Cirebon, tapi bukan menngenai sejarah atau tempat wisatanya, tapi mengenai kuliner khasnya. 

Bagaimana? Gampang kan? Itulah cara menyiapkan makanan khas cirebon~nasi lengko khas cirebon yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
