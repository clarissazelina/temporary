---
description: "BIKIN NGILER! Inilah Resep Cucur Aneka Warna Gampang Banget"
title: "BIKIN NGILER! Inilah Resep Cucur Aneka Warna Gampang Banget"
slug: 1837-masakan-sederhana-bikin-ngiler-inilah-resep-cucur-aneka-warna-gampang-banget
date: 2020-07-24T10:51:20.576Z
image: https://img-global.cpcdn.com/recipes/1d599836eab2fa1d/751x532cq70/cucur-aneka-warna-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d599836eab2fa1d/751x532cq70/cucur-aneka-warna-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d599836eab2fa1d/751x532cq70/cucur-aneka-warna-foto-resep-utama.jpg
author: Amanda Gibson
ratingvalue: 4.2
reviewcount: 13
recipeingredient:
- "100 gram tepung terigu"
- "125 gram tepung beras"
- "1/2 sdt garam"
- "9 sdm gula pasir sesuai selera"
- "250-300 ml air disesuaikan hingga tekstur adonannya pas saja ya"
- "Secukupnya minyak utk menggoreng"
- " Pewarna makanan kuning ungu dan pink"
recipeinstructions:
- "Dalam panci, rebus gula pasir dan air hingga gula larut. (tidak harus mendidih). Sisihkan dan tunggu hingga hangat."
- "Dalam wadah, campur tepung terigu, tepung beras, dan garam. Aduk rata. Lalu tuang air gula sedikit demi sedikit."
- "Aduk dengan wisk hingga tekstur licin dan tidak putus (tidak encer juga tidak kental) dan tidak ada tepung yg menggerindil, lebih bagus jika disaring. Setelah itu diamkan selama kurleb 1-2 jam sembari ditutup dgn kain bersih."
- "Setelah itu, bagi adonan menjadi bbrp bagian sama rata utk diberi warna."
- "Panaskan 1 centong minyak di wajan hingga benar² panas., lalu tuang 1 centong adonan cucur. Tunggu hingga terbentuk serat sampai ketengah, kemudian siram siram kue cucur dengan minyak yg ada di sekelilingnya. (cucur tidak perlu dibalik ya) jika dirasa sdh matang merata, angkat dan tiriskan cucur."
- "Tambahkan 2 sdm minyak diwajan setiap selesai menggoreng 2 cucur. Panaskan minyak dahulu lalu lanjut menggoreng. Lakukan hingga adonan habis."
- "Kue cucur siap disantap :)"
categories:
- Resep
tags:
- cucur
- aneka
- warna

katakunci: cucur aneka warna 
nutrition: 280 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Lunch

---


![Cucur Aneka Warna](https://img-global.cpcdn.com/recipes/1d599836eab2fa1d/751x532cq70/cucur-aneka-warna-foto-resep-utama.jpg)

Sedang mencari inspirasi resep cucur aneka warna yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal cucur aneka warna yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cucur aneka warna, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan cucur aneka warna enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.




Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah cucur aneka warna yang siap dikreasikan. Anda bisa membuat Cucur Aneka Warna memakai 7 bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Cucur Aneka Warna:

1. Ambil 100 gram tepung terigu
1. Sediakan 125 gram tepung beras
1. Ambil 1/2 sdt garam
1. Sediakan 9 sdm gula pasir (sesuai selera)
1. Siapkan 250-300 ml air (disesuaikan hingga tekstur adonannya pas saja ya)
1. Gunakan Secukupnya minyak utk menggoreng
1. Siapkan  Pewarna makanan kuning, ungu, dan pink




##### Langkah-langkah membuat Cucur Aneka Warna:

1. Dalam panci, rebus gula pasir dan air hingga gula larut. (tidak harus mendidih). Sisihkan dan tunggu hingga hangat.
1. Dalam wadah, campur tepung terigu, tepung beras, dan garam. Aduk rata. Lalu tuang air gula sedikit demi sedikit.
1. Aduk dengan wisk hingga tekstur licin dan tidak putus (tidak encer juga tidak kental) dan tidak ada tepung yg menggerindil, lebih bagus jika disaring. Setelah itu diamkan selama kurleb 1-2 jam sembari ditutup dgn kain bersih.
1. Setelah itu, bagi adonan menjadi bbrp bagian sama rata utk diberi warna.
1. Panaskan 1 centong minyak di wajan hingga benar² panas., lalu tuang 1 centong adonan cucur. Tunggu hingga terbentuk serat sampai ketengah, kemudian siram siram kue cucur dengan minyak yg ada di sekelilingnya. (cucur tidak perlu dibalik ya) jika dirasa sdh matang merata, angkat dan tiriskan cucur.
1. Tambahkan 2 sdm minyak diwajan setiap selesai menggoreng 2 cucur. Panaskan minyak dahulu lalu lanjut menggoreng. Lakukan hingga adonan habis.
1. Kue cucur siap disantap :)




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Cucur Aneka Warna yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
