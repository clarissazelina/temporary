---
description: "WAJIB DICOBA! Begini Resep Rahasia Sroto Khas Sokaraja Gampang Banget"
title: "WAJIB DICOBA! Begini Resep Rahasia Sroto Khas Sokaraja Gampang Banget"
slug: 1620-masakan-sederhana-wajib-dicoba-begini-resep-rahasia-sroto-khas-sokaraja-gampang-banget
date: 2020-06-03T09:46:11.117Z
image: https://img-global.cpcdn.com/recipes/46408702fb5db633/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/46408702fb5db633/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/46408702fb5db633/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
author: Emily Kelly
ratingvalue: 4.6
reviewcount: 3
recipeingredient:
- "1 potong ayam me paha ayam"
- "1 bungkus kecil toge pendek me 2 rb"
- "1 bungkus kecil soun"
- "3 batang daun bawang"
- "1 batang daun seledri"
- "7 lembar daun jeruk"
- "5 lembar daun salam"
- "1 batang sereh geprek"
- "2 cm jahe geprek"
- "2 cm lengkuas geprek"
- "9 biji cengkeh"
- "1 sdm garam"
- "20 gr kaldu bubuk setara 2 bks kecil kaldu bubuk"
- "1.5 L air"
- " Bumbu halus "
- "3 butir bamer"
- "5 butir baput"
- "3 butir kemiri"
- "1/2 sdt merica"
- "2 cm kunyit"
- " Bumbu sambal "
- "100 gr kacang tanah"
- "25 buah cabe rawit merah"
- "1.5 keping gula merah"
- "1/2 sdt garam"
- "5 sdm minyak goreng"
- " Bawang goreng untuk taburan me lupa pake"
- " Bahan pelengkap "
- " Kerupuk singkongkerupuk merah"
- "1 buah jeruk nipis"
- "secukupnya Kecap"
recipeinstructions:
- "Ulek semua bumbu: duo bawang, kemiri, merica & kunyit sampai halus. Sisihkan."
- "Panaskan minyak goreng, tumis bumbu sampai harum. Masukkan daun salam, daun jeruk, jahe, lengkuas, sereh, cengkeh. Tumis kembali sampai daun layu, baru pindahkan bumbu ke panci yg sdh ada rebusan ayamnya. Masukkan garam, kaldu bubuk & gula merah. Aduk rata & cicipi rasanya. Baru masukkan potongan daun bawang & seledri (sisakan daun bawang saja sekitar 3 sdm untuk taburan)."
- "Rebus dl tauge pendek selama 10 menit (untuk menghilangkan bau langunya), matikan api lalu angkat & tiriskan. Untuk sounnya rebus dgn air panas sampai agak lembek, lalu tiriskan."
- "Bahan sambal : goreng kacang sampai kecoklatan (bkn gosong ya), angkat & tiriskan. Lalu cabe jg di goreng sebentar aja (kl bisa pake tutup ya bun tkut meletup), matikan api & tiriskan. Ulek kacang sedikit demi sedikit sampai halus (sisakan 3 sdm untuk taburan di sotonya) & sisihkan. Selanjutnya ulek cabe, setelah agak halus tambahkan gula merah & garam."
- "Setelah halus masukkan kacang uleknya, campur hingga merata. Seperti di gambar ya bun (sesuai selera bunda jg gpp)."
- "Untuk sambal, cairkan dgn kuah soto secukupnya (supaya lbh sedap ya bun)."
- "Racik bahan ke dlm mangkuk : soun, tauge pendek, potongan daun bawang & kacang goreng. Siram dgn kuah soto, lalu taburi dgn bawang goreng. Tambahkan kecap, jeruk nipis, kerupuk & sambalnya. Sroto sokarajapun siap di santap 🤤"
categories:
- Resep
tags:
- sroto
- khas
- sokaraja

katakunci: sroto khas sokaraja 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT51M"
recipeyield: "1"
recipecategory: Dinner

---


![Sroto Khas Sokaraja](https://img-global.cpcdn.com/recipes/46408702fb5db633/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg)

Lagi mencari ide resep sroto khas sokaraja yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sroto khas sokaraja yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sroto khas sokaraja, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan sroto khas sokaraja yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.

Sroto Sokaraja adalah soto khas Sokaraja, Banyumas (PURWOKERTO), Jawa Tengah. Adanya campuran bumbu sambal kacang dan ketupat. Soto Sokaraja atau oleh masyarakat Banyumas disebut Sroto Sokaraja adalah sejenis makanan dari Indonesia.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah sroto khas sokaraja yang siap dikreasikan. Anda bisa menyiapkan Sroto Khas Sokaraja menggunakan 31 jenis bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Sroto Khas Sokaraja:

1. Gunakan 1 potong ayam (me: paha ayam)
1. Gunakan 1 bungkus kecil toge pendek (me: 2 rb)
1. Siapkan 1 bungkus kecil soun
1. Siapkan 3 batang daun bawang
1. Gunakan 1 batang daun seledri
1. Ambil 7 lembar daun jeruk
1. Siapkan 5 lembar daun salam
1. Ambil 1 batang sereh (geprek)
1. Ambil 2 cm jahe (geprek)
1. Gunakan 2 cm lengkuas (geprek)
1. Sediakan 9 biji cengkeh
1. Siapkan 1 sdm garam
1. Sediakan 20 gr kaldu bubuk (setara 2 bks kecil kaldu bubuk)
1. Sediakan 1.5 L air
1. Sediakan  Bumbu halus :
1. Gunakan 3 butir bamer
1. Sediakan 5 butir baput
1. Gunakan 3 butir kemiri
1. Siapkan 1/2 sdt merica
1. Sediakan 2 cm kunyit
1. Siapkan  Bumbu sambal :
1. Gunakan 100 gr kacang tanah
1. Ambil 25 buah cabe rawit merah
1. Siapkan 1.5 keping gula merah
1. Gunakan 1/2 sdt garam
1. Sediakan 5 sdm minyak goreng
1. Gunakan  Bawang goreng untuk taburan (me: lupa pake)
1. Gunakan  Bahan pelengkap :
1. Sediakan  Kerupuk singkong/kerupuk merah
1. Siapkan 1 buah jeruk nipis
1. Gunakan secukupnya Kecap


Terletak di jalan Raya Banyumas-Purwokerto atau Jalan Jenderal Sudirman. Sroto merupakan makanan khas dari sokaraja, Banyumas. Jenis makanan ini adalah sama dengan soto, namun orang Sokaraja menyebutnya dengan sebutan sroto. Soto tersebut memiliki rasa yang khas karena dibubuhi sambal kacang Berbeda dengan soto Semarang atau Solo yang bening, soto khas Banyumas ini berkuah agak keruh. 

##### Cara menyiapkan Sroto Khas Sokaraja:

1. Ulek semua bumbu: duo bawang, kemiri, merica & kunyit sampai halus. Sisihkan.
1. Panaskan minyak goreng, tumis bumbu sampai harum. Masukkan daun salam, daun jeruk, jahe, lengkuas, sereh, cengkeh. Tumis kembali sampai daun layu, baru pindahkan bumbu ke panci yg sdh ada rebusan ayamnya. Masukkan garam, kaldu bubuk & gula merah. Aduk rata & cicipi rasanya. Baru masukkan potongan daun bawang & seledri (sisakan daun bawang saja sekitar 3 sdm untuk taburan).
1. Rebus dl tauge pendek selama 10 menit (untuk menghilangkan bau langunya), matikan api lalu angkat & tiriskan. Untuk sounnya rebus dgn air panas sampai agak lembek, lalu tiriskan.
1. Bahan sambal : goreng kacang sampai kecoklatan (bkn gosong ya), angkat & tiriskan. Lalu cabe jg di goreng sebentar aja (kl bisa pake tutup ya bun tkut meletup), matikan api & tiriskan. Ulek kacang sedikit demi sedikit sampai halus (sisakan 3 sdm untuk taburan di sotonya) & sisihkan. Selanjutnya ulek cabe, setelah agak halus tambahkan gula merah & garam.
1. Setelah halus masukkan kacang uleknya, campur hingga merata. Seperti di gambar ya bun (sesuai selera bunda jg gpp).
1. Untuk sambal, cairkan dgn kuah soto secukupnya (supaya lbh sedap ya bun).
1. Racik bahan ke dlm mangkuk : soun, tauge pendek, potongan daun bawang & kacang goreng. Siram dgn kuah soto, lalu taburi dgn bawang goreng. Tambahkan kecap, jeruk nipis, kerupuk & sambalnya. Sroto sokarajapun siap di santap 🤤


Selain terkenal dengan gethuk gorengnya yang lezat, Sokaraja juga memiliki hidangan soto yang khas dan disukai. Soto sokaraja memiliki bumbu yang lebih beragam. GenPI.co - Konon, Purwokerto memapu membuat orang yang. Resep Soto Sokaraja Khas Banyumas Purwokerto Sederhana Spesial Asli Enak. Soto Sokaraja nama lainnya adalah sroto Banyumas tradisional tersedia pakai daging sapi. 

Gimana nih? Mudah bukan? Itulah cara membuat sroto khas sokaraja yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
