---
description: "WAJIB DICOBA! Inilah Resep Rahasia Sagon bakar Pasti Berhasil"
title: "WAJIB DICOBA! Inilah Resep Rahasia Sagon bakar Pasti Berhasil"
slug: 1448-masakan-sederhana-wajib-dicoba-inilah-resep-rahasia-sagon-bakar-pasti-berhasil
date: 2020-04-24T18:35:19.868Z
image: https://img-global.cpcdn.com/recipes/c6fe9c2c4a0cff53/751x532cq70/sagon-bakar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c6fe9c2c4a0cff53/751x532cq70/sagon-bakar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c6fe9c2c4a0cff53/751x532cq70/sagon-bakar-foto-resep-utama.jpg
author: Phoebe Simpson
ratingvalue: 5
reviewcount: 14
recipeingredient:
- "180 gr kelapa keringsy12 bt kelapa setengah tuakupas parut"
- "250 gr tepung sagu kanji ketan"
- "125 gr gula pasir"
- "75 gr margarin"
- "1 bt telur1 kuning telur"
- "1/4 sdt garam"
- "1 Bks vanili"
- "secukupnya air"
- " resep Nova"
recipeinstructions:
- "Sangrai tepung sampai terasa ringan."
- "Sangrai kelapa sampai kering.kalo pakai kelapa kering jadi,tdk usah disangrai."
- "Masukkan gula,garam,vanili ke kelapa sambil diremas remas."
- "Setelah rata masukkan tepung,aduk rata."
- "Kocok mentega sampai lembut lalu masukkan telur satu persatu,kocok rata."
- "Masukkan adonan tepung ke kocokan mentega.aduk rata pakai spatula.seperti bikin kukis"
- "Cetak adonan.bisa pakai cetakan kuker yang bolong bawahnya,taruh cetakan diloyang lalu isi cetakan dengan adonan,tekan2 sampai padat lalu keluarkan adonan dengan cara di dorong.kalo adonan buyar bisa ditambahkan air sedikit ke adonan tapi jangan sampai lembek.kebanyakan air bikin kue jadi keras."
- "Saya cetak pakai loyang muffin,saya isi kurleb 2 sdm adonan lalu ditekan2.panggang suhu 150 sampai matang,usahakan suhu jangan ketinggian ya karena kue mudah gosong jadi coklat tua.hasil kuenya yang benar tekstur kering,renyah,manis,gurih,warna merata kuning kecoklatan."
- "Keluarkan kue dari loyang muffin dengan cara loyangnya dibalik ke telapak tangan saat sudah dingin.jsngan dicongkel congkel kuenya mudah sekali hancur(dr baca2 lagi ternyata kr kurang kelapanya,pas bikin ini saya kasih sedikit air..hasilnya lebih kokoh dan renyah kuenya).lebih mudah pakai loyang muffin yang satuan daripada yang sambung waktu mengeluarkan kuenya."

categories:
- Resep
tags:
- sagon
- bakar

katakunci: sagon bakar 
nutrition: 136 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dessert

---


![Sagon bakar](https://img-global.cpcdn.com/recipes/c6fe9c2c4a0cff53/751x532cq70/sagon-bakar-foto-resep-utama.jpg)

Sedang mencari ide resep sagon bakar yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal sagon bakar yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sagon bakar, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan sagon bakar enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.

Sagon Bakar Ciaul sangat dikenal karena mempunyai Cita rasa, Gurih, Renyah, dan Lakersnya (SANGAT BERBEDA DARI SAGON BIASANYA & Lainnya). Sagon Bakar \"CIAUL\" terbuat dari bahan-bahan yang berkualitas,sehingga kue yang kami Produksi ini memiliki keunggulan tekstur dan rasa dibandingkan dengan kue yang sejenisnya. Resep Kue Kering Sagon Kelapa Bakar Ketan Sederhana Spesial Renyah Gurih Asli Enak.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat sagon bakar yang siap dikreasikan. Anda dapat membuat Sagon bakar memakai 9 jenis bahan dan 11 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah Sagon bakar:

1. Gunakan 180 gr kelapa kering(sy:1/2 bt kelapa setengah tua,kupas parut)
1. Ambil 250 gr tepung sagu/ kanji/ ketan
1. Siapkan 125 gr gula pasir
1. Ambil 75 gr margarin
1. Siapkan 1 bt telur+1 kuning telur
1. Sediakan 1/4 sdt garam
1. Sediakan 1 Bks vanili
1. Sediakan secukupnya air
1. Sediakan  resep Nova


Cari produk Makanan Instan Kaleng lainnya di Tokopedia. Sagon inggih punika salah satunggaling tetedhan tradhisional khas Jawa Tengah. Ing wekdal rumiyin, kathah tiyang ingkang remen damel sagon kanthi bahan-bahan ingkang prasaja tanpa bahan pengawèt. Онлайн видео TUTORIAL IBU IRMA SAGON BAKAR \'CARA MEMBUAT DODOL AGAR\' — смотреть на imperiya.by. Bar in Ho Chi Minh City, Vietnam. 

##### Cara meracik Sagon bakar:

1. Sangrai tepung sampai terasa ringan.
1. Sangrai kelapa sampai kering.kalo pakai kelapa kering jadi,tdk usah disangrai.
1. Masukkan gula,garam,vanili ke kelapa sambil diremas remas.
1. Setelah rata masukkan tepung,aduk rata.1. Kocok mentega sampai lembut lalu masukkan telur satu persatu,kocok rata.
1. Masukkan adonan tepung ke kocokan mentega.aduk rata pakai spatula.seperti bikin kukis
1. Cetak adonan.bisa pakai cetakan kuker yang bolong bawahnya,taruh cetakan diloyang lalu isi cetakan dengan adonan,tekan2 sampai padat lalu keluarkan adonan dengan cara di dorong.kalo adonan buyar bisa ditambahkan air sedikit ke adonan tapi jangan sampai lembek.kebanyakan air bikin kue jadi keras.
1. Saya cetak pakai loyang muffin,saya isi kurleb 2 sdm adonan lalu ditekan2.panggang suhu 150 sampai matang,usahakan suhu jangan ketinggian ya karena kue mudah gosong jadi coklat tua.hasil kuenya yang benar tekstur kering,renyah,manis,gurih,warna merata kuning kecoklatan.
1. Keluarkan kue dari loyang muffin dengan cara loyangnya dibalik ke telapak tangan saat sudah dingin.jsngan dicongkel congkel kuenya mudah sekali hancur(dr baca2 lagi ternyata kr kurang kelapanya,pas bikin ini saya kasih sedikit air..hasilnya lebih kokoh dan renyah kuenya).lebih mudah pakai loyang muffin yang satuan daripada yang sambung waktu mengeluarkan kuenya.

Sagon bakar dan sagon serbuk yang menjadi makanan ringan pada zaman dahulu telah. Sagon bakar ini berbahan dasar kelapa parut ini menghasilkan rasa yang sangat gurih apalagi ditambah dengan kacang tanah yang juga memiliki rasa gurih. Selain mochi, sagon bakar adalah camilan khas Sukabumi lainnya. Sagon bakar terbuat dari kelapa, aci, dan bahan lainnya. Cocok banget jadi teman ngopi! owl:sameAs. dbpedia-id:Sagon_Bakar. 

Bagaimana? Gampang kan? Itulah cara membuat sagon bakar yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
