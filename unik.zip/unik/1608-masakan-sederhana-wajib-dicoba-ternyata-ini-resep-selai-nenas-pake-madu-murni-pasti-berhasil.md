---
description: "WAJIB DICOBA! Ternyata Ini Resep Selai Nenas Pake Madu Murni Pasti Berhasil"
title: "WAJIB DICOBA! Ternyata Ini Resep Selai Nenas Pake Madu Murni Pasti Berhasil"
slug: 1608-masakan-sederhana-wajib-dicoba-ternyata-ini-resep-selai-nenas-pake-madu-murni-pasti-berhasil
date: 2020-06-28T00:26:57.312Z
image: https://img-global.cpcdn.com/recipes/911932e2f126f781/751x532cq70/selai-nenas-pake-madu-murni-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/911932e2f126f781/751x532cq70/selai-nenas-pake-madu-murni-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/911932e2f126f781/751x532cq70/selai-nenas-pake-madu-murni-foto-resep-utama.jpg
author: Lora Fisher
ratingvalue: 3.5
reviewcount: 13
recipeingredient:
- "2 bh nenas biasa beli di pasar"
- "3 sdm gula pasir"
- "1 sdm madu murnisaya pake merek azzikra"
- "5 bh cengkih"
- "1 ruas kayu manis"
- "Sejumput garam"
recipeinstructions:
- "Siapkan semua bahan.Kupas nenas, matanya jgn dibuang ya...(ini tips dari chef profesional yongki gunawan kl nggak percaya searching aja you tube nya).Mata nenas jika dibuat selai menambah keharuman, kelezatan dan membuat selai bertambah awet.Kalau udah jadi selai tdk akan membuat gatal dilidah.Setelah dicuci bersih diparut ya.Habis diparut lalu diblender.Jgn tambahkan air ya...krn nenas udah mengeluarkan air secara alami."
- "Saya masukkan nenas bersama cengkih&kayu manis kedalam magic com.Saya masak hingga airnya asat aja.Setelah itu saya pindahkan ke teflon.Saya keringkan airnya di teflon.Setelah selai benar2 asat airnya baru saya tambahkan 3 sdm gula pasir.Saya masak hingga lebih kering lagi&udah agak berat jika diaduk.Terakhir sebelum diangkat saya beri 1 sdm madu murni&saya masak hingga 5- 10 menit saja.Lalu saya angkat& dinginkan."
- "Setelah dingin, selai saya bulat2kan.Setelah semua selai habis dibikin bulat2, maka selai siap dibuat nastar.Penambahan 1 sdm madu murni ini selain sebagai pemanis alami jg sbg pengawet alami karena madu murni tidak mengenal masa kadaluarsa atau experidate.Jadi istimewa kan selai kita ini...bisa awet lebih lama.😉😘😍😋"
- "Masih berguru kepada chef Yongki Gunawan maka resep rahasia perbandingan antara selai nenas dan adonan utk kuker nastar maka jika selainya 6 gram, maka adonannya harus 8 gram.Jika selainya 8 gram maka adonannya 10 gram.Saya berencana membuat nastar dgn perbandingan 6 gram utk selai nenasnya dan 8 gram utk adonannya.Maka dari itu selai nenasnya saya timbang dulu sebelum di bulatkan.Tujuan ditimbang agar jika saat dioven akan matangnya serentak, seragam dan merata.Menguntungkan kita hemat wkt😉👌"
categories:
- Resep
tags:
- selai
- nenas
- pake

katakunci: selai nenas pake 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT42M"
recipeyield: "1"
recipecategory: Dinner

---


![Selai Nenas Pake Madu Murni](https://img-global.cpcdn.com/recipes/911932e2f126f781/751x532cq70/selai-nenas-pake-madu-murni-foto-resep-utama.jpg)

Sedang mencari inspirasi resep selai nenas pake madu murni yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal selai nenas pake madu murni yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas pake madu murni, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan selai nenas pake madu murni enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, siapkan selai nenas pake madu murni sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Selai Nenas Pake Madu Murni memakai 6 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat Selai Nenas Pake Madu Murni:

1. Sediakan 2 bh nenas biasa (beli di pasar)
1. Sediakan 3 sdm gula pasir
1. Sediakan 1 sdm madu murni(saya pake merek az-zikra)
1. Ambil 5 bh cengkih
1. Ambil 1 ruas kayu manis
1. Ambil Sejumput garam




##### Cara membuat Selai Nenas Pake Madu Murni:

1. Siapkan semua bahan.Kupas nenas, matanya jgn dibuang ya...(ini tips dari chef profesional yongki gunawan kl nggak percaya searching aja you tube nya).Mata nenas jika dibuat selai menambah keharuman, kelezatan dan membuat selai bertambah awet.Kalau udah jadi selai tdk akan membuat gatal dilidah.Setelah dicuci bersih diparut ya.Habis diparut lalu diblender.Jgn tambahkan air ya...krn nenas udah mengeluarkan air secara alami.
1. Saya masukkan nenas bersama cengkih&kayu manis kedalam magic com.Saya masak hingga airnya asat aja.Setelah itu saya pindahkan ke teflon.Saya keringkan airnya di teflon.Setelah selai benar2 asat airnya baru saya tambahkan 3 sdm gula pasir.Saya masak hingga lebih kering lagi&udah agak berat jika diaduk.Terakhir sebelum diangkat saya beri 1 sdm madu murni&saya masak hingga 5- 10 menit saja.Lalu saya angkat& dinginkan.
1. Setelah dingin, selai saya bulat2kan.Setelah semua selai habis dibikin bulat2, maka selai siap dibuat nastar.Penambahan 1 sdm madu murni ini selain sebagai pemanis alami jg sbg pengawet alami karena madu murni tidak mengenal masa kadaluarsa atau experidate.Jadi istimewa kan selai kita ini...bisa awet lebih lama.😉😘😍😋
1. Masih berguru kepada chef Yongki Gunawan maka resep rahasia perbandingan antara selai nenas dan adonan utk kuker nastar maka jika selainya 6 gram, maka adonannya harus 8 gram.Jika selainya 8 gram maka adonannya 10 gram.Saya berencana membuat nastar dgn perbandingan 6 gram utk selai nenasnya dan 8 gram utk adonannya.Maka dari itu selai nenasnya saya timbang dulu sebelum di bulatkan.Tujuan ditimbang agar jika saat dioven akan matangnya serentak, seragam dan merata.Menguntungkan kita hemat wkt😉👌




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Selai Nenas Pake Madu Murni yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Selamat mencoba!
