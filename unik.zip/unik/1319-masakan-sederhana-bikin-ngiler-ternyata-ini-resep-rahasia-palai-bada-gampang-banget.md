---
description: "BIKIN NGILER! Ternyata Ini Resep Rahasia Palai bada Gampang Banget"
title: "BIKIN NGILER! Ternyata Ini Resep Rahasia Palai bada Gampang Banget"
slug: 1319-masakan-sederhana-bikin-ngiler-ternyata-ini-resep-rahasia-palai-bada-gampang-banget
date: 2020-04-11T19:55:32.929Z
image: https://img-global.cpcdn.com/recipes/eb6e3db67873c0f9/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/eb6e3db67873c0f9/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/eb6e3db67873c0f9/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Gavin Spencer
ratingvalue: 4.4
reviewcount: 4
recipeingredient:
- "1/4 kg badaikan bilisikan yg ukuran kecil"
- "2 siung Bawang putih"
- "5 siung Bawang merah"
- " Kunyit seruas kecil"
- " Jahe seruas kecil"
- "6 buah Cabe"
- "1/2 Kelapa agak muda"
- "2 helai Daun kunyit"
- " Daun ruku2 secukupnya daun kemangi"
- " Garam"
- " Jeruk nipis"
recipeinstructions:
- "Ikan dibersihkan dan di beri garam + jeruk nipis, lalu didiamkan"
- "Bumbu bawang putih,bawang merah,jahe,kunyit dan cabe di haluskan dg gilingan tangan"
- "Kelapa yg di parut di giling ke bumbu sebentar jgn sampai halus"
- "Campurkan dg ikan, daun ruku2 dan iris sedikit daun kunyit."
- "Bungkus dg daun pisang yg dialasi dg daun kunyit."
- "Di bakat, sampai masak kira2 klo sudah hitam daunnya sudah masak."
- "Selamat mencoba bunda..."
categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT34M"
recipeyield: "2"
recipecategory: Dinner

---


![Palai bada](https://img-global.cpcdn.com/recipes/eb6e3db67873c0f9/751x532cq70/palai-bada-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep palai bada yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal palai bada yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.

Palai bada adalah salah satu hidangan yang berasal dari Sumatra Barat. Hidangan ini menggunakan ikan teri sebagai bahan utamanya, yang oleh penduduk setempat disebut dengan \"ikan bada\" atau \"maco bada\" (dalam bentuk ikan asin). Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\".

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari palai bada, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing jika hendak menyiapkan palai bada enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan palai bada sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Palai bada menggunakan 11 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Palai bada:

1. Sediakan 1/4 kg bada/ikan bilis/ikan yg ukuran kecil
1. Gunakan 2 siung Bawang putih
1. Siapkan 5 siung Bawang merah
1. Siapkan  Kunyit seruas kecil
1. Gunakan  Jahe seruas kecil
1. Siapkan 6 buah Cabe
1. Ambil 1/2 Kelapa agak muda
1. Gunakan 2 helai Daun kunyit
1. Gunakan  Daun ruku2 secukupnya/ daun kemangi
1. Siapkan  Garam
1. Ambil  Jeruk nipis


Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. 

##### Cara meracik Palai bada:

1. Ikan dibersihkan dan di beri garam + jeruk nipis, lalu didiamkan
1. Bumbu bawang putih,bawang merah,jahe,kunyit dan cabe di haluskan dg gilingan tangan
1. Kelapa yg di parut di giling ke bumbu sebentar jgn sampai halus
1. Campurkan dg ikan, daun ruku2 dan iris sedikit daun kunyit.
1. Bungkus dg daun pisang yg dialasi dg daun kunyit.
1. Di bakat, sampai masak kira2 klo sudah hitam daunnya sudah masak.
1. Selamat mencoba bunda...


Palai Bada (Pepes Teri Basah) terbuat dari ikan teri basah yang dicampur dengan parutan kelapa, serta beragam bumbu seperti daun kunyit, daun serei, lengkuas, asam, dan lainnya. Semua lagu disini hanya untuk review saja, Jika kamu suka lagu Palai Bada belilah CD original. Yo … palai bada, lamak rasonyo makan baduo Yo … palai bada, lamak rasonyo makan baduo. Urang Rao pai ka danau Ambiak rumpuik si bilang-bilang Yo kok tuan indak picayo Bali sabungkuih baok. Palai Bada sprot met kruiden gegrild in bananenblad. 

Gimana nih? Mudah bukan? Itulah cara menyiapkan palai bada yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
