---
description: "BIKIN NAGIH! Inilah Resep Pensi Bumbu Pandan Gampang Banget"
title: "BIKIN NAGIH! Inilah Resep Pensi Bumbu Pandan Gampang Banget"
slug: 1358-masakan-sederhana-bikin-nagih-inilah-resep-pensi-bumbu-pandan-gampang-banget
date: 2020-06-09T09:54:34.504Z
image: https://img-global.cpcdn.com/recipes/049b6037c27dc95b/751x532cq70/pensi-bumbu-pandan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/049b6037c27dc95b/751x532cq70/pensi-bumbu-pandan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/049b6037c27dc95b/751x532cq70/pensi-bumbu-pandan-foto-resep-utama.jpg
author: Rodney Barber
ratingvalue: 4.7
reviewcount: 3
recipeingredient:
- "2 kg pensi"
- "10 butir bawang merah"
- "3 siung bawang putih"
- "3 cm jahe"
- "3 cm lengkuas"
- "1 cm kunyit"
- "8 bh cabe merah"
- "2 lembar daun kunyit"
- "1 lembar daun salam"
- "1 lembar daun jeruk"
- "1 batang sereh"
- "2 lembar pandan iris tipis"
- "1 batang daun bawang iris"
- "1 sdt air perasan jeruk nipis"
- "200 ml air"
- "Secukupnya garam"
- "Secukupnya minyak utk menumis"
recipeinstructions:
- "Rebus pensi & daun kunyit sampai cangkang nya terbuka. Tiriskan"
- "Haluskan bumbu (kecuali daun-daunan)"
- "Panaskan minyak. Tumis bumbu halus beserta garam & daun-daunan (kecuali pandan & daun bawang)"
- "Tambahkan air jeruk nipis. Masak hingga wangi"
- "Masukkan irisan pandan. Aduk merata"
- "Masukkan pensi rebus tadi. Aduk sampai semua bumbu tercampur merata ke pensi nya"
- "Tambahkan air. Masak hingga air menyusut"
- "Matikan api. Tambahkan daun bawang. Aduk merata"
- "Pensi siap di nikmati ☺☺"
categories:
- Resep
tags:
- pensi
- bumbu
- pandan

katakunci: pensi bumbu pandan 
nutrition: 216 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT57M"
recipeyield: "2"
recipecategory: Dinner

---


![Pensi Bumbu Pandan](https://img-global.cpcdn.com/recipes/049b6037c27dc95b/751x532cq70/pensi-bumbu-pandan-foto-resep-utama.jpg)

Sedang mencari ide resep pensi bumbu pandan yang unik? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pensi bumbu pandan yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari pensi bumbu pandan, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan pensi bumbu pandan yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah pensi bumbu pandan yang siap dikreasikan. Anda dapat menyiapkan Pensi Bumbu Pandan memakai 17 jenis bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Pensi Bumbu Pandan:

1. Sediakan 2 kg pensi
1. Siapkan 10 butir bawang merah
1. Sediakan 3 siung bawang putih
1. Siapkan 3 cm jahe
1. Siapkan 3 cm lengkuas
1. Gunakan 1 cm kunyit
1. Siapkan 8 bh cabe merah
1. Ambil 2 lembar daun kunyit
1. Sediakan 1 lembar daun salam
1. Sediakan 1 lembar daun jeruk
1. Ambil 1 batang sereh
1. Sediakan 2 lembar pandan (iris tipis)
1. Gunakan 1 batang daun bawang (iris)
1. Siapkan 1 sdt air perasan jeruk nipis
1. Gunakan 200 ml air
1. Siapkan Secukupnya garam
1. Sediakan Secukupnya minyak utk menumis




##### Langkah-langkah membuat Pensi Bumbu Pandan:

1. Rebus pensi & daun kunyit sampai cangkang nya terbuka. Tiriskan
1. Haluskan bumbu (kecuali daun-daunan)
1. Panaskan minyak. Tumis bumbu halus beserta garam & daun-daunan (kecuali pandan & daun bawang)
1. Tambahkan air jeruk nipis. Masak hingga wangi
1. Masukkan irisan pandan. Aduk merata
1. Masukkan pensi rebus tadi. Aduk sampai semua bumbu tercampur merata ke pensi nya
1. Tambahkan air. Masak hingga air menyusut
1. Matikan api. Tambahkan daun bawang. Aduk merata
1. Pensi siap di nikmati ☺☺




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Pensi Bumbu Pandan yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi ide dalam berbisnis kuliner. Selamat mencoba!
