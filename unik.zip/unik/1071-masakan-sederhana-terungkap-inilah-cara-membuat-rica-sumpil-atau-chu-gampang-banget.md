---
description: "TERUNGKAP! Inilah Cara Membuat Rica Sumpil atau Chu Gampang Banget"
title: "TERUNGKAP! Inilah Cara Membuat Rica Sumpil atau Chu Gampang Banget"
slug: 1071-masakan-sederhana-terungkap-inilah-cara-membuat-rica-sumpil-atau-chu-gampang-banget
date: 2020-06-19T08:06:29.235Z
image: https://img-global.cpcdn.com/recipes/6131e7a558c77aef/751x532cq70/rica-sumpil-atau-chu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6131e7a558c77aef/751x532cq70/rica-sumpil-atau-chu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6131e7a558c77aef/751x532cq70/rica-sumpil-atau-chu-foto-resep-utama.jpg
author: Dale Barton
ratingvalue: 4.3
reviewcount: 8
recipeingredient:
- "1 kg sumpil atau chu rendam semalaman cuci bersih lalu rebus"
- "8 siung bawang putih"
- "10 siung bawang merah"
- "250 gr cabe rawit setan"
- "250 gr cabe keriting"
- "1 ruas lengkuas geprek"
- "2 buah serai"
- "2 lembar daun salam"
- "5 lembar Daun jeruk"
- "2 butir kemiri"
- "1 ruas jahe geprek"
- "secukupnya Garam"
- "secukupnya Merica"
- " Minyak untuk menumis"
- "1 liter air"
recipeinstructions:
- "Haluskan semua bumbu, kecuali serai, daun salam, daun jeruk dan lengkuas"
- "Panaskan minyak, tumis bumbu halus sampai harum, kemudian masukkan serai, daun salam, daun jeruk dan lengkuas. Tunggu hingga berwarna keemasan"
- "Tambahkan air dan tunggu hingga mendidih, kemudian masukkan sumpil atau chu yang sudah direbus terlebih dahulu."
- "Masak hingga air sedikit meresap kedalam sumpil."
- "Sajikan dengan nasi panas"
categories:
- Resep
tags:
- rica
- sumpil
- atau

katakunci: rica sumpil atau 
nutrition: 198 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Rica Sumpil atau Chu](https://img-global.cpcdn.com/recipes/6131e7a558c77aef/751x532cq70/rica-sumpil-atau-chu-foto-resep-utama.jpg)

Sedang mencari inspirasi resep rica sumpil atau chu yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal rica sumpil atau chu yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari rica sumpil atau chu, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing jika mau menyiapkan rica sumpil atau chu yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah rica sumpil atau chu yang siap dikreasikan. Anda dapat membuat Rica Sumpil atau Chu memakai 15 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk meracik Rica Sumpil atau Chu:

1. Ambil 1 kg sumpil atau chu (rendam semalaman, cuci bersih, lalu rebus)
1. Gunakan 8 siung bawang putih
1. Gunakan 10 siung bawang merah
1. Gunakan 250 gr cabe rawit setan
1. Sediakan 250 gr cabe keriting
1. Gunakan 1 ruas lengkuas, geprek
1. Gunakan 2 buah serai
1. Siapkan 2 lembar daun salam
1. Gunakan 5 lembar Daun jeruk
1. Ambil 2 butir kemiri
1. Siapkan 1 ruas jahe, geprek
1. Gunakan secukupnya Garam
1. Ambil secukupnya Merica
1. Gunakan  Minyak untuk menumis
1. Ambil 1 liter air




##### Langkah-langkah menyiapkan Rica Sumpil atau Chu:

1. Haluskan semua bumbu, kecuali serai, daun salam, daun jeruk dan lengkuas
1. Panaskan minyak, tumis bumbu halus sampai harum, kemudian masukkan serai, daun salam, daun jeruk dan lengkuas. Tunggu hingga berwarna keemasan
1. Tambahkan air dan tunggu hingga mendidih, kemudian masukkan sumpil atau chu yang sudah direbus terlebih dahulu.
1. Masak hingga air sedikit meresap kedalam sumpil.
1. Sajikan dengan nasi panas




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Rica Sumpil atau Chu yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
