---
description: "RECOMMENDED! Inilah Cara Membuat Pentol mercon banget suwerrr ✌️🔥 Anti Gagal"
title: "RECOMMENDED! Inilah Cara Membuat Pentol mercon banget suwerrr ✌️🔥 Anti Gagal"
slug: 1831-masakan-sederhana-recommended-inilah-cara-membuat-pentol-mercon-banget-suwerrr-anti-gagal
date: 2020-05-20T01:51:09.375Z
image: https://img-global.cpcdn.com/recipes/cff9201c4165f226/751x532cq70/pentol-mercon-banget-suwerrr-✌️🔥-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cff9201c4165f226/751x532cq70/pentol-mercon-banget-suwerrr-✌️🔥-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cff9201c4165f226/751x532cq70/pentol-mercon-banget-suwerrr-✌️🔥-foto-resep-utama.jpg
author: Marvin Pearson
ratingvalue: 4.4
reviewcount: 8
recipeingredient:
- "1/2 kg pentol dipotong dua"
- "2 bawang putih"
- "4 bawang merah"
- "1/2 sdm kemiri bubuk"
- "15-20 cabe rawit sesuai selera"
- "2 cabe merah jawa"
- "2 sdm gula merah jawa"
- "1 sdm garam"
- " roycomasako sebagai penyedap rasa"
- "1/2 sdm merica bubuk"
- "1 lengkuassereh"
- "2 daun jeruk"
recipeinstructions:
- "Haluskan semua bahan td kecuali lengkuas dan daun jeruk"
- "Setelah halus, tumis ke atas wajan dengan minyak sedikit aja tdk banyak"
- "Tunggu hingga kecoklatan, setelah itu masukan pentol,"
- "Jgn lupa masukan lengkuas yang sudah di geprek dan daun jeruk yg sudah di sobek biar tambah cita rasannya"
- "Tunggu hingga bumbu bener bener meresap"
categories:
- Resep
tags:
- pentol
- mercon
- banget

katakunci: pentol mercon banget 
nutrition: 259 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT38M"
recipeyield: "1"
recipecategory: Lunch

---


![Pentol mercon banget suwerrr ✌️🔥](https://img-global.cpcdn.com/recipes/cff9201c4165f226/751x532cq70/pentol-mercon-banget-suwerrr-✌️🔥-foto-resep-utama.jpg)

Sedang mencari inspirasi resep pentol mercon banget suwerrr ✌️🔥 yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal pentol mercon banget suwerrr ✌️🔥 yang enak seharusnya memiliki aroma dan rasa yang bisa memancing selera kita.

Haii hari ini aku masak pentol bakso mercon Aduuuh ini pedeeessss banget banget banget !! Tp ketagihan sih hehe Disini aku haluskan bumbunya pake chopper. Hai gaess.terima kasih udah selalu nonton n mendukung channelku.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari pentol mercon banget suwerrr ✌️🔥, mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan pentol mercon banget suwerrr ✌️🔥 enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat pentol mercon banget suwerrr ✌️🔥 sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Pentol mercon banget suwerrr ✌️🔥 menggunakan 12 bahan dan 5 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk mengolah Pentol mercon banget suwerrr ✌️🔥:

1. Siapkan 1/2 kg pentol (dipotong dua)
1. Gunakan 2 bawang putih
1. Sediakan 4 bawang merah
1. Gunakan 1/2 sdm kemiri bubuk
1. Siapkan 15-20 cabe rawit (sesuai selera)
1. Ambil 2 cabe merah jawa
1. Gunakan 2 sdm gula merah jawa
1. Sediakan 1 sdm garam
1. Sediakan  royco/masako sebagai penyedap rasa
1. Ambil 1/2 sdm merica bubuk
1. Siapkan 1 lengkuas/sereh
1. Siapkan 2 daun jeruk


Pentol atau bakso jadi salah satu makanan favorit sebagian besar orang Indonesia. Dimakan langsung pun enak, tanpa bahan-bahan pelengkap dalam semangkuk bakso. Namun, tak semua penjual membuatnya dengan bahan-bahan yang higienis dan benar. TRIBUNNEWS,COM - Berikut ini resep dan cara membuat bakso cilok atau pentol mercon yang mudah dan anti gagal. 

##### Langkah-langkah membuat Pentol mercon banget suwerrr ✌️🔥:

1. Haluskan semua bahan td kecuali lengkuas dan daun jeruk
1. Setelah halus, tumis ke atas wajan dengan minyak sedikit aja tdk banyak
1. Tunggu hingga kecoklatan, setelah itu masukan pentol,
1. Jgn lupa masukan lengkuas yang sudah di geprek dan daun jeruk yg sudah di sobek biar tambah cita rasannya
1. Tunggu hingga bumbu bener bener meresap


Masakan ini bisa dilakukan di rumah dengan bahan dan alat sederhana. BoB yg suka makan akan membagikan tutorial mengolah makanan sehat untuk teman teman berbagai kalangan dan makanan sederhana untuk anak kost khas indonesia. Merapat merapat anak kost dan ibu ibu muda HoHoBo. Tekstur pentol yang kenyal dan ditambah dengan rasa bumbu mercon yang super pedas membuat camilan pentol mercon begitu dinikmati. Adanya kreasi baru pentol mercon ternyata tak hanya menarik bagi anak-anak dan remaja, tapi juga orang dewasa. 

Bagaimana? Gampang kan? Itulah cara membuat pentol mercon banget suwerrr ✌️🔥 yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
