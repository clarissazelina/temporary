---
description: "WAJIB DICOBA! Inilah Cara Membuat Gulali Tepung Enak"
title: "WAJIB DICOBA! Inilah Cara Membuat Gulali Tepung Enak"
slug: 1194-masakan-sederhana-wajib-dicoba-inilah-cara-membuat-gulali-tepung-enak
date: 2020-09-19T17:10:09.967Z
image: https://img-global.cpcdn.com/recipes/24e5ae6848fc9c66/751x532cq70/gulali-tepung-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/24e5ae6848fc9c66/751x532cq70/gulali-tepung-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/24e5ae6848fc9c66/751x532cq70/gulali-tepung-foto-resep-utama.jpg
author: Mike Casey
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "200 gr tepung ketan"
- "100 gr gula pasir"
- "80 gr air"
- "1/8 sdt sitrunair jeruk nipis saya pakai sitrun"
- "1 tetes perasa makanan favorit saya pakai perasa stroberi"
recipeinstructions:
- "Sangrai tepung ketan selama 10 menit. Sisihkan dan dinginkan hingga suhu ruang. Taruh di dalam wadah yang lebar."
- "Siapkan 2 wajan teflon. Satu untuk memasak gulali, satu lagi untuk mendinginkan gulali. Wajan yg untuk mendinginkan gulali sebaiknya sambil direndam dengan air"
- "Masak gulali. Tuang gula, air, sitrun, dan pewarna ke dalam wajan. Masak dengan api sedang dan sambil diaduk hingga gula larut."
- "Masak hingga larutan gula mengental tanpa diaduk. Gulali yang berhasil adalah gulali yang sudah berbuih. Dan jika api dimatikan, maka buihnya akan agak lama hilang meskipun sambil diaduk-aduk."
- "Jika sudah berbuih, matikan api, aduk-aduk sampai buih hilang dan menjadi larutan jernih. Lalu cepat tuang gulali ke wajan pendingin."
- "Di dalam wajan pendingin, aduk gulali hingga menjadi satu adonan."
- "Jika sudah dingin sesuai dengan suhu ruang. Pindahkan gulali ke dalam tepung ketan."
- "Di dalam tepung ketan. Buat gulali menjadi seperti donat, tarik, lalu buat menjadi angka 8. Tarik. Lumuri tepung, buat angka 8 lagi, begitu seterusnya hingga gulali menjadi setipis rambut."

categories:
- Resep
tags:
- gulali
- tepung

katakunci: gulali tepung 
nutrition: 202 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT34M"
recipeyield: "1"
recipecategory: Dinner

---


![Gulali Tepung](https://img-global.cpcdn.com/recipes/24e5ae6848fc9c66/751x532cq70/gulali-tepung-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gulali tepung yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal gulali tepung yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gulali tepung, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan gulali tepung yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, variasikan gulali tepung sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gulali Tepung menggunakan 5 jenis bahan dan 9 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Gulali Tepung:

1. Sediakan 200 gr tepung ketan
1. Sediakan 100 gr gula pasir
1. Sediakan 80 gr air
1. Siapkan 1/8 sdt sitrun/air jeruk nipis (saya pakai sitrun)
1. Ambil 1 tetes perasa makanan favorit (saya pakai perasa stroberi)




##### Langkah-langkah meracik Gulali Tepung:

1. Sangrai tepung ketan selama 10 menit. Sisihkan dan dinginkan hingga suhu ruang. Taruh di dalam wadah yang lebar.
1. Siapkan 2 wajan teflon. Satu untuk memasak gulali, satu lagi untuk mendinginkan gulali. Wajan yg untuk mendinginkan gulali sebaiknya sambil direndam dengan air
1. Masak gulali. Tuang gula, air, sitrun, dan pewarna ke dalam wajan. Masak dengan api sedang dan sambil diaduk hingga gula larut.
1. Masak hingga larutan gula mengental tanpa diaduk. Gulali yang berhasil adalah gulali yang sudah berbuih. Dan jika api dimatikan, maka buihnya akan agak lama hilang meskipun sambil diaduk-aduk.
1. Jika sudah berbuih, matikan api, aduk-aduk sampai buih hilang dan menjadi larutan jernih. Lalu cepat tuang gulali ke wajan pendingin.
1. Di dalam wajan pendingin, aduk gulali hingga menjadi satu adonan.
1. Jika sudah dingin sesuai dengan suhu ruang. Pindahkan gulali ke dalam tepung ketan.
1. Di dalam tepung ketan. Buat gulali menjadi seperti donat, tarik, lalu buat menjadi angka 8. Tarik. Lumuri tepung, buat angka 8 lagi, begitu seterusnya hingga gulali menjadi setipis rambut.



Bagaimana? Gampang kan? Itulah cara menyiapkan gulali tepung yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
