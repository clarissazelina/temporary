---
description: "BIKIN NGILER! Inilah Cara Membuat Cucur Betawi Bersarang "
title: "BIKIN NGILER! Inilah Cara Membuat Cucur Betawi Bersarang "
slug: 1838-masakan-sederhana-bikin-ngiler-inilah-cara-membuat-cucur-betawi-bersarang
date: 2020-09-29T04:20:01.515Z
image: https://img-global.cpcdn.com/recipes/210ae7f96596fd46/751x532cq70/cucur-betawi-bersarang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/210ae7f96596fd46/751x532cq70/cucur-betawi-bersarang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/210ae7f96596fd46/751x532cq70/cucur-betawi-bersarang-foto-resep-utama.jpg
author: Mabel Weber
ratingvalue: 3.9
reviewcount: 9
recipeingredient:
- "220 gr tepung beras"
- "150 gr terigu saya pakai segitiga"
- "250 gr gula merah"
- "100 gr gula pasir"
- "1/2 sdt garam"
- "600 ml air matang"
- "2 lembar daun pandan"
recipeinstructions:
- "Rebus gula merah, gula pasir, garam dan daun pandan dalam air, setelah mendidih dan gula larut tunggu hingga hangat kuku kemudian saring"
- "Masukkan tepung terigu dan tepung beras ke dalam wadah aduk merata kemudian masukkan air gula sedikit demi sedikit (jangan semua, hingga adonan cukup kekentalannya saja) aduk hingga merata"
- "Mixer adonan dgn kecepatan rendah selama 5 menit kemudian saring dan isitirahatkan adonan dgn ditutup kain selama 1-2jam (saya cm 1jam)"
- "Setelah itu aduk adonan secara merata kalau terlalu kental masukkan kembali sisa air gula tadi (saya lbh suka kondisi adonan agak cair dan tidak terlalu kental karna hasilnya jd lbh empuk tdk terlalu tebal dan pinggiran garing)"
- "Panaskan minyak goreng secukupnya dalam wajan cekung (minyak jgn terlalu banyak) dengan api sedang masukkan adonan menggunakan sendok sayur, tunggu hingga adonan bersarang hingga ke tengah kemudian siram2 minyak (jika tdk ada lg adonan keluar artinya sdh matang) ketika pinggiran sdh agak kecoklatan boleh dibalik sebentar lalu angkat"
- "Siap dihidangkan (jika kue cucur tebal dan keras artinya terlalu kental, boleh ditambahnkan air, kalau saya tambahkan air gula merah agar manis tidak berubah)"
- "Sisa adonan saya taro dikulkas besoknya saya goreng lg dgn menambahkan air gula, hasilnya jauh lbh enak... jd semakin lama adonan di istirahatkan hasil jg semakin enak ya.."
categories:
- Resep
tags:
- cucur
- betawi
- bersarang

katakunci: cucur betawi bersarang 
nutrition: 186 calories
recipecuisine: Indonesian
preptime: "PT40M"
cooktime: "PT52M"
recipeyield: "3"
recipecategory: Lunch

---


![Cucur Betawi Bersarang](https://img-global.cpcdn.com/recipes/210ae7f96596fd46/751x532cq70/cucur-betawi-bersarang-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep cucur betawi bersarang yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal cucur betawi bersarang yang enak seharusnya mempunyai aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cucur betawi bersarang, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan cucur betawi bersarang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, siapkan cucur betawi bersarang sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Cucur Betawi Bersarang menggunakan 7 jenis bahan dan 7 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Cucur Betawi Bersarang:

1. Gunakan 220 gr tepung beras
1. Ambil 150 gr terigu (saya pakai segitiga)
1. Ambil 250 gr gula merah
1. Gunakan 100 gr gula pasir
1. Siapkan 1/2 sdt garam
1. Ambil 600 ml air matang
1. Gunakan 2 lembar daun pandan




##### Cara meracik Cucur Betawi Bersarang:

1. Rebus gula merah, gula pasir, garam dan daun pandan dalam air, setelah mendidih dan gula larut tunggu hingga hangat kuku kemudian saring
1. Masukkan tepung terigu dan tepung beras ke dalam wadah aduk merata kemudian masukkan air gula sedikit demi sedikit (jangan semua, hingga adonan cukup kekentalannya saja) aduk hingga merata
1. Mixer adonan dgn kecepatan rendah selama 5 menit kemudian saring dan isitirahatkan adonan dgn ditutup kain selama 1-2jam (saya cm 1jam)
1. Setelah itu aduk adonan secara merata kalau terlalu kental masukkan kembali sisa air gula tadi (saya lbh suka kondisi adonan agak cair dan tidak terlalu kental karna hasilnya jd lbh empuk tdk terlalu tebal dan pinggiran garing)
1. Panaskan minyak goreng secukupnya dalam wajan cekung (minyak jgn terlalu banyak) dengan api sedang masukkan adonan menggunakan sendok sayur, tunggu hingga adonan bersarang hingga ke tengah kemudian siram2 minyak (jika tdk ada lg adonan keluar artinya sdh matang) ketika pinggiran sdh agak kecoklatan boleh dibalik sebentar lalu angkat
1. Siap dihidangkan (jika kue cucur tebal dan keras artinya terlalu kental, boleh ditambahnkan air, kalau saya tambahkan air gula merah agar manis tidak berubah)
1. Sisa adonan saya taro dikulkas besoknya saya goreng lg dgn menambahkan air gula, hasilnya jauh lbh enak... jd semakin lama adonan di istirahatkan hasil jg semakin enak ya..




Bagaimana? Gampang kan? Itulah cara menyiapkan cucur betawi bersarang yang bisa Anda lakukan di rumah. Selamat mencoba!
