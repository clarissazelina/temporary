---
description: "BIKIN NGILER! Inilah Resep Rahasia Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon Anti Gagal"
title: "BIKIN NGILER! Inilah Resep Rahasia Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon Anti Gagal"
slug: 160-masakan-sederhana-bikin-ngiler-inilah-resep-rahasia-makanan-khas-cirebontahu-gejrot-khas-cirebon-anti-gagal
date: 2020-05-28T04:16:56.458Z
image: https://img-global.cpcdn.com/recipes/ef41ef217af3606d/751x532cq70/makanan-khas-cirebontahu-gejrot-khas-cirebon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef41ef217af3606d/751x532cq70/makanan-khas-cirebontahu-gejrot-khas-cirebon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef41ef217af3606d/751x532cq70/makanan-khas-cirebontahu-gejrot-khas-cirebon-foto-resep-utama.jpg
author: Eunice Norman
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- "5 buah tahu Sumedang goreng boleh lebih ya"
- "4 siung bawang merah"
- "3 buah caberawit merah boleh lebih"
- "4 buah cabe rawit hijau boleh lebih"
- " Bahan Kuah "
- "200 ml air"
- "Secukupnya gula merah kecap  asam"
recipeinstructions:
- "Siapkan semua bahan, rebus bahan kuah"
- "Ulek kasar cabai & bawang merah"
- "Potong2 tahu nya, letakkan ulekan cabai bawang diatasnya kemudian siram dg kuah. Jadi deh, simpel kan hihi"
- "Tahu Gejrot Khas Cirebon siap dihidangkan 😍"
categories:
- Resep
tags:
- makanan
- khas
- cirebontahu

katakunci: makanan khas cirebontahu 
nutrition: 254 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

---


![Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon](https://img-global.cpcdn.com/recipes/ef41ef217af3606d/751x532cq70/makanan-khas-cirebontahu-gejrot-khas-cirebon-foto-resep-utama.jpg)

Anda sedang mencari ide resep makanan khas cirebon~tahu gejrot khas cirebon yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal makanan khas cirebon~tahu gejrot khas cirebon yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari makanan khas cirebon~tahu gejrot khas cirebon, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan makanan khas cirebon~tahu gejrot khas cirebon enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.

Makanan khas yang bisa dianggap sebagai makanan ringan ini, diguyur dengan bumbu yang berasal dari campuran bawang putih, bawang merah, gula merah, dan juga cabai yang dihaluskan. Jika Anda penasaran dengan Tahu Gejrot, Anda bisa mencobanya saat mampir di kota Cirebon. Tahu gejrot adalah makanan khas cirebon terdiri dari bahan tahu, bawang merah/putih, cabe hijau, garam, gula merah dan kuah..


Nah, kali ini kita coba, yuk, siapkan makanan khas cirebon~tahu gejrot khas cirebon sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon memakai 7 bahan dan 4 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon:

1. Sediakan 5 buah tahu Sumedang goreng (boleh lebih ya)
1. Ambil 4 siung bawang merah
1. Siapkan 3 buah caberawit merah (boleh lebih)
1. Ambil 4 buah cabe rawit hijau (boleh lebih)
1. Gunakan  Bahan Kuah :
1. Siapkan 200 ml air
1. Siapkan Secukupnya gula merah, kecap & asam


Resep makanan ringan khas kota Cirebon ini identik dengan penggunaan tahu kopong yang dibanjur dengan kuah asam manis pedas yang sangat unik dan khas rasanya. Rupanya tidak sulit membuat camilan ini di dapur sendiri. Selain bisa memastikan kehigienisannya, tahu gejrot buatan Anda juga. Selain dari Cirebon, tahu gejrot juga ada yang khas Bandung. 

##### Cara mengolah Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon:

1. Siapkan semua bahan, rebus bahan kuah
1. Ulek kasar cabai & bawang merah
1. Potong2 tahu nya, letakkan ulekan cabai bawang diatasnya kemudian siram dg kuah. Jadi deh, simpel kan hihi
1. Tahu Gejrot Khas Cirebon siap dihidangkan 😍


Makanan ringan yang berbahan dasar tahu ini menjadi salah satu makanan yang Antara tahu gejrot Cirebon dan Bandung, tentu saja terdapat perbedaan yang terletak pada bahan-bahan yang digunakan untuk membuat tahu gejrot ini. Selebihnya, tahu-tahu yang sudah dipotong akan dicampur bersama bumbu yang dihaluskan tersebut dan disiram kuah khas tahu gejrot yang terbuat dari kecap manis dan gula merah ini. Tekstur tahu yang kopong ini menjadikan kudapan begitu juicy dan sedap, hingga tak terasa keringat mulai. Makanan khas Cirebon yang satu ini memang sangat lekat dengan kota asalnya. Nah, Tahu Gejrot biasanya disajikan menggunakan cobek berukuran kecil Makanan khas Cirebon yang selanjutnya adalah Pedesan Entog yang berasal dari daerah Indramayu. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Makanan Khas Cirebon~Tahu Gejrot Khas Cirebon yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
