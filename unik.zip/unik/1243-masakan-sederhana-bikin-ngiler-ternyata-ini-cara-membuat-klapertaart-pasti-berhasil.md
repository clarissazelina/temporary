---
description: "BIKIN NGILER! Ternyata Ini Cara Membuat Klapertaart Pasti Berhasil"
title: "BIKIN NGILER! Ternyata Ini Cara Membuat Klapertaart Pasti Berhasil"
slug: 1243-masakan-sederhana-bikin-ngiler-ternyata-ini-cara-membuat-klapertaart-pasti-berhasil
date: 2020-09-16T02:21:10.693Z
image: https://img-global.cpcdn.com/recipes/2bfb1802cfc7a012/751x532cq70/klapertaart-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2bfb1802cfc7a012/751x532cq70/klapertaart-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2bfb1802cfc7a012/751x532cq70/klapertaart-foto-resep-utama.jpg
author: Roxie Bennett
ratingvalue: 3.4
reviewcount: 5
recipeingredient:
- "2 buah daging kelapa sedang"
- "500 ml air kelapa"
- "500 ml susu UHT"
- "120 gr gula pasirsesuai selera"
- "3 sact SKMsesuai selera"
- "100 gr kismis"
- "100 gr kacang kenari sangrai"
- "1 sdt rumvanilla"
- "3 buah kuning telur"
- "50 gr buttermargarin"
- "Secukupnya kacang almond"
- " Bahan pengental"
- "4 sdm tepung maizena"
- "3 sdm tepung trigu"
- " Bahan lapis meringue"
- "3 putih telur"
- "Sejumput cream of tartar"
- "2 sdm gula pasir"
- "Secukupnya bubuk cinnamon utk taburan"
recipeinstructions:
- "Masukan air kelapa+susu UHT+ gula+ SKM ke dlm panci msk dg api sedang, di tmpt lain campur bahan pengental bersama kuning telur aduk hingga rata Dan mskn ke dlm panci air klapa. Aduk hingga tercampur rata Dan tdk Ada yg bergerindil."
- "Masak hingga mengental matang dan meletup\" matikan kompor Lalu mskn butter+ daging klapa+ kismis+kacang kenari."
- "Mskn kedalam loyang, diamkan hingga uap hilang dan agak dingin. Setelah itu kocok Bahan meringue sampai soft peak, bila adonan di loyang sdh dingin lapisin dgn meringue hingga tertutup rata. Lalu beri taburan cinnamon bubuk+ kismis Dan almond."
- "Panggang sebentar dg api atas hingga bagian atas meringue kecoklatan Dan almond berubah warna sktr 20mnt dg api 150-160 delcel. Kluarkan dr oven Dan sajikan, lbh enak lg disimpan dahulu stgh Hari dikulkas Lalu disajikan dlm keadaan dingin... Hhhmmmm lumerrr dimulutt😋pgn lagi Dan lagi"
categories:
- Resep
tags:
- klapertaart

katakunci: klapertaart 
nutrition: 267 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT49M"
recipeyield: "2"
recipecategory: Dessert

---


![Klapertaart](https://img-global.cpcdn.com/recipes/2bfb1802cfc7a012/751x532cq70/klapertaart-foto-resep-utama.jpg)

Lagi mencari ide resep klapertaart yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal klapertaart yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari klapertaart, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan klapertaart enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.

Klappertaart-kun (Also known as Klapper) is one of the Desserts from Dessert Anime. He is a gijinka of the Dessert Klappertaart and was made by the tumblr used Hika (She does not have a main blog). He is a homemade dessert, and has a very close relation to his baker.


Nah, kali ini kita coba, yuk, siapkan klapertaart sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Klapertaart menggunakan 19 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Klapertaart:

1. Siapkan 2 buah daging kelapa sedang
1. Sediakan 500 ml air kelapa
1. Sediakan 500 ml susu UHT
1. Gunakan 120 gr gula pasir/sesuai selera
1. Siapkan 3 sact SKM/sesuai selera
1. Siapkan 100 gr kismis
1. Ambil 100 gr kacang kenari sangrai
1. Ambil 1 sdt rum/vanilla
1. Gunakan 3 buah kuning telur
1. Gunakan 50 gr butter/margarin
1. Siapkan Secukupnya kacang almond
1. Siapkan  Bahan pengental:
1. Gunakan 4 sdm tepung maizena
1. Gunakan 3 sdm tepung trigu
1. Siapkan  Bahan lapis meringue:
1. Sediakan 3 putih telur
1. Sediakan Sejumput cream of tartar
1. Sediakan 2 sdm gula pasir
1. Siapkan Secukupnya bubuk cinnamon utk taburan


Klappertaart is a Dutch-influenced Indonesian cake originating from Manado, North Sulawesi. Want to discover art related to klappertaart? Check out inspiring examples of klappertaart artwork on DeviantArt, and get inspired by our community of talented artists. klappertaart. Klappertaart or coconut custard Klappertaart is a Dutch-influenced Indonesian cake originating from Manado, North Sulawesi. 

##### Langkah-langkah meracik Klapertaart:

1. Masukan air kelapa+susu UHT+ gula+ SKM ke dlm panci msk dg api sedang, di tmpt lain campur bahan pengental bersama kuning telur aduk hingga rata Dan mskn ke dlm panci air klapa. Aduk hingga tercampur rata Dan tdk Ada yg bergerindil.
1. Masak hingga mengental matang dan meletup\" matikan kompor Lalu mskn butter+ daging klapa+ kismis+kacang kenari.
1. Mskn kedalam loyang, diamkan hingga uap hilang dan agak dingin. Setelah itu kocok Bahan meringue sampai soft peak, bila adonan di loyang sdh dingin lapisin dgn meringue hingga tertutup rata. Lalu beri taburan cinnamon bubuk+ kismis Dan almond.
1. Panggang sebentar dg api atas hingga bagian atas meringue kecoklatan Dan almond berubah warna sktr 20mnt dg api 150-160 delcel. Kluarkan dr oven Dan sajikan, lbh enak lg disimpan dahulu stgh Hari dikulkas Lalu disajikan dlm keadaan dingin... Hhhmmmm lumerrr dimulutt😋pgn lagi Dan lagi


Klappertaart is a Dutch-influenced Indonesian cake originating from Manado, North Sulawesi. For faster navigation, this Iframe is preloading the Wikiwand page for Klappertaart. Klappertaart is a Dutch-influenced Indonesian cake originating from Manado, North Sulawesi. Meskipun lebih dikenal sebagai kuliner Manado, klappertaart punya sejarah panjang kolonial di baliknya. de\'Gaav Klappertaart. Make a packaging design of three different flavors of klappertaart to increase the sales. 

Gimana nih? Gampang kan? Itulah cara membuat klapertaart yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
