---
description: "BIKIN NAGIH! Inilah Resep Rahasia Pentol Mercon Enak Bgt😆 Enak"
title: "BIKIN NAGIH! Inilah Resep Rahasia Pentol Mercon Enak Bgt😆 Enak"
slug: 1822-masakan-sederhana-bikin-nagih-inilah-resep-rahasia-pentol-mercon-enak-bgt-enak
date: 2020-04-14T17:38:55.853Z
image: https://img-global.cpcdn.com/recipes/073799629b197b44/751x532cq70/pentol-mercon-enak-bgt😆-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/073799629b197b44/751x532cq70/pentol-mercon-enak-bgt😆-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/073799629b197b44/751x532cq70/pentol-mercon-enak-bgt😆-foto-resep-utama.jpg
author: Jeremiah Pearson
ratingvalue: 4.4
reviewcount: 4
recipeingredient:
- "30 pentol ayam kira2"
- "10 bawang merah"
- "6 bawang putih"
- "3 butir kemiri"
- "8 cabe keriting"
- "10 cabe rawit opsionalbisa tambah bisa kurang"
- "1 ruas lengkuas"
- "3 lembar daun jeruk"
- "secukupnya Kaldu bubuk"
- "secukupnya Gula"
- "secukupnya Garam"
- " Kecap dikit ajaa"
recipeinstructions:
- "Siapkan bahan. Aku goreng bentar pentolnya tp ga garing2 bgt. Lalu blender bumbu kecuali serai, daun jeruk, lengkuas."
- "Masukkan bumbu halus, serai, lengkuas dan daun jeruk kemudian masukkan pentol ayam aduk sampai rata. Masukkan sedikit air, garam, kaldu, gula, kecap. Koreksi rasa"
- "Dan taraaaaa. Langsung cusss ambil nasi wkwkwwwk, enak bgtt pke kerupuk trus nasinya panassss😭😭😭cobain buibuuuu"
categories:
- Resep
tags:
- pentol
- mercon
- enak

katakunci: pentol mercon enak 
nutrition: 120 calories
recipecuisine: Indonesian
preptime: "PT16M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dessert

---


![Pentol Mercon Enak Bgt😆](https://img-global.cpcdn.com/recipes/073799629b197b44/751x532cq70/pentol-mercon-enak-bgt😆-foto-resep-utama.jpg)

Anda sedang mencari ide resep pentol mercon enak bgt😆 yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal pentol mercon enak bgt😆 yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari pentol mercon enak bgt😆, pertama dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan pentol mercon enak bgt😆 yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Nah, kali ini kita coba, yuk, buat pentol mercon enak bgt😆 sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Pentol Mercon Enak Bgt😆 memakai 12 jenis bahan dan 3 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Pentol Mercon Enak Bgt😆:

1. Gunakan 30 pentol ayam (kira2)
1. Siapkan 10 bawang merah
1. Siapkan 6 bawang putih
1. Sediakan 3 butir kemiri
1. Gunakan 8 cabe keriting
1. Siapkan 10 cabe rawit (opsional,bisa tambah bisa kurang)
1. Gunakan 1 ruas lengkuas
1. Siapkan 3 lembar daun jeruk
1. Sediakan secukupnya Kaldu bubuk
1. Siapkan secukupnya Gula
1. Siapkan secukupnya Garam
1. Siapkan  Kecap (dikit ajaa)




##### Cara mengolah Pentol Mercon Enak Bgt😆:

1. Siapkan bahan. Aku goreng bentar pentolnya tp ga garing2 bgt. Lalu blender bumbu kecuali serai, daun jeruk, lengkuas.
1. Masukkan bumbu halus, serai, lengkuas dan daun jeruk kemudian masukkan pentol ayam aduk sampai rata. Masukkan sedikit air, garam, kaldu, gula, kecap. Koreksi rasa
1. Dan taraaaaa. Langsung cusss ambil nasi wkwkwwwk, enak bgtt pke kerupuk trus nasinya panassss😭😭😭cobain buibuuuu




Bagaimana? Mudah bukan? Itulah cara menyiapkan pentol mercon enak bgt😆 yang bisa Anda praktikkan di rumah. Selamat mencoba!
