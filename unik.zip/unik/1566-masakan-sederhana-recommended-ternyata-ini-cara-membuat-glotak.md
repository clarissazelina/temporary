---
description: "RECOMMENDED! Ternyata Ini Cara Membuat Glotak "
title: "RECOMMENDED! Ternyata Ini Cara Membuat Glotak "
slug: 1566-masakan-sederhana-recommended-ternyata-ini-cara-membuat-glotak
date: 2020-08-17T21:04:06.574Z
image: https://img-global.cpcdn.com/recipes/ba3efaffccfb285d/751x532cq70/glotak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba3efaffccfb285d/751x532cq70/glotak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba3efaffccfb285d/751x532cq70/glotak-foto-resep-utama.jpg
author: Tyler Allison
ratingvalue: 3.2
reviewcount: 4
recipeingredient:
- "3 papan dage"
- "250 gram cekerbalunganiga"
- "12 buah cabe ijo potong serong memanjang"
- "1 sdm pete cina optional"
- "7 siung bawang merah iris tipis"
- "2 lembar daun salam"
- "4 lembar daun jeruk buang tulangnya"
- "1 ruas lengkuas memarkan"
- "3 batang sereh memarkan"
- "1 butir tomat merah ukuran kecil potong2"
- "secukupnya kaldu bubuk"
- "1 sdm kecap manis"
- "1 sdt garam"
- "1 sdt gula pasir"
- "1 sdt gula merah"
- "2 sdm minyak untuk menumis"
- "1 lt air"
- " Bumbu halus"
- "5 siung bawang putih"
- "5 buah cabe merah keriting"
- "7 buah cabe rawit"
- "1 ruas jahe"
- "1 sdt merica butiran"
- "1 sdt terasi"
- "3 butir kemiri"
recipeinstructions:
- "Kukus dage hingga matang. Kurang lebih 30 menit. Haluskan. Sisihkan."
- "Rebus tulang/ceker dengan air mendidih dan api besar. Selama 3 menit. Buang airnya. Didihkan kembali tulang/ceker dengan api besar selama 3 menit. Kecilkan api, rebus kira2 10 menit sampai keluar kaldunya. Matikan api. Sisihkan."
- "Tumis cabe dan bawang merah hingga layu, masukkan bumbu halus bersama tomat, daun salam, sereh, lengkuas dan daun jeruk hingga wangi. Tambahkan tulang/ceker beserta kaldunya. Biarkan mendidih."
- "Tambahkan dage yg sudah dihaluskan. Aduk rata. Tambahkan garam, gula pasir, gula merah, kecap manis dan kaldu bubuk. Test rasa."
- "Menjelang diangkat tambahkan petai cina. Aduk rata. Angkat. Sajikan bersama kerupuk mie atau kerupuk antor."
- "Yummm...oia, buat yg bwlum tahu, kerupuk antor itu kerupuk aci khas Tegal yg bersalut bumbu bawang....rasa gurihnya ngangenin..."
categories:
- Resep
tags:
- glotak

katakunci: glotak 
nutrition: 204 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Lunch

---


![Glotak](https://img-global.cpcdn.com/recipes/ba3efaffccfb285d/751x532cq70/glotak-foto-resep-utama.jpg)

Anda sedang mencari ide resep glotak yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal glotak yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Lokasinya sendiri berada di lereng Gunung Kawi. Glotak adalah makanan tradisional dari Tegal. Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari glotak, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan glotak enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan glotak sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Glotak memakai 25 jenis bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah Glotak:

1. Ambil 3 papan dage
1. Siapkan 250 gram ceker/balungan/iga
1. Ambil 12 buah cabe ijo, potong serong memanjang
1. Sediakan 1 sdm pete cina (optional)
1. Sediakan 7 siung bawang merah, iris tipis
1. Sediakan 2 lembar daun salam
1. Gunakan 4 lembar daun jeruk, buang tulangnya
1. Gunakan 1 ruas lengkuas, memarkan
1. Gunakan 3 batang sereh, memarkan
1. Ambil 1 butir tomat merah ukuran kecil, potong2
1. Sediakan secukupnya kaldu bubuk
1. Siapkan 1 sdm kecap manis
1. Gunakan 1 sdt garam
1. Gunakan 1 sdt gula pasir
1. Sediakan 1 sdt gula merah
1. Gunakan 2 sdm minyak untuk menumis
1. Gunakan 1 lt air
1. Gunakan  Bumbu halus:
1. Siapkan 5 siung bawang putih
1. Sediakan 5 buah cabe merah keriting
1. Sediakan 7 buah cabe rawit
1. Siapkan 1 ruas jahe
1. Sediakan 1 sdt merica butiran
1. Siapkan 1 sdt terasi
1. Gunakan 3 butir kemiri


Coban Glotak Wagir Malang, Keindahan Air Terjun Tersembunyi. Blog Diah Didi berisi resep masakan praktis yang mudah dipraktekkan di rumah. Coban Glotak, Track Tepat Bagi Jiwa Petualang. 

##### Cara menyiapkan Glotak:

1. Kukus dage hingga matang. Kurang lebih 30 menit. Haluskan. Sisihkan.
1. Rebus tulang/ceker dengan air mendidih dan api besar. Selama 3 menit. Buang airnya. Didihkan kembali tulang/ceker dengan api besar selama 3 menit. Kecilkan api, rebus kira2 10 menit sampai keluar kaldunya. Matikan api. Sisihkan.
1. Tumis cabe dan bawang merah hingga layu, masukkan bumbu halus bersama tomat, daun salam, sereh, lengkuas dan daun jeruk hingga wangi. Tambahkan tulang/ceker beserta kaldunya. Biarkan mendidih.
1. Tambahkan dage yg sudah dihaluskan. Aduk rata. Tambahkan garam, gula pasir, gula merah, kecap manis dan kaldu bubuk. Test rasa.
1. Menjelang diangkat tambahkan petai cina. Aduk rata. Angkat. Sajikan bersama kerupuk mie atau kerupuk antor.
1. Yummm...oia, buat yg bwlum tahu, kerupuk antor itu kerupuk aci khas Tegal yg bersalut bumbu bawang....rasa gurihnya ngangenin...




Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Glotak yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide dalam berjualan makanan. Selamat mencoba!
