---
description: "TERUNGKAP! Ternyata Ini Cara Membuat Selai Nenas Anti Gagal"
title: "TERUNGKAP! Ternyata Ini Cara Membuat Selai Nenas Anti Gagal"
slug: 1594-masakan-sederhana-terungkap-ternyata-ini-cara-membuat-selai-nenas-anti-gagal
date: 2020-07-05T07:53:08.114Z
image: https://img-global.cpcdn.com/recipes/0fc198826de01c5c/751x532cq70/selai-nenas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0fc198826de01c5c/751x532cq70/selai-nenas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0fc198826de01c5c/751x532cq70/selai-nenas-foto-resep-utama.jpg
author: Ellen Hill
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "2 buah nenas"
- "1 gelas gula pasir"
- "2 sdm tepung maizena"
- "1 sdt garam"
- "secukupnya Air"
recipeinstructions:
- "Bersihkan nenas, potong2. Blender nenas dengan memberikan air secukupnya saja. Blender sampai halus."
- "Siapkan gula dan garam. Usahakan masak selai nenas di teflon anti lengket yah. Soalnya saat memasak selai nenas, bakalan lengket lengket."
- "Masak hingga air berkurang dan mulai mengental. Setelah mulai mengental, masukkan larutan tepung maizena yg dilarutkan dengan air."
- "Selai nenas jadi. Jika diblender, masih terasa seratnya. Meski dikasih gula, masih terasa asem nya nenas."
categories:
- Resep
tags:
- selai
- nenas

katakunci: selai nenas 
nutrition: 126 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT57M"
recipeyield: "1"
recipecategory: Dinner

---


![Selai Nenas](https://img-global.cpcdn.com/recipes/0fc198826de01c5c/751x532cq70/selai-nenas-foto-resep-utama.jpg)

Anda sedang mencari ide resep selai nenas yang unik? Cara membuatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal selai nenas yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan selai nenas enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah selai nenas yang siap dikreasikan. Anda dapat membuat Selai Nenas memakai 5 bahan dan 4 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Selai Nenas:

1. Ambil 2 buah nenas
1. Sediakan 1 gelas gula pasir
1. Gunakan 2 sdm tepung maizena
1. Ambil 1 sdt garam
1. Gunakan secukupnya Air




##### Langkah-langkah mengolah Selai Nenas:

1. Bersihkan nenas, potong2. Blender nenas dengan memberikan air secukupnya saja. Blender sampai halus.
1. Siapkan gula dan garam. Usahakan masak selai nenas di teflon anti lengket yah. Soalnya saat memasak selai nenas, bakalan lengket lengket.
1. Masak hingga air berkurang dan mulai mengental. Setelah mulai mengental, masukkan larutan tepung maizena yg dilarutkan dengan air.
1. Selai nenas jadi. Jika diblender, masih terasa seratnya. Meski dikasih gula, masih terasa asem nya nenas.




Gimana nih? Gampang kan? Itulah cara menyiapkan selai nenas yang bisa Anda lakukan di rumah. Selamat mencoba!
