---
description: "BIKIN NAGIH! Begini Cara Membuat Pentol mercon Anti Gagal"
title: "BIKIN NAGIH! Begini Cara Membuat Pentol mercon Anti Gagal"
slug: 1828-masakan-sederhana-bikin-nagih-begini-cara-membuat-pentol-mercon-anti-gagal
date: 2020-09-08T21:28:36.013Z
image: https://img-global.cpcdn.com/recipes/72c6cff7375fdb4f/751x532cq70/pentol-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/72c6cff7375fdb4f/751x532cq70/pentol-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/72c6cff7375fdb4f/751x532cq70/pentol-mercon-foto-resep-utama.jpg
author: John Norman
ratingvalue: 3
reviewcount: 11
recipeingredient:
- "2 bawang putih"
- "5 bawang merah"
- "1/2 tomat"
- "2 cabe merah"
- " Cabe rawit setan sesuai selera"
- " Terasi  sdt"
- " Gula merah sesuai selera"
- " Garam secukupnya"
- " Kecap sedikit saja"
- " Minyak goreng"
- " Air"
- "15 Basopentol"
- " Saus cabai"
recipeinstructions:
- "Goreng bawang merah, bawang putih, tomat, cabe merah, cabe rawit sampai layu"
- "Ulek bahan yang sudah digoreng tadi (menggunakan blender juga bisa) jangan terlalu halus"
- "Goreng semua bumbu tadi dengan minyak sedikit saja, kemudian tambahkan terasi dan gula merah (sesuai selera)"
- "Lalu masukan baso (untuk baso bisa digoreng dulu). Bisa juga langsung dimasukan"
- "Tambahkan kecap dan saus cabai (sesuai selera)"
- "Masukan air secukupnya, sesekali di aduk agar sambal meresap dengan rata kedalam pentol/baso dan tunggu sampai air mengering dan bumbunya meresap"
categories:
- Resep
tags:
- pentol
- mercon

katakunci: pentol mercon 
nutrition: 126 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Pentol mercon](https://img-global.cpcdn.com/recipes/72c6cff7375fdb4f/751x532cq70/pentol-mercon-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep pentol mercon yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pentol mercon yang enak selayaknya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari pentol mercon, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan pentol mercon enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.

Haii hari ini aku masak pentol bakso mercon Aduuuh ini pedeeessss banget banget banget !! Tp ketagihan sih hehe Disini aku haluskan bumbunya pake chopper. Tahukah Anda bedanya bakso dan pentol?


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah pentol mercon yang siap dikreasikan. Anda bisa menyiapkan Pentol mercon menggunakan 13 bahan dan 6 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Pentol mercon:

1. Gunakan 2 bawang putih
1. Siapkan 5 bawang merah
1. Ambil 1/2 tomat
1. Siapkan 2 cabe merah
1. Siapkan  Cabe rawit setan (sesuai selera)
1. Gunakan  Terasi (½ sdt)
1. Sediakan  Gula merah (sesuai selera)
1. Ambil  Garam (secukupnya)
1. Gunakan  Kecap (sedikit saja)
1. Ambil  Minyak goreng
1. Sediakan  Air
1. Siapkan 15 Baso/pentol
1. Gunakan  Saus cabai


Questions regarding function, support and sales can be answered via online chat support, e-mail to sales@pentol.net or personal online meeting. BoB yg suka makan akan membagikan tutorial mengolah makanan sehat untuk teman teman berbagai kalangan dan makanan sederhana. Nah, berikut ini resep pentol mercon, seperti dilansir suara.com yang mengutip Tips terakhir untuk nada yang ingin memulai usaha pentol mercon adalah kewajiban setiappemilik usaha, yakni jadikan. Resep Pentol Mercon Pedas Super Enak. 

##### Cara menyiapkan Pentol mercon:

1. Goreng bawang merah, bawang putih, tomat, cabe merah, cabe rawit sampai layu
1. Ulek bahan yang sudah digoreng tadi (menggunakan blender juga bisa) jangan terlalu halus
1. Goreng semua bumbu tadi dengan minyak sedikit saja, kemudian tambahkan terasi dan gula merah (sesuai selera)
1. Lalu masukan baso (untuk baso bisa digoreng dulu). Bisa juga langsung dimasukan
1. Tambahkan kecap dan saus cabai (sesuai selera)
1. Masukan air secukupnya, sesekali di aduk agar sambal meresap dengan rata kedalam pentol/baso dan tunggu sampai air mengering dan bumbunya meresap


Pentol mercon pedasnya meledak ledak dimulut l indonesia street food. Pentol atau bakso jadi salah satu makanan favorit sebagian besar orang Indonesia. Dimakan langsung pun enak, tanpa bahan-bahan pelengkap dalam semangkuk bakso. Tekstur pentol yang kenyal dan ditambah dengan rasa bumbu mercon yang super pedas membuat Resep Bakso Pentol Mercon. Paylaştığı hiçbir fotoğrafı ve videoyu kaçırmamak için Pentol Mercon Mamsky\'i (@pentolmamsky) takip et. 

Gimana nih? Gampang kan? Itulah cara membuat pentol mercon yang bisa Anda praktikkan di rumah. Selamat mencoba!
