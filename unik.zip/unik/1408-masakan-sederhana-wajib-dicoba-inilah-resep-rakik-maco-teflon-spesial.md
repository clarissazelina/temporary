---
description: "WAJIB DICOBA! Inilah Resep Rakik Maco (Teflon) Spesial"
title: "WAJIB DICOBA! Inilah Resep Rakik Maco (Teflon) Spesial"
slug: 1408-masakan-sederhana-wajib-dicoba-inilah-resep-rakik-maco-teflon-spesial
date: 2020-06-24T19:46:33.739Z
image: https://img-global.cpcdn.com/recipes/b9a39c705b53a269/751x532cq70/rakik-maco-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b9a39c705b53a269/751x532cq70/rakik-maco-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b9a39c705b53a269/751x532cq70/rakik-maco-teflon-foto-resep-utama.jpg
author: Mathilda Banks
ratingvalue: 3
reviewcount: 13
recipeingredient:
- "6 sdm Terigu "
- "2 sdm Tapioka"
- "1 butir putih telur boleh kuningnya ya bund"
- "12 ekor Ikan Maco ukuran sedang"
- "2 siung Bawang Putih"
- "1 siung Bawang Merah"
- "2 cm Kunyit"
- "1 buah Kemiri"
- "1 buah Cabe Keriting optional"
- "3 lembar Daun Jeruk iris kecil"
- "1/3 lembar Daun Kunyit optional"
- "1/3 sdt Kapur Sirih boleh skip"
- "Secukupnya Garam"
- "Secukupnya Ketumbar bubuk"
- "Secukupnya Merica bubuk"
- "Secukupnya air"
recipeinstructions:
- "Bersikan bagian perut ikan asin, cuci sekilas dan tiriskan."
- "Haluskan duo bawang, kemiri, kunyit dan cabe. Jangan lupa tambahkan garam. Sisihkan."
- "Satukan duo tepung, ketumbar bubuk, merica bubuk, kapur sirih. Aduk rata."
- "Masukan bumbu halus, putih telur, lalu tambahkan air sedikit demi sedikit aduk rata. Adonan cendrung encer. Semakin encer semakin bagus ketebalannya, tapi jangan terlalu encer ya bund. Karena kalo terlalu encer sulit untuk membentuknya. Jangan lupa tes rasa."
- "Tambahkan irisan daun jeruk dan daun kunyit jika suka. Aduk rata, adonan siap untuk di masak."
- "Siapkan teflon dengan olesan minyak goreng tipis serta wajan penggorengan yang berisi minyak secukupnya. Panaskan minyak di wajan dan teflon. Proses memasak memang menggunakan dua kompor sekaligus ya bund."
- "Setelah teflon panas tuang adonan peyek satu sendok sayur atau ukuran sesuai selera, tipiskan adonan dengan punggung sendok sayur (agar tipis merata). Jangan lupa taruh satu ekor ikan asin di tengah, sedikit ditekan ya bunda."
- "Setelah pinggiran peyek dirasa kokoh, siram peyek dengan minyak panas yang diambil dari wajan sebelah. Siram sedikit demi sedikit dan berhenti saat peyek sudah lepas dari teflon. Balik."
- "Peyek di teflon itu setengah matang ya bund. Saat peyek sudah kokoh (tidak terlihat adonan tepung) peyek boleh langsung dipindah ke wajan dengan minyak panas dan goreng sampai matang. Lakukan hingga selesai."
- "Nb. Teflon adalah alat pengganti cetakan. Karena rakik maco ini biasanya berbentuk persegi atau bulat. Agar mendapatkan bentuk bulat tanpa cetakan, cukup tuang adonan pada bagian tengah teflon yang panasnya sedang. Biarkan adonan menyebar sendiri hingga membentuk bundar."
- "Nb.. Untuk mendapatkan ketebalan yang pas tergantung pada konsistensi adonan dan tinggkat kepanasan teflon ya bunda. Teflon yang terlalu panas dan kurang panas membuat adonan menumpuk ditengah dan sulit diratakan dengan punggung sendok sayur. Hasilnya ketebalan dibagian tengah atau bahkan tidak matang."
- "Nb... Untuk mendapatkan tepung rempeyek bagian ikan asin dan ikan asisnnya matang, saat memindahkan ke minyak goreng posisikan sisi peyek yang ada ikannya dibagian bawah sesekali tekan bagian yang ada ikan asinnya. InsyaAllah matang sempurna bunda. Oh ya ikan asin bisa diganti udang rebon ya bund.. Happy cooking, maaf kali ini ga ada foto step by step ya bund 😣"
categories:
- Resep
tags:
- rakik
- maco
- teflon

katakunci: rakik maco teflon 
nutrition: 224 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT51M"
recipeyield: "4"
recipecategory: Dessert

---


![Rakik Maco (Teflon)](https://img-global.cpcdn.com/recipes/b9a39c705b53a269/751x532cq70/rakik-maco-teflon-foto-resep-utama.jpg)

Lagi mencari ide resep rakik maco (teflon) yang unik? Cara menyiapkannya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal rakik maco (teflon) yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari rakik maco (teflon), mulai dari jenis bahan, kemudian pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan rakik maco (teflon) yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan rakik maco (teflon) sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Rakik Maco (Teflon) memakai 16 jenis bahan dan 12 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Rakik Maco (Teflon):

1. Gunakan 6 sdm Terigu ∆
1. Gunakan 2 sdm Tapioka
1. Ambil 1 butir putih telur (boleh kuningnya ya bund)
1. Ambil 12 ekor Ikan Maco ukuran sedang
1. Gunakan 2 siung Bawang Putih
1. Sediakan 1 siung Bawang Merah
1. Sediakan 2 cm Kunyit
1. Siapkan 1 buah Kemiri
1. Sediakan 1 buah Cabe Keriting (optional)
1. Siapkan 3 lembar Daun Jeruk iris kecil
1. Gunakan 1/3 lembar Daun Kunyit (optional)
1. Siapkan 1/3 sdt Kapur Sirih (boleh skip)
1. Gunakan Secukupnya Garam
1. Gunakan Secukupnya Ketumbar bubuk
1. Ambil Secukupnya Merica bubuk
1. Ambil Secukupnya air




##### Langkah-langkah meracik Rakik Maco (Teflon):

1. Bersikan bagian perut ikan asin, cuci sekilas dan tiriskan.
1. Haluskan duo bawang, kemiri, kunyit dan cabe. Jangan lupa tambahkan garam. Sisihkan.
1. Satukan duo tepung, ketumbar bubuk, merica bubuk, kapur sirih. Aduk rata.
1. Masukan bumbu halus, putih telur, lalu tambahkan air sedikit demi sedikit aduk rata. Adonan cendrung encer. Semakin encer semakin bagus ketebalannya, tapi jangan terlalu encer ya bund. Karena kalo terlalu encer sulit untuk membentuknya. Jangan lupa tes rasa.
1. Tambahkan irisan daun jeruk dan daun kunyit jika suka. Aduk rata, adonan siap untuk di masak.
1. Siapkan teflon dengan olesan minyak goreng tipis serta wajan penggorengan yang berisi minyak secukupnya. Panaskan minyak di wajan dan teflon. Proses memasak memang menggunakan dua kompor sekaligus ya bund.
1. Setelah teflon panas tuang adonan peyek satu sendok sayur atau ukuran sesuai selera, tipiskan adonan dengan punggung sendok sayur (agar tipis merata). Jangan lupa taruh satu ekor ikan asin di tengah, sedikit ditekan ya bunda.
1. Setelah pinggiran peyek dirasa kokoh, siram peyek dengan minyak panas yang diambil dari wajan sebelah. Siram sedikit demi sedikit dan berhenti saat peyek sudah lepas dari teflon. Balik.
1. Peyek di teflon itu setengah matang ya bund. Saat peyek sudah kokoh (tidak terlihat adonan tepung) peyek boleh langsung dipindah ke wajan dengan minyak panas dan goreng sampai matang. Lakukan hingga selesai.
1. Nb. Teflon adalah alat pengganti cetakan. Karena rakik maco ini biasanya berbentuk persegi atau bulat. Agar mendapatkan bentuk bulat tanpa cetakan, cukup tuang adonan pada bagian tengah teflon yang panasnya sedang. Biarkan adonan menyebar sendiri hingga membentuk bundar.
1. Nb.. Untuk mendapatkan ketebalan yang pas tergantung pada konsistensi adonan dan tinggkat kepanasan teflon ya bunda. Teflon yang terlalu panas dan kurang panas membuat adonan menumpuk ditengah dan sulit diratakan dengan punggung sendok sayur. Hasilnya ketebalan dibagian tengah atau bahkan tidak matang.
1. Nb... Untuk mendapatkan tepung rempeyek bagian ikan asin dan ikan asisnnya matang, saat memindahkan ke minyak goreng posisikan sisi peyek yang ada ikannya dibagian bawah sesekali tekan bagian yang ada ikan asinnya. InsyaAllah matang sempurna bunda. Oh ya ikan asin bisa diganti udang rebon ya bund.. Happy cooking, maaf kali ini ga ada foto step by step ya bund 😣




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Rakik Maco (Teflon) yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
