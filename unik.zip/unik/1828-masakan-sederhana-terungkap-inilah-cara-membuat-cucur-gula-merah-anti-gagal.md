---
description: "TERUNGKAP! Inilah Cara Membuat Cucur gula merah Anti Gagal"
title: "TERUNGKAP! Inilah Cara Membuat Cucur gula merah Anti Gagal"
slug: 1828-masakan-sederhana-terungkap-inilah-cara-membuat-cucur-gula-merah-anti-gagal
date: 2020-05-20T06:55:07.937Z
image: https://img-global.cpcdn.com/recipes/6f2cd0a1498244e6/751x532cq70/cucur-gula-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6f2cd0a1498244e6/751x532cq70/cucur-gula-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6f2cd0a1498244e6/751x532cq70/cucur-gula-merah-foto-resep-utama.jpg
author: Estella Vasquez
ratingvalue: 3.7
reviewcount: 13
recipeingredient:
- "8 sdm tepung beras"
- "10 sdm tepung terigu"
- "2 1/2 keping gula merah"
- "4 sdm gula pasir"
- "Sejumput garam"
- "200 ml air"
- "1 lembar daun pandan"
- " Minyak goreng"
- " Nb  tingkat kemanisan bisa di sesuaikan sndr"
recipeinstructions:
- "Rebus gula merah,garam dan daun pandan dengan air 200 ml td sampai gula larut dn sisihkan"
- "Smbil menunggu gula dingin,campur tepung beras dan tepung terigu aduk2"
- "Setelah gula dingin,tuang ke campuran tepung sedikit dmi sdkit aduk smpai rata lalu saring supaya tidak ada tepung yang bergerindil"
- "Lalu mixer selama 5 menit,setelah itu ttup kain dan diamkan selama 15 menit"
- "Panaskan penggorengan dan tuang minyak (jangan terlalu banyak),usahakan minyak benar2 panas dan api kecil,kemudian tuang adonan sebanyak 1 sendok sayur,goreng sampai matang"
categories:
- Resep
tags:
- cucur
- gula
- merah

katakunci: cucur gula merah 
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dinner

---


![Cucur gula merah](https://img-global.cpcdn.com/recipes/6f2cd0a1498244e6/751x532cq70/cucur-gula-merah-foto-resep-utama.jpg)

Sedang mencari ide resep cucur gula merah yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal cucur gula merah yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cucur gula merah, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan cucur gula merah enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.

Kue berwarna cokelat bernama kue cucur atau kuih cucur dalam bahasa Melayu ini sangat mudah ditemukan di pasar. Warna cokelat dari kue ini berasal dari gula merah yang menjadi campuran. Lihat juga resep Cucur Gula Merah enak lainnya.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah cucur gula merah yang siap dikreasikan. Anda bisa membuat Cucur gula merah memakai 9 bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Cucur gula merah:

1. Gunakan 8 sdm tepung beras
1. Gunakan 10 sdm tepung terigu
1. Sediakan 2 1/2 keping gula merah
1. Sediakan 4 sdm gula pasir
1. Gunakan Sejumput garam
1. Sediakan 200 ml air
1. Siapkan 1 lembar daun pandan
1. Gunakan  Minyak goreng
1. Sediakan  Nb :: tingkat kemanisan bisa di sesuaikan sndr


Cara membuat kue cucur gula merah perlu ketelitian dan mengikuti resep dengan tepat. Kue cucur terbuat dari tepung beras, tepung terigu, dan gula merah. Cucur Gula Merar, makanan khas jajanan pasar yang ternyata untuk membuatnya tak perlu butuh banyak bahan. Simak resep cucur ini untuk mengetahui tips anti gagal dalam membuatnya! 

##### Langkah-langkah meracik Cucur gula merah:

1. Rebus gula merah,garam dan daun pandan dengan air 200 ml td sampai gula larut dn sisihkan
1. Smbil menunggu gula dingin,campur tepung beras dan tepung terigu aduk2
1. Setelah gula dingin,tuang ke campuran tepung sedikit dmi sdkit aduk smpai rata lalu saring supaya tidak ada tepung yang bergerindil
1. Lalu mixer selama 5 menit,setelah itu ttup kain dan diamkan selama 15 menit
1. Panaskan penggorengan dan tuang minyak (jangan terlalu banyak),usahakan minyak benar2 panas dan api kecil,kemudian tuang adonan sebanyak 1 sendok sayur,goreng sampai matang


Resep Kue Cucur Gula Merah. ©Shutterstock. Berikut ini resep dan cara membuat kue cucur dengan rasa gula merah sederhana. Saat gula merah berubah menjadi karamel, tambahkan sedikit air ke dalamnya. Tiriskan, lalu letakkan kue cucur di atas piring. Jika gula merah sudah mulai larut, anda bisa menyaring hasil rebusan tersebut dan biarkan rebusan tetap hangat. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Cucur gula merah yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
