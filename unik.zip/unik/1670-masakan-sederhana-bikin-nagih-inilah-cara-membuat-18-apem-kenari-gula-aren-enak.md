---
description: "BIKIN NAGIH! Inilah Cara Membuat #18. Apem Kenari Gula Aren Enak"
title: "BIKIN NAGIH! Inilah Cara Membuat #18. Apem Kenari Gula Aren Enak"
slug: 1670-masakan-sederhana-bikin-nagih-inilah-cara-membuat-18-apem-kenari-gula-aren-enak
date: 2020-08-21T03:52:53.900Z
image: https://img-global.cpcdn.com/recipes/94973856bf1187ec/751x532cq70/18-apem-kenari-gula-aren-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/94973856bf1187ec/751x532cq70/18-apem-kenari-gula-aren-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/94973856bf1187ec/751x532cq70/18-apem-kenari-gula-aren-foto-resep-utama.jpg
author: William Summers
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- " Bahan kering"
- "250 gram tepung terigu"
- "1 bks vanili"
- "75 gram gula aren"
- "25 gram gula pasir"
- "1/2 sdt garam"
- "1 sdt kayu manis bubuk"
- " Bahan pencampur"
- "100 gram kelapa parut agak muda"
- "50 gram kenari cincang"
- "1/2 sdm ragi instan"
- " Bahan basah"
- "1 butir telur"
- "35 gram mentega"
- "200 ml air"
recipeinstructions:
- "Campur bahan kering, aduk merata"
- "Tambahkan bahan pencampur dan aduk lagi lalu tambahkan bahan basah"
- "Aduk adonan hingga bercampur dan istirahatkan selama 1 jam"
- "Siapkan cetakan, olesi minyak dan panaskan. Kemudian siap memanggang"
- "Gunakan api kecil dan jgn ditutup, Biarkan adonan naik dan terlihat lubang-lubang pada permukaan adonan baru kemudian dibalik"
- "Kue apem kelapa kenari siap dihidangkan"
categories:
- Resep
tags:
- 18
- apem
- kenari

katakunci: 18 apem kenari 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Dinner

---


![#18. Apem Kenari Gula Aren](https://img-global.cpcdn.com/recipes/94973856bf1187ec/751x532cq70/18-apem-kenari-gula-aren-foto-resep-utama.jpg)

Anda sedang mencari ide resep #18. apem kenari gula aren yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal #18. apem kenari gula aren yang enak selayaknya memiliki aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari #18. apem kenari gula aren, pertama dari jenis bahan, kemudian pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan #18. apem kenari gula aren enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Di bawah ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah #18. apem kenari gula aren yang siap dikreasikan. Anda bisa membuat #18. Apem Kenari Gula Aren menggunakan 15 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah #18. Apem Kenari Gula Aren:

1. Gunakan  Bahan kering
1. Ambil 250 gram tepung terigu
1. Siapkan 1 bks vanili
1. Siapkan 75 gram gula aren
1. Siapkan 25 gram gula pasir
1. Ambil 1/2 sdt garam
1. Ambil 1 sdt kayu manis bubuk
1. Ambil  Bahan pencampur
1. Siapkan 100 gram kelapa parut (agak muda)
1. Siapkan 50 gram kenari cincang
1. Ambil 1/2 sdm ragi instan
1. Siapkan  Bahan basah
1. Ambil 1 butir telur
1. Ambil 35 gram mentega
1. Gunakan 200 ml air




##### Langkah-langkah meracik #18. Apem Kenari Gula Aren:

1. Campur bahan kering, aduk merata
1. Tambahkan bahan pencampur dan aduk lagi lalu tambahkan bahan basah
1. Aduk adonan hingga bercampur dan istirahatkan selama 1 jam
1. Siapkan cetakan, olesi minyak dan panaskan. Kemudian siap memanggang
1. Gunakan api kecil dan jgn ditutup, Biarkan adonan naik dan terlihat lubang-lubang pada permukaan adonan baru kemudian dibalik
1. Kue apem kelapa kenari siap dihidangkan




Gimana nih? Mudah bukan? Itulah cara membuat #18. apem kenari gula aren yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
