---
description: "BIKIN NAGIH! Inilah Cara Membuat Sroto khas Sokaraja "
title: "BIKIN NAGIH! Inilah Cara Membuat Sroto khas Sokaraja "
slug: 1613-masakan-sederhana-bikin-nagih-inilah-cara-membuat-sroto-khas-sokaraja
date: 2020-04-25T23:29:37.301Z
image: https://img-global.cpcdn.com/recipes/118dfe1bfb9b19d3/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/118dfe1bfb9b19d3/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/118dfe1bfb9b19d3/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg
author: Jeremy Hughes
ratingvalue: 3.8
reviewcount: 14
recipeingredient:
- "1 paha ayam utuh Rebus sisihkan kaldunya"
- "secukupnya Tauge pendek"
- "3 daun jeruk"
- "1 ruas lengkuas"
- "1 batang serai"
- " Ketupatlontong"
- " Kerupuk Aci goreng"
- " Penyedap rasa ayam"
- " Gula dan garam"
- " Bumbu Halus "
- "2 siung bawang merah"
- "3 siung bawang putih"
- "2 butir kemiri"
- "2 cm kunyit"
- "Sedikit jahe"
- "1/2 sdt merica"
- " Bahan Sambal Kacang "
- "150 gr kacang goreng"
- "2 keping gula merah sisir"
- "25 cabe rawit"
- "Sedikit garam"
recipeinstructions:
- "Goreng sebentar paha ayam yg sudah direbus, tiriskan lalu suwir. Didihkan kaldu rebusan ayam dengan menambahkan air secukupnya."
- "Tumis bumbu halus, serai, daun jeruk & serai. Pastikan menumis bumbu sampai matang. Lalu masukkan bumbu ke rebusan kaldu. Masukkan lengkuas dan suwiran ayam. Bumbui dengan garam dan sedikit gula. Cek rasa."
- "Buat sambal dg haluskan semua bahan sambal kacang. Beri sedikit kuah sroto sampai sambal mengental. Tata semua komponen di mangkuk. Siram kuah sroto & sambal. Beri taburan kerupuk. Sajikan. Happy Cooking ❤❤"
categories:
- Resep
tags:
- sroto
- khas
- sokaraja

katakunci: sroto khas sokaraja 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT52M"
recipeyield: "2"
recipecategory: Dessert

---


![Sroto khas Sokaraja](https://img-global.cpcdn.com/recipes/118dfe1bfb9b19d3/751x532cq70/sroto-khas-sokaraja-foto-resep-utama.jpg)

Anda sedang mencari ide resep sroto khas sokaraja yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal sroto khas sokaraja yang enak harusnya sih punya aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sroto khas sokaraja, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan sroto khas sokaraja enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.

Sroto Sokaraja adalah soto khas Sokaraja, Banyumas (PURWOKERTO), Jawa Tengah. Adanya campuran bumbu sambal kacang dan ketupat. Soto Sokaraja atau oleh masyarakat Banyumas disebut Sroto Sokaraja adalah sejenis makanan dari Indonesia.


Berikut ini ada beberapa tips dan trik praktis untuk membuat sroto khas sokaraja yang siap dikreasikan. Anda bisa menyiapkan Sroto khas Sokaraja memakai 21 bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Sroto khas Sokaraja:

1. Gunakan 1 paha ayam, utuh. Rebus, sisihkan kaldunya
1. Siapkan secukupnya Tauge pendek
1. Ambil 3 daun jeruk
1. Ambil 1 ruas lengkuas
1. Ambil 1 batang serai
1. Sediakan  Ketupat/lontong
1. Ambil  Kerupuk Aci goreng
1. Ambil  Penyedap rasa ayam
1. Sediakan  Gula dan garam
1. Gunakan  Bumbu Halus :
1. Siapkan 2 siung bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 2 butir kemiri
1. Siapkan 2 cm kunyit
1. Sediakan Sedikit jahe
1. Ambil 1/2 sdt merica
1. Gunakan  Bahan Sambal Kacang :
1. Sediakan 150 gr kacang goreng
1. Sediakan 2 keping gula merah, sisir
1. Ambil 25 cabe rawit
1. Siapkan Sedikit garam


Terletak di jalan Raya Banyumas-Purwokerto atau Jalan Jenderal Sudirman. Sroto merupakan makanan khas dari sokaraja, Banyumas. Jenis makanan ini adalah sama dengan soto, namun orang Sokaraja menyebutnya dengan sebutan sroto. Soto tersebut memiliki rasa yang khas karena dibubuhi sambal kacang Berbeda dengan soto Semarang atau Solo yang bening, soto khas Banyumas ini berkuah agak keruh. 

##### Cara menyiapkan Sroto khas Sokaraja:

1. Goreng sebentar paha ayam yg sudah direbus, tiriskan lalu suwir. Didihkan kaldu rebusan ayam dengan menambahkan air secukupnya.
1. Tumis bumbu halus, serai, daun jeruk & serai. Pastikan menumis bumbu sampai matang. Lalu masukkan bumbu ke rebusan kaldu. Masukkan lengkuas dan suwiran ayam. Bumbui dengan garam dan sedikit gula. Cek rasa.
1. Buat sambal dg haluskan semua bahan sambal kacang. Beri sedikit kuah sroto sampai sambal mengental. Tata semua komponen di mangkuk. Siram kuah sroto & sambal. Beri taburan kerupuk. Sajikan. - Happy Cooking ❤❤


Selain terkenal dengan gethuk gorengnya yang lezat, Sokaraja juga memiliki hidangan soto yang khas dan disukai. Soto sokaraja memiliki bumbu yang lebih beragam. GenPI.co - Konon, Purwokerto memapu membuat orang yang. Resep Soto Sokaraja Khas Banyumas Purwokerto Sederhana Spesial Asli Enak. Soto Sokaraja nama lainnya adalah sroto Banyumas tradisional tersedia pakai daging sapi. 

Bagaimana? Gampang kan? Itulah cara menyiapkan sroto khas sokaraja yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
