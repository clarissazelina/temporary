---
description: "BIKIN NAGIH! Inilah Cara Membuat Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu) Enak"
title: "BIKIN NAGIH! Inilah Cara Membuat Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu) Enak"
slug: 1401-masakan-sederhana-bikin-nagih-inilah-cara-membuat-aneka-olahan-rainbowcenil-rainbow-jajanan-tempo-dulu-enak
date: 2020-09-27T13:41:28.800Z
image: https://img-global.cpcdn.com/recipes/7c153c850a87f467/751x532cq70/aneka-olahan-rainbowcenil-rainbow-jajanan-tempo-dulu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7c153c850a87f467/751x532cq70/aneka-olahan-rainbowcenil-rainbow-jajanan-tempo-dulu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7c153c850a87f467/751x532cq70/aneka-olahan-rainbowcenil-rainbow-jajanan-tempo-dulu-foto-resep-utama.jpg
author: Warren Hines
ratingvalue: 4.5
reviewcount: 9
recipeingredient:
- " Bahan adonan "
- "10 sdm tepung terigu"
- "10 sdm tepung tapioka tepung kanji"
- "1/4 sdt garam"
- "1/4 sdt vanili"
- "Secukupnya air hangat"
- "Secukupnya pewarna merah hijau"
- "Secukupnya daun pisang"
- " Taburan "
- "200 gr Kelapa parut"
- "1/4 sdt garam"
- "1 ruas pandan"
- " Bahan kuah "
- "100 gr gula merah"
- "125 ml air"
- "1 ruas pandan"
- "1 sdm tepung maizena"
recipeinstructions:
- "Siapkan semua bahan bahannya"
- "Kita buat kuah siramnya dahulu ya sampai mengental. Setelah itu kita kukus kelapa nya"
- "Campurkan bahan adonan dan uleni sampai kalis, bagi jadi 3 bagian dan kasih pewarna merah, hijau, yang satu original ya"
- "Taburi daun pisang dengan tepung tapioka, ambil sedikit demi sedikit adonan dan plintir sampai adonan habis"
- "Panaskan air, jika sudah mendidih, masukkan adonan tadi sampai mengapung, tiriskan, baluri dengan kelapa, letakkan dalam wadah & siram dengan kuah gula merah"
- "Cenil rainbow siap dihidangkan 😍"
categories:
- Resep
tags:
- aneka
- olahan
- rainbowcenil

katakunci: aneka olahan rainbowcenil 
nutrition: 272 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT40M"
recipeyield: "2"
recipecategory: Lunch

---


![Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu)](https://img-global.cpcdn.com/recipes/7c153c850a87f467/751x532cq70/aneka-olahan-rainbowcenil-rainbow-jajanan-tempo-dulu-foto-resep-utama.jpg)

Sedang mencari ide resep aneka olahan rainbow~cenil rainbow (jajanan tempo dulu) yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal aneka olahan rainbow~cenil rainbow (jajanan tempo dulu) yang enak seharusnya mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari aneka olahan rainbow~cenil rainbow (jajanan tempo dulu), mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan aneka olahan rainbow~cenil rainbow (jajanan tempo dulu) enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.


Nah, kali ini kita coba, yuk, variasikan aneka olahan rainbow~cenil rainbow (jajanan tempo dulu) sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu) memakai 17 bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu):

1. Sediakan  Bahan adonan :
1. Ambil 10 sdm tepung terigu
1. Sediakan 10 sdm tepung tapioka (tepung kanji)
1. Ambil 1/4 sdt garam
1. Sediakan 1/4 sdt vanili
1. Gunakan Secukupnya air hangat
1. Ambil Secukupnya pewarna (merah, hijau)
1. Sediakan Secukupnya daun pisang
1. Ambil  Taburan :
1. Gunakan 200 gr Kelapa parut
1. Sediakan 1/4 sdt garam
1. Gunakan 1 ruas pandan
1. Sediakan  Bahan kuah :
1. Gunakan 100 gr gula merah
1. Siapkan 125 ml air
1. Gunakan 1 ruas pandan
1. Ambil 1 sdm tepung maizena




##### Cara mengolah Aneka Olahan Rainbow~Cenil Rainbow (jajanan tempo dulu):

1. Siapkan semua bahan bahannya
1. Kita buat kuah siramnya dahulu ya sampai mengental. Setelah itu kita kukus kelapa nya
1. Campurkan bahan adonan dan uleni sampai kalis, bagi jadi 3 bagian dan kasih pewarna merah, hijau, yang satu original ya
1. Taburi daun pisang dengan tepung tapioka, ambil sedikit demi sedikit adonan dan plintir sampai adonan habis
1. Panaskan air, jika sudah mendidih, masukkan adonan tadi sampai mengapung, tiriskan, baluri dengan kelapa, letakkan dalam wadah & siram dengan kuah gula merah
1. Cenil rainbow siap dihidangkan 😍




Bagaimana? Mudah bukan? Itulah cara menyiapkan aneka olahan rainbow~cenil rainbow (jajanan tempo dulu) yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
