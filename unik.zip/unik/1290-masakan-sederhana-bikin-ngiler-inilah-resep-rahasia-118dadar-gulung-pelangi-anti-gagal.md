---
description: "BIKIN NGILER! Inilah Resep Rahasia 118.Dadar gulung pelangi Anti Gagal"
title: "BIKIN NGILER! Inilah Resep Rahasia 118.Dadar gulung pelangi Anti Gagal"
slug: 1290-masakan-sederhana-bikin-ngiler-inilah-resep-rahasia-118dadar-gulung-pelangi-anti-gagal
date: 2020-08-24T03:52:43.583Z
image: https://img-global.cpcdn.com/recipes/52244f5751d0fc28/751x532cq70/118dadar-gulung-pelangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/52244f5751d0fc28/751x532cq70/118dadar-gulung-pelangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/52244f5751d0fc28/751x532cq70/118dadar-gulung-pelangi-foto-resep-utama.jpg
author: Charles Pittman
ratingvalue: 5
reviewcount: 8
recipeingredient:
- " Bahan kulit"
- "300 gr terigu"
- "500 ml santan"
- "2 telur kocok lepas"
- "1 sdt garam"
- " Pewarna makananmerah hijau biru"
- " Bahan isi"
- "1/2 buah kelapa parut"
- "200 gr gula merahsesuai selera"
- "secukupnya garam"
recipeinstructions:
- "Campur semua bahan.ambil masing-masing sesendok sayur adonan kasih pewarna makanan masing masing.sisa adonan biarkan putih."
- "Panaskan teflon buat dadar.tuang adonan warna buat garis masing-masing adonan warna.lalu siram dgn adonan putih."
- "Buat isian. campur semua bahan masak dgn api kecil sampai bercampur rata"
- "Isi masing masing kulit dadar dengan inti kelapa.lipat amplop."
categories:
- Resep
tags:
- 118dadar
- gulung
- pelangi

katakunci: 118dadar gulung pelangi 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![118.Dadar gulung pelangi](https://img-global.cpcdn.com/recipes/52244f5751d0fc28/751x532cq70/118dadar-gulung-pelangi-foto-resep-utama.jpg)

Lagi mencari ide resep 118.dadar gulung pelangi yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal 118.dadar gulung pelangi yang enak selayaknya mempunyai aroma dan cita rasa yang dapat memancing selera kita.

Aneka Resep Dadar Gulung Unti Kelapa, Pisang, Pisang Coklat, Polkadot, Pelangi dan Mawar Spesial Lengkap Dengan Tips Cara Membuat Kulit Dadar Gulung Agar Tidak Pecah dan Lembut. Kue dadar gulung adalah salah satu resep kue basah tradisional yang terbuat dari bahan sederhana seperti. Jangan Lupa Subscribe,Like And Share Ya😉 Jangan Lupa Juga Tekan Tombol.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari 118.dadar gulung pelangi, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan 118.dadar gulung pelangi yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah 118.dadar gulung pelangi yang siap dikreasikan. Anda bisa membuat 118.Dadar gulung pelangi menggunakan 10 jenis bahan dan 4 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik 118.Dadar gulung pelangi:

1. Siapkan  Bahan kulit
1. Ambil 300 gr terigu
1. Ambil 500 ml santan
1. Siapkan 2 telur kocok lepas
1. Ambil 1 sdt garam
1. Ambil  Pewarna makanan,merah hijau, biru
1. Siapkan  Bahan isi
1. Siapkan 1/2 buah kelapa parut
1. Siapkan 200 gr gula merah(sesuai selera)
1. Gunakan secukupnya garam


Dadar gulung ini merupakan makanan khas Indonesia dan Malaysia yang dapat diisi dengan parutan kelapa yang dicampur. Kue dadar gulung pelangi _ -. Dadar gulung is a traditional Indonesian dessert consisting of a thin rice flour crêpe that is filled with grated coconut. Pancake batter is traditionally infused with pandan leaves which add flavor and impart a vibrant green color to the pancakes, but modern varieties often employ green food coloring instead. 

##### Langkah-langkah membuat 118.Dadar gulung pelangi:

1. Campur semua bahan.ambil masing-masing sesendok sayur adonan kasih pewarna makanan masing masing.sisa adonan biarkan putih.
1. Panaskan teflon buat dadar.tuang adonan warna buat garis masing-masing adonan warna.lalu siram dgn adonan putih.
1. Buat isian. campur semua bahan masak dgn api kecil sampai bercampur rata
1. Isi masing masing kulit dadar dengan inti kelapa.lipat amplop.


Dadar gulung (lit: \"rolled pancake/omelette\") is a popular traditional kue (traditional snack) of sweet coconut pancake. It is often described as an Indonesian coconut pancake. Dadar gulung is one of the popular snacks in Indonesia, especially in Java. Pasalnya dadar gulung merupakan makanan tradisional dan cukup merakyat. Hampir di seluruh toko kue, orang dengan mudah bisa menjumpai kue Dadar gulung tidak hanya bisa dikonsumsi sehari-hari saja lho, kamu juga bisa menyajikannya untuk acar-acara tertentu, seperti Lebaran, syukuran dan. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan 118.Dadar gulung pelangi yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
