---
description: "BIKIN NGILER! Ternyata Ini Resep Jajanan pasar PADAMARAN khas Jambi Anti Gagal"
title: "BIKIN NGILER! Ternyata Ini Resep Jajanan pasar PADAMARAN khas Jambi Anti Gagal"
slug: 1640-masakan-sederhana-bikin-ngiler-ternyata-ini-resep-jajanan-pasar-padamaran-khas-jambi-anti-gagal
date: 2020-06-27T22:52:16.760Z
image: https://img-global.cpcdn.com/recipes/31a59b714f23bbe8/751x532cq70/jajanan-pasar-padamaran-khas-jambi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/31a59b714f23bbe8/751x532cq70/jajanan-pasar-padamaran-khas-jambi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/31a59b714f23bbe8/751x532cq70/jajanan-pasar-padamaran-khas-jambi-foto-resep-utama.jpg
author: Howard Chandler
ratingvalue: 4.2
reviewcount: 8
recipeingredient:
- "150 gr tepung beras"
- "450 ml santan encer"
- "75 ml santan kental"
- "75 gr gula merah sisir halus"
- "50 ml air perasan daun sujipandan sekitar 25lembar daun suji"
- "1 sdt pasta pandan good quality"
- "1/4 sdt garam halus"
- "beberapa lembar daun pisang layukan dg cara dipanaskan di api"
recipeinstructions:
- "Pertama bikin alas pisang/takir dulu ya. Caranya ikuti step step di foto. Sisihkan. Jangan lupa juga panaskan kukusan."
- "Campur tepung, santan encer, garam di panci lalu masak di atas api kecil saja, sambil terus diaduk aduk, sampai tepung larut"
- "Masih di atas api, masukkan campuran air suji dan pasta pandan ke dalam santan. Sambil terus diaduk ya.."
- "Masak dan aduk terus hingga muncul gelembung di tepi panci dan adonan meletup letup, jangan sampai terlalu kental. Matikan api, dinginkan."
- "Sembari itu, tuang sisiran gula merah ke dalam wadah takir yg sudah dibuat tadi"
- "Tuang adonan sekitar 2sdm ke dalam takir, lalu tabur gula merah, lalu tuang lagi adonan 2sdm, lakukan ke semua wadah takir, diakhiri dg adonan di atas ya moms.."
- "Kukus dengan api sedang, sekitar 5 menit, lalu tuang santan kental 1sdm ke dalam masing2 wadah takir adonan tadi."
- "Kukus lagi api sedang sampai matang, sekitar 10 menit, hingga adonan terlihat mengental kayak bubur."
categories:
- Resep
tags:
- jajanan
- pasar
- padamaran

katakunci: jajanan pasar padamaran 
nutrition: 263 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT47M"
recipeyield: "3"
recipecategory: Dessert

---


![Jajanan pasar PADAMARAN khas Jambi](https://img-global.cpcdn.com/recipes/31a59b714f23bbe8/751x532cq70/jajanan-pasar-padamaran-khas-jambi-foto-resep-utama.jpg)

Anda sedang mencari ide resep jajanan pasar padamaran khas jambi yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal jajanan pasar padamaran khas jambi yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari jajanan pasar padamaran khas jambi, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan jajanan pasar padamaran khas jambi enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.

Kue yg susah susah gampang dicari. Tepung beras yg digunakan si Ibu pakai beras yg digiling sendiri. Padamaran yg di buat nya enak wangi dan lembut.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah jajanan pasar padamaran khas jambi yang siap dikreasikan. Anda dapat menyiapkan Jajanan pasar PADAMARAN khas Jambi menggunakan 8 bahan dan 8 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Jajanan pasar PADAMARAN khas Jambi:

1. Gunakan 150 gr tepung beras
1. Gunakan 450 ml santan encer
1. Gunakan 75 ml santan kental
1. Ambil 75 gr gula merah, sisir halus
1. Ambil 50 ml air perasan daun suji/pandan (sekitar 25lembar daun suji)
1. Sediakan 1 sdt pasta pandan good quality
1. Sediakan 1/4 sdt garam halus
1. Ambil beberapa lembar daun pisang, layukan dg cara dipanaskan di api


Salah satu jajan pasar yang sangat terkenal dimana-mana di Indonesia, yukkkk kita saksikan cara pembuatannya. jangan lupa like, comment dan subscribe yaa. Resep jajanan pasar yang pertama adalah Klepon ubi ungu. Kue ini termasuk pada aneka kue tradisional yang khas. Dimana pada umumnya kue ini dibuat menggunakan tepung ketan yang diberikan pewarna alami atau pewarna makanan dan juga terdapat isi gula merah di dalamnya. 

##### Cara meracik Jajanan pasar PADAMARAN khas Jambi:

1. Pertama bikin alas pisang/takir dulu ya. Caranya ikuti step step di foto. Sisihkan. Jangan lupa juga panaskan kukusan.
1. Campur tepung, santan encer, garam di panci lalu masak di atas api kecil saja, sambil terus diaduk aduk, sampai tepung larut
1. Masih di atas api, masukkan campuran air suji dan pasta pandan ke dalam santan. Sambil terus diaduk ya..
1. Masak dan aduk terus hingga muncul gelembung di tepi panci dan adonan meletup letup, jangan sampai terlalu kental. Matikan api, dinginkan.
1. Sembari itu, tuang sisiran gula merah ke dalam wadah takir yg sudah dibuat tadi
1. Tuang adonan sekitar 2sdm ke dalam takir, lalu tabur gula merah, lalu tuang lagi adonan 2sdm, lakukan ke semua wadah takir, diakhiri dg adonan di atas ya moms..
1. Kukus dengan api sedang, sekitar 5 menit, lalu tuang santan kental 1sdm ke dalam masing2 wadah takir adonan tadi.
1. Kukus lagi api sedang sampai matang, sekitar 10 menit, hingga adonan terlihat mengental kayak bubur.


Jajanan pasar merupakan penganan yang bisa dibeli dari pasar tradisional. Jenisnya pun beragam, mulai dari yang rasanya manis hingga Kue bugis adalah salah satu jenis kue basah tradisional khas Sulawesi. Kue ini berbahan dasar parutan kelapa yang dipadukan. Kue khas Jambi berhasil membuat orang jambi yang merantau kangen pulang kampung. Padamaran adalah kue tradisional Jambi yang terbuat dari campuran tepung beras dan santan yang dikemas di dalam takir Kue gandus merupakan salah satu jajanan pasar yang dimiliki oleh jambi. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Jajanan pasar PADAMARAN khas Jambi yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
