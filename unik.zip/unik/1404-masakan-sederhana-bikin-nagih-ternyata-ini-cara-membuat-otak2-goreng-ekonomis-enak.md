---
description: "BIKIN NAGIH! Ternyata Ini Cara Membuat Otak2 Goreng Ekonomis Enak"
title: "BIKIN NAGIH! Ternyata Ini Cara Membuat Otak2 Goreng Ekonomis Enak"
slug: 1404-masakan-sederhana-bikin-nagih-ternyata-ini-cara-membuat-otak2-goreng-ekonomis-enak
date: 2020-07-07T14:59:45.816Z
image: https://img-global.cpcdn.com/recipes/cc05ed6fe10441e9/751x532cq70/otak2-goreng-ekonomis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cc05ed6fe10441e9/751x532cq70/otak2-goreng-ekonomis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cc05ed6fe10441e9/751x532cq70/otak2-goreng-ekonomis-foto-resep-utama.jpg
author: Stanley Cunningham
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- "100 gr tepung terigu"
- "70 gr tepung tapioka"
- "1/4 sdt soda kue"
- "1 sdm udang rebon haluskan"
- "1/2 sdt lada bubuk"
- "3 siung bawang putih haluskan"
- "1 butir telur"
- "2 batang daun bawang iris tipis"
- "2 sdm santan instant"
- "100 ml air"
- "secukupnya Gula garam royc"
recipeinstructions:
- "Campurkan terigu, bumbu halus, daun bawang, lada, gula, garam, royc* dan air. Aduk sampai tercampur rata, masak di api kecil dan aduk2 sampai menjadi bubur."
- "Setelah agak dingin masukkan telur, santan, soda kue, aduk sampai rata kemudian tambahkan tapioka sedikit demi sedikit, aduk kembali sampai bisa dibentuk."
- "Ambil 1sdm adonan kemudian pilin memanjang lumuri tangan dg minyak goreng agar tidak lengket, setelah selesai rebus otak2 tunggu sampai mengapung dan angkat. Setelah dingin baru digoreng, sajikan dg saos sambal."
categories:
- Resep
tags:
- otak2
- goreng
- ekonomis

katakunci: otak2 goreng ekonomis 
nutrition: 292 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Dessert

---


![Otak2 Goreng Ekonomis](https://img-global.cpcdn.com/recipes/cc05ed6fe10441e9/751x532cq70/otak2-goreng-ekonomis-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep otak2 goreng ekonomis yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal otak2 goreng ekonomis yang enak harusnya sih memiliki aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari otak2 goreng ekonomis, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan otak2 goreng ekonomis yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat otak2 goreng ekonomis yang siap dikreasikan. Anda bisa menyiapkan Otak2 Goreng Ekonomis menggunakan 11 bahan dan 3 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Otak2 Goreng Ekonomis:

1. Ambil 100 gr tepung terigu
1. Gunakan 70 gr tepung tapioka
1. Gunakan 1/4 sdt soda kue
1. Ambil 1 sdm udang rebon haluskan
1. Gunakan 1/2 sdt lada bubuk
1. Sediakan 3 siung bawang putih haluskan
1. Gunakan 1 butir telur
1. Gunakan 2 batang daun bawang iris tipis
1. Gunakan 2 sdm santan instant
1. Sediakan 100 ml air
1. Siapkan secukupnya Gula, garam, royc*




##### Langkah-langkah meracik Otak2 Goreng Ekonomis:

1. Campurkan terigu, bumbu halus, daun bawang, lada, gula, garam, royc* dan air. Aduk sampai tercampur rata, masak di api kecil dan aduk2 sampai menjadi bubur.
1. Setelah agak dingin masukkan telur, santan, soda kue, aduk sampai rata kemudian tambahkan tapioka sedikit demi sedikit, aduk kembali sampai bisa dibentuk.
1. Ambil 1sdm adonan kemudian pilin memanjang lumuri tangan dg minyak goreng agar tidak lengket, setelah selesai rebus otak2 tunggu sampai mengapung dan angkat. Setelah dingin baru digoreng, sajikan dg saos sambal.




Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Otak2 Goreng Ekonomis yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi inspirasi untuk berbisnis kuliner. Selamat mencoba!
