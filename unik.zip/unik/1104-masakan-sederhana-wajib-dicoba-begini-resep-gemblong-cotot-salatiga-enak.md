---
description: "WAJIB DICOBA! Begini Resep Gemblong Cotot Salatiga Enak"
title: "WAJIB DICOBA! Begini Resep Gemblong Cotot Salatiga Enak"
slug: 1104-masakan-sederhana-wajib-dicoba-begini-resep-gemblong-cotot-salatiga-enak
date: 2020-04-07T15:21:45.107Z
image: https://img-global.cpcdn.com/recipes/0e2a4321dd93beef/751x532cq70/gemblong-cotot-salatiga-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0e2a4321dd93beef/751x532cq70/gemblong-cotot-salatiga-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0e2a4321dd93beef/751x532cq70/gemblong-cotot-salatiga-foto-resep-utama.jpg
author: Leah Gonzales
ratingvalue: 4.2
reviewcount: 15
recipeingredient:
- "1/2 kg singkong"
- "1/4 sdt garam"
- "1 daun pandan"
- "1/2 cup gula"
- "1 sdm butter"
- " Bahan baluran kering"
- "4 sdm terigu"
- "1 sdt gula"
- "Sejumput garam"
- "optional Bahan basah"
- "2 sdm terigu"
- "2 air matang"
recipeinstructions:
- "Bersihkan singkong dan kupas lalu potong2. Karena saya tidak pakai semuanya jadi sisanya saya bungkus tissu dapur dan masukan ke plastik simpan di kulkas ya. Bisa tahan 2 hari kalau disimpan diluat nanti bau angin jd ga bisa dimakan."
- "Siapkan kukusan kemudian kukus singkong dan daun pandan. Kukus selama 30 menit atau hingga matang."
- "Setelah matang buang serat2 nya dan segera haluskan dengan masher atau ulekan yang sudah dilapisi plastik"
- "Campurkan singkong dengan butter hingga kalis. Ambil sekitar 2 sdm kemudian pipihkan. Isi dengan gula ditengah lalu remas hingga rapat"
- "Masukan di freezer selama minimal 10 menit sebelum digoreng. Goreng dengan api kecil hingga matang. Balurkan ke tepung kering lalu masak sebelum digoreng supaya ga ambyar. Bisa juga dari tepung kering ke tepung basah baru di goreng"
- "Nah ini saya ga baluri langsung goreng jd ambyar"
- "Jika sisa bisa dibekukan di kulkas bisa tahan 7 hari. Enaknya anget2 ya"
- "Selamat menikmati"
categories:
- Resep
tags:
- gemblong
- cotot
- salatiga

katakunci: gemblong cotot salatiga 
nutrition: 215 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Gemblong Cotot Salatiga](https://img-global.cpcdn.com/recipes/0e2a4321dd93beef/751x532cq70/gemblong-cotot-salatiga-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gemblong cotot salatiga yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gemblong cotot salatiga yang enak selayaknya memiliki aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari gemblong cotot salatiga, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan gemblong cotot salatiga yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.

Gemblong cotot terbuat dari ubi singkong yang direbus kemudian dihaluskan. Dibagian tengah diberi gula pasir, gula jawa. Singkong Keju & Gemblong Cotot Khas Salatiga Kini tersedia di.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat gemblong cotot salatiga yang siap dikreasikan. Anda bisa membuat Gemblong Cotot Salatiga memakai 12 bahan dan 8 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk membuat Gemblong Cotot Salatiga:

1. Sediakan 1/2 kg singkong
1. Siapkan 1/4 sdt garam
1. Gunakan 1 daun pandan
1. Ambil 1/2 cup gula
1. Siapkan 1 sdm butter
1. Gunakan  Bahan baluran kering
1. Sediakan 4 sdm terigu
1. Gunakan 1 sdt gula
1. Siapkan Sejumput garam
1. Ambil optional Bahan basah
1. Sediakan 2 sdm terigu
1. Ambil 2 air matang


Diponegoro Salatiga, buat acara Berbagi Cerita Relawan Keluarga Kita. The Gambling.co.uk Network, bringing you industry news, reviews of UK gambling sites, links to the best UK gambling destinations, and a comprehensive gambling directory. Salatiga is een stadsgemeente (kota otonom of kotamadya) in de Indonesische provincie Midden-Java. Deze gemeente wordt helemaal omgeven door het regentschap Semarang. 

##### Langkah-langkah mengolah Gemblong Cotot Salatiga:

1. Bersihkan singkong dan kupas lalu potong2. Karena saya tidak pakai semuanya jadi sisanya saya bungkus tissu dapur dan masukan ke plastik simpan di kulkas ya. Bisa tahan 2 hari kalau disimpan diluat nanti bau angin jd ga bisa dimakan.
1. Siapkan kukusan kemudian kukus singkong dan daun pandan. Kukus selama 30 menit atau hingga matang.
1. Setelah matang buang serat2 nya dan segera haluskan dengan masher atau ulekan yang sudah dilapisi plastik
1. Campurkan singkong dengan butter hingga kalis. Ambil sekitar 2 sdm kemudian pipihkan. Isi dengan gula ditengah lalu remas hingga rapat
1. Masukan di freezer selama minimal 10 menit sebelum digoreng. Goreng dengan api kecil hingga matang. Balurkan ke tepung kering lalu masak sebelum digoreng supaya ga ambyar. Bisa juga dari tepung kering ke tepung basah baru di goreng
1. Nah ini saya ga baluri langsung goreng jd ambyar
1. Jika sisa bisa dibekukan di kulkas bisa tahan 7 hari. Enaknya anget2 ya
1. Selamat menikmati


Gemblong Cotot is a traditional food from Central Java, Indonesia. Tarakan, Tarakan City, East Kalimantan, Indonesia. Kue Singkong Gemblong Cocot memiliki bentuk khas, yaitu berbentuk bulat lonjong. Meskipun ada juga yang dibuat dengan bentuk lain tetapi olahan singkong parut ini lebih sering dibentuk bulatan. Kue gemblong cotot pada umumnya berbentuk seperti telur. 

Bagaimana? Gampang kan? Itulah cara menyiapkan gemblong cotot salatiga yang bisa Anda lakukan di rumah. Selamat mencoba!
