---
description: "BIKIN NAGIH! Ternyata Ini Resep Rahasia 29. Kuih Seri Muka / Pulut Srikaya 🥥😻 Anti Gagal"
title: "BIKIN NAGIH! Ternyata Ini Resep Rahasia 29. Kuih Seri Muka / Pulut Srikaya 🥥😻 Anti Gagal"
slug: 1243-masakan-sederhana-bikin-nagih-ternyata-ini-resep-rahasia-29-kuih-seri-muka-pulut-srikaya-anti-gagal
date: 2020-08-22T15:07:44.476Z
image: https://img-global.cpcdn.com/recipes/54ce590dff134932/751x532cq70/29-kuih-seri-muka-pulut-srikaya-🥥😻-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/54ce590dff134932/751x532cq70/29-kuih-seri-muka-pulut-srikaya-🥥😻-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/54ce590dff134932/751x532cq70/29-kuih-seri-muka-pulut-srikaya-🥥😻-foto-resep-utama.jpg
author: Susie Lopez
ratingvalue: 3.5
reviewcount: 11
recipeingredient:
- " Bagian putih  pulut"
- "300 gram beras pulut  beras ketan"
- "1/2 sdt garam"
- "2 helai daun pandan disimpul"
- "100 ml santan"
- "100 ml air"
- " Bagian hijau"
- "2 butir telur kocok lepas"
- "100 gram gula halus atau sesuai selera"
- "25 gram tepung terigu"
- "20 gram tepung maizena"
- "200 ml sari pandan 8 lembar pandan blendersaring ambil airny"
- "150 ml santan"
- "1/2 sdt garam"
recipeinstructions:
- "Cuci bersih lalu rendam beras pulut minimal 2 jam dalam air bersih. Kurleb air rendaman setinggi 1 ruas jari. Stlh 2 jam, masukkan beras pulut bersama garam, santan cair dan daun pandan ke dalam rice cooker & masak hingga matang"
- "Setelah beras pulut matang, siapkan loyang bundar (*saya ○ 18cm), alasi dg baking paper, sapu bagian dalam loyang dan baking paper dg minyak goreng. Lalu masukkan beras pulut ke dlm loyang, ratakan sambil ditekan2 agar tdk ada bagian berongga. Lalu sisihkan sementara kita lanjut membuat bagian hijau."
- "Untuk bagian hijau, kocok lepas telur dgn gula halus dan masukkan perlahan & sdkt2 sari pandan dan santan. Sari pandan sy dpt dri 8lbr daun pandan diblender dg 200ml air, lalu disaring ambil airnya. Ayak tepung terigu dan maizena, lalu campur rata dgn adonan cair. Saring adonan untuk menghilangkan gerindil2. Setelah disaring, adonan lebih mulus."
- "Masak adonan hijau di panci dgn api sedang sambil diaduk agar tepung tdk mengendap di dasar panci. Jika sdh mengental, tuang ke dalam loyang berisi adonan putih."
- "Kukus loyang yg telah berisi adonan pulut dan hijau. Bungkus tutup kukusan dg kain spy air tdk menetes ke permukaan kuih serimuka. Kurleb waktu mengukus 30 mnt. Stlh dikukus kue masih lunak sekali, jgn panik. Setelah didinginkan akan lebih padat 🤗🥰😍 Stlh 30 mnt mengukus, keluarkan kue dr kukusan, dinginkan suhu ruangan. Lalu simpan dlm kulkas minimal 4 jam sblm dikeluarkan dri loyang & dipotong2."
- "Jika langsung dikeluarkan dri loyang & dipotong begitu dingin, biasanya kue akan hancur dan terkesan gagal. 🥰 Tips dri sy : dinginkan dulu minimal 4jm, potongnya pakai spatula plastik ya moms yg diolesi minyak goreng. Klo dipotong dg pisau meskipun sdh dioles minyak, potongannya tdk bs rapi & masih banyak lengket2nya. Sy lebih suka menikmati kuih serimuka dlm keadaan dingin, ditemani teh hangat ☕🥰😍"
categories:
- Resep
tags:
- 29
- kuih
- seri

katakunci: 29 kuih seri 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT36M"
recipeyield: "3"
recipecategory: Dessert

---


![29. Kuih Seri Muka / Pulut Srikaya 🥥😻](https://img-global.cpcdn.com/recipes/54ce590dff134932/751x532cq70/29-kuih-seri-muka-pulut-srikaya-🥥😻-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep 29. kuih seri muka / pulut srikaya 🥥😻 yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal 29. kuih seri muka / pulut srikaya 🥥😻 yang enak seharusnya memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari 29. kuih seri muka / pulut srikaya 🥥😻, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan 29. kuih seri muka / pulut srikaya 🥥😻 yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.

#kuihserimuka #pulutsekaya #kuihputrisalat #kuih Kuih Seri Muka, kuih salat or pulut sekaya, is one of Malaysians favourite sweet, creamy and salty dessert. Seri muka is a Malaysian steamed layer cake (kuih) which consist of a glutinous rice (thai sweet rice - sticky rice) layer steamed with Kuih means cakes in Malay. Seri Muka translates to radiant face or pretty face.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah 29. kuih seri muka / pulut srikaya 🥥😻 yang siap dikreasikan. Anda bisa menyiapkan 29. Kuih Seri Muka / Pulut Srikaya 🥥😻 menggunakan 14 jenis bahan dan 6 langkah pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat 29. Kuih Seri Muka / Pulut Srikaya 🥥😻:

1. Gunakan  Bagian putih / pulut
1. Siapkan 300 gram beras pulut / beras ketan
1. Gunakan 1/2 sdt garam
1. Gunakan 2 helai daun pandan disimpul
1. Sediakan 100 ml santan
1. Sediakan 100 ml air
1. Gunakan  Bagian hijau
1. Sediakan 2 butir telur kocok lepas
1. Siapkan 100 gram gula halus (*atau sesuai selera)
1. Gunakan 25 gram tepung terigu
1. Sediakan 20 gram tepung maizena
1. Siapkan 200 ml sari pandan (8 lembar pandan blender,saring ambil airny)
1. Ambil 150 ml santan
1. Ambil 1/2 sdt garam


Kuih seri muka merupakan sejenis kuih talam tradisi yang berasal dari negara kita. Ia lazimnya dihasilkan di dalam talam yang besar dan berbentuk bulat atau segiempat. Setelah masak, ia kemudiannya dipotong mengikut saiz hidangan. Kuih ini adalah kuih kegemaran suami saya. 

##### Langkah-langkah membuat 29. Kuih Seri Muka / Pulut Srikaya 🥥😻:

1. Cuci bersih lalu rendam beras pulut minimal 2 jam dalam air bersih. Kurleb air rendaman setinggi 1 ruas jari. Stlh 2 jam, masukkan beras pulut bersama garam, santan cair dan daun pandan ke dalam rice cooker & masak hingga matang
1. Setelah beras pulut matang, siapkan loyang bundar (*saya ○ 18cm), alasi dg baking paper, sapu bagian dalam loyang dan baking paper dg minyak goreng. Lalu masukkan beras pulut ke dlm loyang, ratakan sambil ditekan2 agar tdk ada bagian berongga. Lalu sisihkan sementara kita lanjut membuat bagian hijau.
1. Untuk bagian hijau, kocok lepas telur dgn gula halus dan masukkan perlahan & sdkt2 sari pandan dan santan. Sari pandan sy dpt dri 8lbr daun pandan diblender dg 200ml air, lalu disaring ambil airnya. Ayak tepung terigu dan maizena, lalu campur rata dgn adonan cair. Saring adonan untuk menghilangkan gerindil2. Setelah disaring, adonan lebih mulus.
1. Masak adonan hijau di panci dgn api sedang sambil diaduk agar tepung tdk mengendap di dasar panci. Jika sdh mengental, tuang ke dalam loyang berisi adonan putih.
1. Kukus loyang yg telah berisi adonan pulut dan hijau. Bungkus tutup kukusan dg kain spy air tdk menetes ke permukaan kuih serimuka. Kurleb waktu mengukus 30 mnt. Stlh dikukus kue masih lunak sekali, jgn panik. Setelah didinginkan akan lebih padat 🤗🥰😍 Stlh 30 mnt mengukus, keluarkan kue dr kukusan, dinginkan suhu ruangan. Lalu simpan dlm kulkas minimal 4 jam sblm dikeluarkan dri loyang & dipotong2.
1. Jika langsung dikeluarkan dri loyang & dipotong begitu dingin, biasanya kue akan hancur dan terkesan gagal. 🥰 Tips dri sy : dinginkan dulu minimal 4jm, potongnya pakai spatula plastik ya moms yg diolesi minyak goreng. Klo dipotong dg pisau meskipun sdh dioles minyak, potongannya tdk bs rapi & masih banyak lengket2nya. Sy lebih suka menikmati kuih serimuka dlm keadaan dingin, ditemani teh hangat ☕🥰😍


Seri muka antara kuih yang paling laris kat warung dia. Ramai customer dia lebih suka seri muka gula melaka. Masukkan beras pulut, santan dan garam ke dalam loyang. Pulut Seri Muka kalau Min jumpa wajib beli. Ini adalah antara kuih tradisional Melayu sejak dulu-dulu lagi. 

Terima kasih telah membaca resep yang tim kami tampilkan di sini. Harapan kami, olahan 29. Kuih Seri Muka / Pulut Srikaya 🥥😻 yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
