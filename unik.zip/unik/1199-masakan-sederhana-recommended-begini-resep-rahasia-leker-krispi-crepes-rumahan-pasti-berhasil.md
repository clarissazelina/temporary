---
description: "RECOMMENDED! Begini Resep Rahasia Leker krispi (crepes rumahan) Pasti Berhasil"
title: "RECOMMENDED! Begini Resep Rahasia Leker krispi (crepes rumahan) Pasti Berhasil"
slug: 1199-masakan-sederhana-recommended-begini-resep-rahasia-leker-krispi-crepes-rumahan-pasti-berhasil
date: 2020-04-26T22:36:59.573Z
image: https://img-global.cpcdn.com/recipes/47368441ca659725/751x532cq70/leker-krispi-crepes-rumahan-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/47368441ca659725/751x532cq70/leker-krispi-crepes-rumahan-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/47368441ca659725/751x532cq70/leker-krispi-crepes-rumahan-foto-resep-utama.jpg
author: Linnie Butler
ratingvalue: 4.5
reviewcount: 4
recipeingredient:
- "10 SDM tepung beras"
- "8 SDM terigu"
- "1/2 SDM baking powder"
- "6 SDM gula pasir"
- "300 ml air"
- "1 butir telor"
- "Sejumput garam"
- " Topping sukasuka me  selai blueberry"
- " Gula pasir untuk taburan"
recipeinstructions:
- "Campur semua bahan dan naduk sampai halus."
- "Panaskan teflon, tuang 1 sendok sayur kemudian goyang goyangkan sampai setipis mungkin."
- "Taburi dengan gula pasir dan tambahkan topping. Masak dengan api kecil sampai crepes berwarna cokelat biar garing."
- "Lipat dan angkat. Sajikan dengan minuman hangat di sore yang hujan."
- "Selamat mencoba..."
categories:
- Resep
tags:
- leker
- krispi
- crepes

katakunci: leker krispi crepes 
nutrition: 281 calories
recipecuisine: Indonesian
preptime: "PT24M"
cooktime: "PT51M"
recipeyield: "2"
recipecategory: Dinner

---


![Leker krispi (crepes rumahan)](https://img-global.cpcdn.com/recipes/47368441ca659725/751x532cq70/leker-krispi-crepes-rumahan-foto-resep-utama.jpg)

Sedang mencari ide resep leker krispi (crepes rumahan) yang unik? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal leker krispi (crepes rumahan) yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari leker krispi (crepes rumahan), pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing jika mau menyiapkan leker krispi (crepes rumahan) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.

Hai teman-teman, kali ini saya akan share resep cara membuat Crepes atau kue leker yang crispy dan super renyah. Karena saya ga punya crepe pan jadi cukup. Resep Crepes Teflon Crispy Super Renyah!


Di bawah ini ada beberapa cara mudah dan praktis dalam mengolah leker krispi (crepes rumahan) yang siap dikreasikan. Anda bisa membuat Leker krispi (crepes rumahan) memakai 9 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Leker krispi (crepes rumahan):

1. Sediakan 10 SDM tepung beras
1. Ambil 8 SDM terigu
1. Gunakan 1/2 SDM baking powder
1. Ambil 6 SDM gula pasir
1. Ambil 300 ml air
1. Ambil 1 butir telor
1. Ambil Sejumput garam
1. Ambil  Topping suka-suka (me : selai blueberry)
1. Sediakan  Gula pasir untuk taburan


Taukah bunda tidak hanya ayam Kentucky saja yang bisa diolah menjadi menu makanan. Crispy Vietnamese Crepes (Banh Xeo) — Evergreen Kitchen. Stuff these crispy crepes to your heart\'s desire. Bánh xèo tastes best on a cold and raining day. 

##### Langkah-langkah menyiapkan Leker krispi (crepes rumahan):

1. Campur semua bahan dan naduk sampai halus.
1. Panaskan teflon, tuang 1 sendok sayur kemudian goyang goyangkan sampai setipis mungkin.
1. Taburi dengan gula pasir dan tambahkan topping. Masak dengan api kecil sampai crepes berwarna cokelat biar garing.
1. Lipat dan angkat. Sajikan dengan minuman hangat di sore yang hujan.
1. Selamat mencoba...


There\'s something about the cold and rain that beckon my senses to the. Boleh dibilang crepes adalah leker versi modern. Kue leker memang mirip crepes namun kue leker lebih lembut di bagian dalamnya. Dengan membuat leker yang beraneka rasa maka akan lebih menarik banyak konsumen, sehingga tidak mustahil jika kue leker bisa. Resep Crepes Leker Ala D Crepe Renyah Crispy Sederhana Spesial Asli Enak. 

Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Leker krispi (crepes rumahan) yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
