---
description: "BIKIN NAGIH! Begini Cara Membuat Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil Enak"
title: "BIKIN NAGIH! Begini Cara Membuat Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil Enak"
slug: 1260-masakan-sederhana-bikin-nagih-begini-cara-membuat-day6lapek-bugih-khas-minangprramadhan-takjil-enak
date: 2020-07-02T16:07:19.040Z
image: https://img-global.cpcdn.com/recipes/7070d398f0e31944/751x532cq70/day6lapek-bugih-khas-minangprramadhan_takjil-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7070d398f0e31944/751x532cq70/day6lapek-bugih-khas-minangprramadhan_takjil-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7070d398f0e31944/751x532cq70/day6lapek-bugih-khas-minangprramadhan_takjil-foto-resep-utama.jpg
author: Marc Griffin
ratingvalue: 3.6
reviewcount: 8
recipeingredient:
- " Bahan kulit"
- "250 gr santan kental"
- "1/8 sdm garam"
- "150 gr tepung ketan hitam"
- "50 gr tepung ketan putih"
- " Bahan isi"
- "1/4 butir kelapa parut dari kelapa yang udah agak tua"
- "2 lembar daun pandan ukuran kecil"
- "1/8 sdt garam"
- "1/2 sdm margarin"
- " Bahan areh"
- "175 ml santan kental"
- "1 sendok makan tepung maizena larutkan dengan sedikit air"
- "1/8 sendok teh garam"
recipeinstructions:
- "Masak santan dan garam hingga mendidih (santan yang buat kulit)"
- "Tuang ke dalam campuran tepung (ketan hitam dan ketan putih). Aduk-aduk hingga rata. Sisihkan (saran saya, jangan tuang semua. Hentikan jika adonan sudah kalis). Boleh ditambahi minyak dikit, agar mudah saat dibentuk nantinya Sisihkan"
- "Masak bahan isian hingga berserabut. Sisihkan"
- "Masak bahan areh (vla kelapa). Didihkan dulu santan yang dibubuhi sedikit garam. Terakhir tambahkan larutan maizena. Masak hingga agak mengental. Sisihkan"
- "Siapkan daun (daunnya saya angetin dulu di atas api kompor biar layu, agar mudah dalam penggunaannya nanti)"
- "Olesi daun dengan minyak goreng."
- "Ambil adonan kulit secukupnya, pipihkan, masukkan bahan isian, tutup dan bulatkan. Taruh di daun, bubuhi 1/2 sdm vla santan. Bungkus sesuai selera. Demikian hingga selesai."
- "Kukus hingga matang (ambil satu buah, koreksi kematengan"
- "Lapek bugih siap untuk dihidangkan :)"
categories:
- Resep
tags:
- day6lapek
- bugih
- khas

katakunci: day6lapek bugih khas 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT50M"
recipeyield: "1"
recipecategory: Lunch

---


![Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil](https://img-global.cpcdn.com/recipes/7070d398f0e31944/751x532cq70/day6lapek-bugih-khas-minangprramadhan_takjil-foto-resep-utama.jpg)

Lagi mencari inspirasi resep day6.lapek bugih khas minang#prramadhan_takjil yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal day6.lapek bugih khas minang#prramadhan_takjil yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari day6.lapek bugih khas minang#prramadhan_takjil, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan day6.lapek bugih khas minang#prramadhan_takjil enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.




Nah, kali ini kita coba, yuk, ciptakan day6.lapek bugih khas minang#prramadhan_takjil sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil menggunakan 14 bahan dan 9 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil:

1. Sediakan  Bahan kulit:
1. Siapkan 250 gr santan kental
1. Gunakan 1/8 sdm garam
1. Gunakan 150 gr tepung ketan hitam
1. Ambil 50 gr tepung ketan putih
1. Sediakan  Bahan isi:
1. Gunakan 1/4 butir kelapa parut (dari kelapa yang udah agak tua)
1. Sediakan 2 lembar daun pandan ukuran kecil
1. Sediakan 1/8 sdt garam
1. Ambil 1/2 sdm margarin
1. Siapkan  Bahan areh:
1. Sediakan 175 ml santan kental
1. Ambil 1 sendok makan tepung maizena (larutkan dengan sedikit air)
1. Ambil 1/8 sendok teh garam




##### Langkah-langkah membuat Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil:

1. Masak santan dan garam hingga mendidih (santan yang buat kulit)
1. Tuang ke dalam campuran tepung (ketan hitam dan ketan putih). Aduk-aduk hingga rata. Sisihkan (saran saya, jangan tuang semua. Hentikan jika adonan sudah kalis). Boleh ditambahi minyak dikit, agar mudah saat dibentuk nantinya Sisihkan
1. Masak bahan isian hingga berserabut. Sisihkan
1. Masak bahan areh (vla kelapa). Didihkan dulu santan yang dibubuhi sedikit garam. Terakhir tambahkan larutan maizena. Masak hingga agak mengental. Sisihkan
1. Siapkan daun (daunnya saya angetin dulu di atas api kompor biar layu, agar mudah dalam penggunaannya nanti)
1. Olesi daun dengan minyak goreng.
1. Ambil adonan kulit secukupnya, pipihkan, masukkan bahan isian, tutup dan bulatkan. Taruh di daun, bubuhi 1/2 sdm vla santan. Bungkus sesuai selera. Demikian hingga selesai.
1. Kukus hingga matang (ambil satu buah, koreksi kematengan
1. Lapek bugih siap untuk dihidangkan :)




Terima kasih telah membaca resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Day6.Lapek Bugih Khas Minang#PrRamadhan_Takjil yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
