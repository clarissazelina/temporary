---
description: "BIKIN NGILER! Ternyata Ini Cara Membuat Prol Nyes Anti Gagal"
title: "BIKIN NGILER! Ternyata Ini Cara Membuat Prol Nyes Anti Gagal"
slug: 1487-masakan-sederhana-bikin-ngiler-ternyata-ini-cara-membuat-prol-nyes-anti-gagal
date: 2020-09-13T01:25:14.159Z
image: https://img-global.cpcdn.com/recipes/6ee8900b04073d90/751x532cq70/prol-nyes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6ee8900b04073d90/751x532cq70/prol-nyes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6ee8900b04073d90/751x532cq70/prol-nyes-foto-resep-utama.jpg
author: Gregory Johnson
ratingvalue: 3.5
reviewcount: 7
recipeingredient:
- "600 ml santan dari 12 butir kelapa"
- "1 lembar daun pandan"
- "6 lembar roti tawar berkulit"
- "100 gram gula pasir"
- "Sejumput garam"
- "Sejumput vanili bubuk"
- "1 sdt rhum optional"
- "1 butir telur saya 2 butir karena telur nya kecil"
- "1 bungkus (7 gr) agaragar putih plain"
- " Coklat bubuk secukupnya optional"
recipeinstructions:
- "Rebus santan sambil diaduk-aduk supaya tidak pecah sampai mendidih. Biarkan hangat/dingin. Siapkan roti tawar kemudian robek-robek roti tawar tambahkan gula pasir, garam, vanili bubuk"
- "Tuang santan ke dalam wadah yang berisi roti tawar yang sudah dirobek tadi diamkan selama 5 menit agar roti lembut dan santan meresap kedalam roti"
- "Pecahkan telur, tambahkan rhum dan kocok lepas, tuang kocokan telur kedalam wadah roti yang sudah terendam santan aduk hingga rata kemudian tambahkan agar-agar bubuk aduk hingga rata kemudian tuang kedalam loyang yang sudah dialasi kertas roti atau plastik yang sebelumnya dipoles minyak dasar loyangnya"
- "Kukus selama 30-40 menit, kukusan sebelumnya sudah dipanaskan terlebih dahulu jangan lupa tutup kukusan dilapisi dengan serbet double, saya buat variasi dengan menambahkan bubuk coklat dicampur sedikit air kemudian buat motif marmer diatasnya,setelah uap panas nya hilang dinginkan dikulkas"
categories:
- Resep
tags:
- prol
- nyes

katakunci: prol nyes 
nutrition: 269 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dinner

---


![Prol Nyes](https://img-global.cpcdn.com/recipes/6ee8900b04073d90/751x532cq70/prol-nyes-foto-resep-utama.jpg)

Anda sedang mencari ide resep prol nyes yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal prol nyes yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari prol nyes, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan prol nyes enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian istimewa.




Di bawah ini ada beberapa tips dan trik praktis untuk membuat prol nyes yang siap dikreasikan. Anda bisa menyiapkan Prol Nyes menggunakan 10 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Prol Nyes:

1. Siapkan 600 ml santan dari 1/2 butir kelapa
1. Ambil 1 lembar daun pandan
1. Siapkan 6 lembar roti tawar berkulit
1. Gunakan 100 gram gula pasir
1. Gunakan Sejumput garam
1. Gunakan Sejumput vanili bubuk
1. Gunakan 1 sdt rhum (optional)
1. Siapkan 1 butir telur saya 2 butir karena telur nya kecil
1. Ambil 1 bungkus (7 gr) agar-agar putih /plain
1. Ambil  Coklat bubuk secukupnya (optional)




##### Cara menyiapkan Prol Nyes:

1. Rebus santan sambil diaduk-aduk supaya tidak pecah sampai mendidih. Biarkan hangat/dingin. Siapkan roti tawar kemudian robek-robek roti tawar tambahkan gula pasir, garam, vanili bubuk
1. Tuang santan ke dalam wadah yang berisi roti tawar yang sudah dirobek tadi diamkan selama 5 menit agar roti lembut dan santan meresap kedalam roti
1. Pecahkan telur, tambahkan rhum dan kocok lepas, tuang kocokan telur kedalam wadah roti yang sudah terendam santan aduk hingga rata kemudian tambahkan agar-agar bubuk aduk hingga rata kemudian tuang kedalam loyang yang sudah dialasi kertas roti atau plastik yang sebelumnya dipoles minyak dasar loyangnya
1. Kukus selama 30-40 menit, kukusan sebelumnya sudah dipanaskan terlebih dahulu jangan lupa tutup kukusan dilapisi dengan serbet double, saya buat variasi dengan menambahkan bubuk coklat dicampur sedikit air kemudian buat motif marmer diatasnya,setelah uap panas nya hilang dinginkan dikulkas




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Prol Nyes yang mudah di atas dapat membantu Anda menyiapkan hidangan yang lezat untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
