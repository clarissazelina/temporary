---
description: "TERUNGKAP! Ternyata Ini Resep Rahasia Sarang semut Karamel Takaran gelas & sendok Enak"
title: "TERUNGKAP! Ternyata Ini Resep Rahasia Sarang semut Karamel Takaran gelas & sendok Enak"
slug: 1181-masakan-sederhana-terungkap-ternyata-ini-resep-rahasia-sarang-semut-karamel-takaran-gelas-sendok-enak
date: 2020-06-17T11:42:26.714Z
image: https://img-global.cpcdn.com/recipes/1d2bb798332fd89c/751x532cq70/sarang-semut-karamel-takaran-gelas-sendok-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1d2bb798332fd89c/751x532cq70/sarang-semut-karamel-takaran-gelas-sendok-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1d2bb798332fd89c/751x532cq70/sarang-semut-karamel-takaran-gelas-sendok-foto-resep-utama.jpg
author: Ina Farmer
ratingvalue: 4.5
reviewcount: 5
recipeingredient:
- " Bahan Caramel"
- "400 gr gula 2 12 gelas blimbing atau 22 sendok mkan"
- "400 ml air panas 2 gelas belimbing"
- " kalo mau bikin stengah resep tinggal di bagi 2 aja ya"
- " Bahan adonan"
- "4 butir telur"
- "160 gr margarin atau 34 margarin sachet me palmia royal atau"
- " bisa ganti minyak kemasan 1 gelas"
- "120 gr tepung terigu 1 gelas belimbing  8 Sdm munjung"
- "120 gr tapioka atau sagu 1 12 gelas belimbing 12 sdm munjung"
- "4 bks Kental manis mefrisian flag"
- "1 sdt baking powder"
- "1 sdt baking sodasoda kue"
recipeinstructions:
- "Buat caramel nya dulu, panaskan gula di atas teflon atau panci hingga larut dengan api kecillllllll hampir mati"
- "Biarkan leleh jangan di aduk"
- "Tambahkan air panas perlahan, matikan.. ini hasil nya.. sisihkan... biarkan agak dingin atau hangat (hati\" nyiprat, aku pake panci, karna pernah kcipratan pas pake teflon 😂)"
- "Lelehkan margarin, atau siapkan minyak 1 gelas. ini ukuran gelas yg aku pake ya.. sisihkan"
- "Campur semua bahan kering, terigu, sagu. baking powder dan baking soda, ayak.."
- "Kocok lepas telur dengan kental manis"
- "Hingga rata sprti ini"
- "Tambahkan terigu dan gula caramel bergantian sdikit sdikit,"
- "Masukan minyak atau margarin, hasilnya encer yaa dan rada bergrindil.. gpp nanti di saring"
- "Olesi loyang dengan margarin dan taburi tepung terigu.. aku olesi loyang pake carlo sisa kmaren. si pengoles loyang yg hasilnya mulus... terigu,margarin,minyak masing\" 1 sdm aduk rata smpe ngbntuk pasta,"
- "Tuang adonan ke loyang sambil di saring ya.. supaya halus dari adonan yg brgrindil.. pangga 45 menit dengan suhu 175°. (sesuaikan oven masing\")"
- "Aku pake baking fan. api sedang, pertama lubang udara nya di ttup dulu utk matengin kue bagian dalem,klo uda stengah jam lubang nya di buka, supaya bagian atas nya mateng sempurna. hati\" api jngn trlalu besar.."
- "Angkat, dari loyang.. aga susah yaa nempel.. tunggu dingin.. aku gak sabaran di angkat masih panas susah... jadi di cuil pake spatula plastik.. 🤣🤣"
- "Biarkan dingin.. baru potong.. supaya seratnya keliatan"
- "Yummyyyyy...."
- "Selamat mencobaaa"
categories:
- Resep
tags:
- sarang
- semut
- karamel

katakunci: sarang semut karamel 
nutrition: 213 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Sarang semut Karamel Takaran gelas & sendok](https://img-global.cpcdn.com/recipes/1d2bb798332fd89c/751x532cq70/sarang-semut-karamel-takaran-gelas-sendok-foto-resep-utama.jpg)

Anda sedang mencari ide resep sarang semut karamel takaran gelas & sendok yang unik? Cara membuatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sarang semut karamel takaran gelas & sendok yang enak harusnya sih punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sarang semut karamel takaran gelas & sendok, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan sarang semut karamel takaran gelas & sendok enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan istimewa.




Di bawah ini ada beberapa cara mudah dan praktis untuk membuat sarang semut karamel takaran gelas & sendok yang siap dikreasikan. Anda bisa membuat Sarang semut Karamel Takaran gelas & sendok memakai 13 jenis bahan dan 16 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk membuat Sarang semut Karamel Takaran gelas & sendok:

1. Siapkan  Bahan Caramel
1. Gunakan 400 gr gula (2 1/2 gelas blimbing atau 22 sendok mkan)
1. Siapkan 400 ml air panas (2 gelas belimbing)
1. Siapkan  kalo mau bikin stengah resep tinggal di bagi 2 aja ya
1. Sediakan  Bahan adonan
1. Siapkan 4 butir telur
1. Ambil 160 gr margarin atau 3/4 margarin sachet, (me: palmia royal atau
1. Siapkan  bisa ganti minyak kemasan 1 gelas)
1. Ambil 120 gr tepung terigu (1 gelas belimbing = 8 Sdm munjung)
1. Siapkan 120 gr tapioka atau sagu (1 1/2 gelas belimbing =12 sdm munjung)
1. Ambil 4 bks Kental manis (me:frisian flag)
1. Sediakan 1 sdt baking powder
1. Gunakan 1 sdt baking soda/soda kue




##### Langkah-langkah mengolah Sarang semut Karamel Takaran gelas & sendok:

1. Buat caramel nya dulu, panaskan gula di atas teflon atau panci hingga larut dengan api kecillllllll hampir mati
1. Biarkan leleh jangan di aduk
1. Tambahkan air panas perlahan, matikan.. ini hasil nya.. sisihkan... biarkan agak dingin atau hangat (hati\" nyiprat, aku pake panci, karna pernah kcipratan pas pake teflon 😂)
1. Lelehkan margarin, atau siapkan minyak 1 gelas. ini ukuran gelas yg aku pake ya.. sisihkan
1. Campur semua bahan kering, terigu, sagu. baking powder dan baking soda, ayak..
1. Kocok lepas telur dengan kental manis
1. Hingga rata sprti ini
1. Tambahkan terigu dan gula caramel bergantian sdikit sdikit,
1. Masukan minyak atau margarin, hasilnya encer yaa dan rada bergrindil.. gpp nanti di saring
1. Olesi loyang dengan margarin dan taburi tepung terigu.. aku olesi loyang pake carlo sisa kmaren. si pengoles loyang yg hasilnya mulus... terigu,margarin,minyak masing\" 1 sdm aduk rata smpe ngbntuk pasta,
1. Tuang adonan ke loyang sambil di saring ya.. supaya halus dari adonan yg brgrindil.. pangga 45 menit dengan suhu 175°. (sesuaikan oven masing\")
1. Aku pake baking fan. api sedang, pertama lubang udara nya di ttup dulu utk matengin kue bagian dalem,klo uda stengah jam lubang nya di buka, supaya bagian atas nya mateng sempurna. hati\" api jngn trlalu besar..
1. Angkat, dari loyang.. aga susah yaa nempel.. tunggu dingin.. aku gak sabaran di angkat masih panas susah... jadi di cuil pake spatula plastik.. 🤣🤣
1. Biarkan dingin.. baru potong.. supaya seratnya keliatan
1. Yummyyyyy....
1. Selamat mencobaaa




Gimana nih? Mudah bukan? Itulah cara membuat sarang semut karamel takaran gelas & sendok yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
