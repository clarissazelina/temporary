---
description: "TERUNGKAP! Begini Resep Rahasia Pentol pedas manis Gampang Banget"
title: "TERUNGKAP! Begini Resep Rahasia Pentol pedas manis Gampang Banget"
slug: 1842-masakan-sederhana-terungkap-begini-resep-rahasia-pentol-pedas-manis-gampang-banget
date: 2020-06-17T15:02:16.045Z
image: https://img-global.cpcdn.com/recipes/ef9521c8b5d679e8/751x532cq70/pentol-pedas-manis-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ef9521c8b5d679e8/751x532cq70/pentol-pedas-manis-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ef9521c8b5d679e8/751x532cq70/pentol-pedas-manis-foto-resep-utama.jpg
author: Alejandro Castro
ratingvalue: 3.5
reviewcount: 8
recipeingredient:
- " Pentol Saya 1 bungkus isi 17 biji"
- "1 siung bawang putih jumbo normal 23 siung"
- "2 siung bawang merah besar"
- "10 buah cabe rawit sesuaikan"
- "2 sendok makan saus tomat"
- " 1 sendok makan kecap manis"
- "Secukupnya kaldu bubukpenyedap"
- "Secukupnya merica bubuk"
- "Secukupnya garam"
- "Secukupnya gula"
- "Secukupnya air"
- "Secukupnya daun bawang pre topping"
recipeinstructions:
- "Rebus pentol."
- "Uleg bawang putih, bawang merah, cabe dengan garam dan gula agar lebih mudah. Iris tipis daun bawang."
- "Tumis bumbu halus hingga harum beri sedikit air. Masukan pentol. Beri saus, kecap, kaldu bubuk dan merica bubuk aduk rata. Tes rasa, sesuaikan. Tunggu air hingga sedikit menyusut."
- "Beri irisan daun bawang dan siap disantap 😋. Happy cooking 😄."
categories:
- Resep
tags:
- pentol
- pedas
- manis

katakunci: pentol pedas manis 
nutrition: 155 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Pentol pedas manis](https://img-global.cpcdn.com/recipes/ef9521c8b5d679e8/751x532cq70/pentol-pedas-manis-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep pentol pedas manis yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pentol pedas manis yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Hallo sista👩 and brother. 👱 Selamat datang di youtobe channel ku. I Love you all. * bahan bahan nya. Pentol manis pedas adalah salah satu jenis kuliner yang sangat digemari oleh anak-anak saya,karena rasanya benar-benar membuat ketagihan.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari pentol pedas manis, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan pentol pedas manis enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat pentol pedas manis yang siap dikreasikan. Anda dapat menyiapkan Pentol pedas manis menggunakan 12 jenis bahan dan 4 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Pentol pedas manis:

1. Sediakan  Pentol (Saya 1 bungkus isi 17 biji)
1. Gunakan 1 siung bawang putih jumbo (normal 2-3 siung)
1. Gunakan 2 siung bawang merah besar
1. Ambil 10 buah cabe rawit (sesuaikan)
1. Gunakan 2 sendok makan saus tomat
1. Siapkan  ±1 sendok makan kecap manis
1. Ambil Secukupnya kaldu bubuk/penyedap
1. Gunakan Secukupnya merica bubuk
1. Siapkan Secukupnya garam
1. Ambil Secukupnya gula
1. Gunakan Secukupnya air
1. Sediakan Secukupnya daun bawang pre (topping)


Cuci bersih dada ayam kemudian haluskan. Siapkan wadah lalu masukan tepung tapioka, putih telur dan air es, aduk sampai merata. Mulai dari pentol isi abon, pentol ranjau yang merupakan pentol isi cabai rawit, lalu pentol setan super pedas, pentol tuyul yang sebenarnya berupa pentol kecil-kecil, pentol gila, pentol isi telur. Haluskan bumbu (dengan diblender atau diulek). 

##### Langkah-langkah mengolah Pentol pedas manis:

1. Rebus pentol.
1. Uleg bawang putih, bawang merah, cabe dengan garam dan gula agar lebih mudah. Iris tipis daun bawang.
1. Tumis bumbu halus hingga harum beri sedikit air. Masukan pentol. Beri saus, kecap, kaldu bubuk dan merica bubuk aduk rata. Tes rasa, sesuaikan. Tunggu air hingga sedikit menyusut.
1. Beri irisan daun bawang dan siap disantap 😋. Happy cooking 😄.


Our technical engineering, chemical production and development is based in Germany while our service teams are working world. Aku cobain es podeng campur dari Es Podeng H. Rasa khas es serut dari santan kelapa dengan toping beraneka macam, ada alpukat, tape, jelly, nangka ditambah dengan susu kental manis. Tak kalah dengan Jogja, kuliner Solo pun Acara dengan puluhan kuliner enak yang patut dicoba. Pentol urat dengan kuah pedas ini pun biasanya. 

Bagaimana? Gampang kan? Itulah cara menyiapkan pentol pedas manis yang bisa Anda lakukan di rumah. Selamat mencoba!
