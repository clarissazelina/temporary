---
description: "RECOMMENDED! Begini Resep 68. Kelicuk Gampang Banget"
title: "RECOMMENDED! Begini Resep 68. Kelicuk Gampang Banget"
slug: 1683-masakan-sederhana-recommended-begini-resep-68-kelicuk-gampang-banget
date: 2020-07-20T10:29:22.910Z
image: https://img-global.cpcdn.com/recipes/4beddb2c31d6994d/751x532cq70/68-kelicuk-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4beddb2c31d6994d/751x532cq70/68-kelicuk-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4beddb2c31d6994d/751x532cq70/68-kelicuk-foto-resep-utama.jpg
author: Harriett Lynch
ratingvalue: 3.7
reviewcount: 12
recipeingredient:
- "5 buah pisang jantan matang"
- "250 gram beras ketan putih"
- "100 gram kelapa parut"
- "secukupnya gula pasir"
- "secukupnya garam"
- "secukupnya daun pisang"
recipeinstructions:
- "Cuci bersih beras ketan, lalu direndam selama kurang lebih 1 hingga 2 jam."
- "Kupas buah pisang, hilangkan serat-serat putihnya kemudian haluskan (cukup menggunakan garpu atau tangan--tidak perlu diblender). Jika sudah halus, tambahkan gula, garam dan kelapa parut. Aduk rata. Terakhir, campurkan beras ketan yang telah direndam, aduk kembali sampai bercampur semuanya."
- "Proses selanjutnya yaitu membungkus adonan kelicuk. Pertama-tama, bentuk daun pisang seperti segitiga kerucut, kemudian masukkan satu/dua sendok adonan ke dalam daun pisang yang telah berbentuk kerucut."
- "Tutup bagian terbuka daun pisang seperti di foto."
- "Bagian atas daun yang tersisa, dilipat ke bagian belakang agar adonan tidak keluar. Lanjutkan sampai adonan habis."
- "Didihkan air di panci pengukus. Setelah air mendidih, barulah susun semuanya di dalam panci dan pastikan bagian daun yang dilipat menyentuh dinding panci supaya adonan tidak keluar saat dikukus. Contoh bisa lihat di foto. Kukus kurang lebih 45 sampai 1 jam di atas api sedang."
- "CATATAN: 1) Sebaiknya beras ketan diaron terlebih dahulu agar mempersingkat waktu pengukusan. 2) Pastikan saat melipat daun, keadaan daun tidak ada yang sobek. 3) Keluarga saya selalu menggunakan pisang jantan atau pisang Lampung untuk membuat kelicuk karena rasanya yang manis, dan kurang tahu bisa/tidak bila diganti jenis pisang lain. 4) Saya menambahkan 3 sendok makan munju gula pasir dan 1/2 sendok teh garam. Selamat mencoba resepnya."
categories:
- Resep
tags:
- 68
- kelicuk

katakunci: 68 kelicuk 
nutrition: 256 calories
recipecuisine: Indonesian
preptime: "PT29M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Dinner

---


![68. Kelicuk](https://img-global.cpcdn.com/recipes/4beddb2c31d6994d/751x532cq70/68-kelicuk-foto-resep-utama.jpg)

Anda sedang mencari ide resep 68. kelicuk yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal 68. kelicuk yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Tlateloco es una historia en una ciudad con grandes héroes y villanos; también una historia de amor entre dos estudiantes de distintos estratos sociales. Chip y Liza son una pareja peculiar. La novia de Chip parecía una mujer de lo más normal, pero lo cierto es que tiene.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari 68. kelicuk, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing jika ingin menyiapkan 68. kelicuk yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah 68. kelicuk yang siap dikreasikan. Anda dapat membuat 68. Kelicuk memakai 6 bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah 68. Kelicuk:

1. Siapkan 5 buah pisang jantan matang
1. Ambil 250 gram beras ketan putih
1. Ambil 100 gram kelapa parut
1. Siapkan secukupnya gula pasir
1. Ambil secukupnya garam
1. Sediakan secukupnya daun pisang




##### Langkah-langkah mengolah 68. Kelicuk:

1. Cuci bersih beras ketan, lalu direndam selama kurang lebih 1 hingga 2 jam.
1. Kupas buah pisang, hilangkan serat-serat putihnya kemudian haluskan (cukup menggunakan garpu atau tangan--tidak perlu diblender). Jika sudah halus, tambahkan gula, garam dan kelapa parut. Aduk rata. Terakhir, campurkan beras ketan yang telah direndam, aduk kembali sampai bercampur semuanya.
1. Proses selanjutnya yaitu membungkus adonan kelicuk. Pertama-tama, bentuk daun pisang seperti segitiga kerucut, kemudian masukkan satu/dua sendok adonan ke dalam daun pisang yang telah berbentuk kerucut.
1. Tutup bagian terbuka daun pisang seperti di foto.
1. Bagian atas daun yang tersisa, dilipat ke bagian belakang agar adonan tidak keluar. Lanjutkan sampai adonan habis.
1. Didihkan air di panci pengukus. Setelah air mendidih, barulah susun semuanya di dalam panci dan pastikan bagian daun yang dilipat menyentuh dinding panci supaya adonan tidak keluar saat dikukus. Contoh bisa lihat di foto. Kukus kurang lebih 45 sampai 1 jam di atas api sedang.
1. CATATAN: 1) Sebaiknya beras ketan diaron terlebih dahulu agar mempersingkat waktu pengukusan. 2) Pastikan saat melipat daun, keadaan daun tidak ada yang sobek. 3) Keluarga saya selalu menggunakan pisang jantan atau pisang Lampung untuk membuat kelicuk karena rasanya yang manis, dan kurang tahu bisa/tidak bila diganti jenis pisang lain. 4) Saya menambahkan 3 sendok makan munju gula pasir dan 1/2 sendok teh garam. Selamat mencoba resepnya.




Gimana nih? Mudah bukan? Itulah cara membuat 68. kelicuk yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
