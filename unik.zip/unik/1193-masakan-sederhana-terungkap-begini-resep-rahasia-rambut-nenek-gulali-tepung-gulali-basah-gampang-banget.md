---
description: "TERUNGKAP! Begini Resep Rahasia Rambut Nenek (Gulali Tepung/Gulali Basah) Gampang Banget"
title: "TERUNGKAP! Begini Resep Rahasia Rambut Nenek (Gulali Tepung/Gulali Basah) Gampang Banget"
slug: 1193-masakan-sederhana-terungkap-begini-resep-rahasia-rambut-nenek-gulali-tepung-gulali-basah-gampang-banget
date: 2020-04-26T22:06:22.202Z
image: https://img-global.cpcdn.com/recipes/e08800ce0af55ca1/751x532cq70/rambut-nenek-gulali-tepunggulali-basah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e08800ce0af55ca1/751x532cq70/rambut-nenek-gulali-tepunggulali-basah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e08800ce0af55ca1/751x532cq70/rambut-nenek-gulali-tepunggulali-basah-foto-resep-utama.jpg
author: Raymond Taylor
ratingvalue: 3.6
reviewcount: 12
recipeingredient:
- "125 Gram Gula Pasir"
- "150 Gram Tepung Ketan Putih"
- "100 Ml Air"
- "1/4 Sdt Perasan Air Jeruk Nipis"
- "Secukupnya Pewarna Makanan"
recipeinstructions:
- "Sangrai Tepung Ketan Putih Hingga Ringan.Angkat Dan Dinginkan.Sisihkan"
- "Siapkan Alas Rata anti lengket,Jika tidak ada bisa menggunakan alas apapun kemudian olesi sedikit minyak.Sisihkan"
- "Masak Gula,Air,Perasan Jeruk Nipis,dan pewarna secukupnya.Masak hingga mendidih dan berbuih dengan api kecil."
- "Cek Gulali dengan menyiapkan air dingin.Kemudian Tuang Sedikit Gulali ke dalam air dingin.Jika Gulali dipegang masih cair itu tandanya gulali belum siap dibentuk,teruskan memasak."
- "Ulangi lagi,jika gulali dipegang mulai padat tapi ketika ditarik masih jatuh,itu juga tandanya masih belum siap.Terus Memasak"
- "Saat pengecekan ke 3,gulali diangkat dari air dingin mulai padat dan saat ditarik terbentuk garis lurus kokoh dan tidak jatuh,itu tandanya gulali siap dibentuk rambut nenek."
- "Pindahkan gulali ke dalam alas/wadah yg telah diberi minyak.Biarkan uap panasnya menghilang,dan gulali menjadi hangat.Kalian Boleh Mengaduknya sesekali,tapi jangan terlalu sering,karena jika terlalu sering diaduk gulali akan mengkristal menjadi gula pasir kembali."
- "Jika sudah mulai dingin dan padat,gulali bisa kita uleni dengan tangan(pastikan tangan bersih ya) atau bisa menggunakan sarung tangan plastik.Mulai Bentuk,beri lubang ditengah gulali lumuri tepung.Lebarkan,lipat menjadi dua,lebarkan kembali,lakukan hingga mendapatkan rambut nenek."
- "Jika Sudah Jadi Bisa Langsung Dimakan atau bisa disimpan di tempat kedap udara.Karena rambut nenek Gulali basah ini tidak bisa tahan di udara luar.Jika terlalu lama diluar,gulali bisa mencair dan menempel kembali satu sama lain."
- "Selamat Mencoba😊"
categories:
- Resep
tags:
- rambut
- nenek
- gulali

katakunci: rambut nenek gulali 
nutrition: 221 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dessert

---


![Rambut Nenek (Gulali Tepung/Gulali Basah)](https://img-global.cpcdn.com/recipes/e08800ce0af55ca1/751x532cq70/rambut-nenek-gulali-tepunggulali-basah-foto-resep-utama.jpg)

Sedang mencari ide resep rambut nenek (gulali tepung/gulali basah) yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal rambut nenek (gulali tepung/gulali basah) yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari rambut nenek (gulali tepung/gulali basah), pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan rambut nenek (gulali tepung/gulali basah) yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Nah, kali ini kita coba, yuk, variasikan rambut nenek (gulali tepung/gulali basah) sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa membuat Rambut Nenek (Gulali Tepung/Gulali Basah) memakai 5 jenis bahan dan 10 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Rambut Nenek (Gulali Tepung/Gulali Basah):

1. Sediakan 125 Gram Gula Pasir
1. Ambil 150 Gram Tepung Ketan Putih
1. Sediakan 100 Ml Air
1. Ambil 1/4 Sdt Perasan Air Jeruk Nipis
1. Sediakan Secukupnya Pewarna Makanan




##### Cara membuat Rambut Nenek (Gulali Tepung/Gulali Basah):

1. Sangrai Tepung Ketan Putih Hingga Ringan.Angkat Dan Dinginkan.Sisihkan
1. Siapkan Alas Rata anti lengket,Jika tidak ada bisa menggunakan alas apapun kemudian olesi sedikit minyak.Sisihkan
1. Masak Gula,Air,Perasan Jeruk Nipis,dan pewarna secukupnya.Masak hingga mendidih dan berbuih dengan api kecil.
1. Cek Gulali dengan menyiapkan air dingin.Kemudian Tuang Sedikit Gulali ke dalam air dingin.Jika Gulali dipegang masih cair itu tandanya gulali belum siap dibentuk,teruskan memasak.
1. Ulangi lagi,jika gulali dipegang mulai padat tapi ketika ditarik masih jatuh,itu juga tandanya masih belum siap.Terus Memasak
1. Saat pengecekan ke 3,gulali diangkat dari air dingin mulai padat dan saat ditarik terbentuk garis lurus kokoh dan tidak jatuh,itu tandanya gulali siap dibentuk rambut nenek.
1. Pindahkan gulali ke dalam alas/wadah yg telah diberi minyak.Biarkan uap panasnya menghilang,dan gulali menjadi hangat.Kalian Boleh Mengaduknya sesekali,tapi jangan terlalu sering,karena jika terlalu sering diaduk gulali akan mengkristal menjadi gula pasir kembali.
1. Jika sudah mulai dingin dan padat,gulali bisa kita uleni dengan tangan(pastikan tangan bersih ya) atau bisa menggunakan sarung tangan plastik.Mulai Bentuk,beri lubang ditengah gulali lumuri tepung.Lebarkan,lipat menjadi dua,lebarkan kembali,lakukan hingga mendapatkan rambut nenek.
1. Jika Sudah Jadi Bisa Langsung Dimakan atau bisa disimpan di tempat kedap udara.Karena rambut nenek Gulali basah ini tidak bisa tahan di udara luar.Jika terlalu lama diluar,gulali bisa mencair dan menempel kembali satu sama lain.
1. Selamat Mencoba😊




Bagaimana? Mudah bukan? Itulah cara menyiapkan rambut nenek (gulali tepung/gulali basah) yang bisa Anda praktikkan di rumah. Selamat mencoba!
