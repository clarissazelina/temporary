---
description: "WAJIB DICOBA! Begini Resep Rahasia Kupat sumpil daun bambu, irit gas Gampang Banget"
title: "WAJIB DICOBA! Begini Resep Rahasia Kupat sumpil daun bambu, irit gas Gampang Banget"
slug: 1069-masakan-sederhana-wajib-dicoba-begini-resep-rahasia-kupat-sumpil-daun-bambu-irit-gas-gampang-banget
date: 2020-09-17T17:20:29.009Z
image: https://img-global.cpcdn.com/recipes/0bc937356c2db69a/751x532cq70/kupat-sumpil-daun-bambu-irit-gas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0bc937356c2db69a/751x532cq70/kupat-sumpil-daun-bambu-irit-gas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0bc937356c2db69a/751x532cq70/kupat-sumpil-daun-bambu-irit-gas-foto-resep-utama.jpg
author: Duane Perry
ratingvalue: 4.5
reviewcount: 4
recipeingredient:
- "2 gelas beras takaran mejicom"
- "Secukupnya daun bambu"
- "Tusuk gigilidi"
- "2 lembar dun pandan"
recipeinstructions:
- "Cuci bersih beras tiriskan, ambil daun bambu dicuci dilap bersih.., gunting ujung pangkal daun bambu jangan sampai robek"
- "Ambil satu lembar daun bambu, lekuk ujung daun bambu dibikin contong. Ambil satu sedok makan mudung beras, kira\" setengh dari contong daun bambu..tekuk daun bambu, dari sisinya usahakan rapat...jangan sampai bocor/pecah. membentuk segi tiga, lakukan sampai pangkal daun bambu semat dg lidi pd pangkal ujung, daun bambu"
- "Masak air daun pandan dlm panci, masukan semua sumpil rebus usahkan semua sumpil terendam dlm air. Tutup panci dg rapat rebus 25mnit biarkan, stelah 25mit matikan kompor biarkan dlm panci 30mnit,"
- "Setelah 30menit angakt sumpil, siram dg air dingin supaya tidk lengket dan juga bersih tdk kotor.. Panaskan kukusa kukus sumpil selama 20mnit. Supaya kupat sumpil tanak taha untuk dimkan esok hari nya"
- "Kupaat sumpil siap disajikan.. Lebih tepat nya dimkan kalo sudah dingin serasa nyes/dingin enak diperut dan wangi daun pandan nya... Buat campuran apa saja cocok.. Opor ayam, atu pecel urap. Selamat mencoba"
categories:
- Resep
tags:
- kupat
- sumpil
- daun

katakunci: kupat sumpil daun 
nutrition: 203 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT45M"
recipeyield: "3"
recipecategory: Dinner

---


![Kupat sumpil daun bambu, irit gas](https://img-global.cpcdn.com/recipes/0bc937356c2db69a/751x532cq70/kupat-sumpil-daun-bambu-irit-gas-foto-resep-utama.jpg)

Sedang mencari ide resep kupat sumpil daun bambu, irit gas yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal kupat sumpil daun bambu, irit gas yang enak harusnya sih punya aroma dan cita rasa yang bisa memancing selera kita.

Ketupat sumpil atau biasa disebut kupat sumpil adalah makanan/kuliner khas Jawa Tengah Bentuknya yang unik, lucu dan imut, yaitu berbentuk segitiga. Enak di bawa traveling tidak mudah basi kenyal enak di makan dengan gorengan, rica rica,sate ataupun rendang dan serundeng. Kupat sumpil yang kami produksi menggunakan beras pilihan dan di bungkus dengan daun bambu, sehingga lebih aman untuk dikonsumsi.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari kupat sumpil daun bambu, irit gas, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan kupat sumpil daun bambu, irit gas enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah kupat sumpil daun bambu, irit gas yang siap dikreasikan. Anda dapat menyiapkan Kupat sumpil daun bambu, irit gas memakai 4 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Kupat sumpil daun bambu, irit gas:

1. Sediakan 2 gelas beras, takaran mejicom
1. Siapkan Secukupnya daun bambu
1. Siapkan Tusuk gigi/lidi
1. Sediakan 2 lembar dun pandan


Khasiat daun bambu kuning telah dikenal semenjak jaman dahulu dapat digunakan untuk pengobatan dan berbagai masalah medis secara tradisional. Daun bambu ternyata memiliki khasiat yang cukup manjur untuk mengobati berbagai macam penyakit, dan salah satunya membantu melancarkan menstruasi. Khasiat.co.id - Daun bambu memang tidak atau belum banyak yang memanfaatkannya, tidak seperti pada batang pohon atau bagian rebungnya. Dinamakan Bambu Rejeki, karena tanaman ini dipercaya mampu membawa keberuntungan. 

##### Langkah-langkah mengolah Kupat sumpil daun bambu, irit gas:

1. Cuci bersih beras tiriskan, ambil daun bambu dicuci dilap bersih.., gunting ujung pangkal daun bambu jangan sampai robek
1. Ambil satu lembar daun bambu, lekuk ujung daun bambu dibikin contong. Ambil satu sedok makan mudung beras, kira\" setengh dari contong daun bambu..tekuk daun bambu, dari sisinya usahakan rapat...jangan sampai bocor/pecah. membentuk segi tiga, lakukan sampai pangkal daun bambu semat dg lidi pd pangkal ujung, daun bambu
1. Masak air daun pandan dlm panci, masukan semua sumpil rebus usahkan semua sumpil terendam dlm air. Tutup panci dg rapat rebus 25mnit biarkan, stelah 25mit matikan kompor biarkan dlm panci 30mnit,
1. Setelah 30menit angakt sumpil, siram dg air dingin supaya tidk lengket dan juga bersih tdk kotor.. Panaskan kukusa kukus sumpil selama 20mnit. Supaya kupat sumpil tanak taha untuk dimkan esok hari nya
1. Kupaat sumpil siap disajikan.. Lebih tepat nya dimkan kalo sudah dingin serasa nyes/dingin enak diperut dan wangi daun pandan nya... Buat campuran apa saja cocok.. Opor ayam, atu pecel urap. Selamat mencoba


Meskipun bambu identik dengan negara Cina, ternyata Baik itu daun, ataupun kuncup tanaman. Hal ini bisa disebabgkan oleh beberapa hal seperti kurangnya air, temperatur yang terlalu terik, atau pupuk dan. Daun bambu merupakan stimulan. manfaat daun bambu tersebut mampu mengurangi gangguan-gangguan yang jarang terjadi, sekresi luka dan pendarahan. Khasiat lain daun bambu adalah sebagai pembangkit gairah yang efektif. Daun-daunnya tersebut harus direbus hingga menjadi teh, Jika ingin. 

Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Kupat sumpil daun bambu, irit gas yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi inspirasi untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
