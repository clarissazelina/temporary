---
description: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Palai Bada Enak"
title: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Palai Bada Enak"
slug: 1322-masakan-sederhana-wajib-dicoba-ternyata-ini-resep-rahasia-palai-bada-enak
date: 2020-08-25T04:21:22.140Z
image: https://img-global.cpcdn.com/recipes/5e8af2ea8a5c3f22/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5e8af2ea8a5c3f22/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5e8af2ea8a5c3f22/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Leah Willis
ratingvalue: 4.5
reviewcount: 7
recipeingredient:
- "350 gram Teri basah"
- "75 gram Kelapa parut dihaluskan sy sangrai dl biar ngga gampang basi"
- "1 batang Daun bawang iris halus"
- "2 lembar Daun jeruk iris halus"
- "3 lembar Daun mangkokan iris halus sy ngga ada"
- "1 lembar Daun kunyit iris halus sy ngga ada"
- "1 buah Asam sundai ambil airnya pake jeruk nipis jg boleh"
- "secukupnya Daun salam"
- "Secukupnya Daun pisang untuk membungkus"
- " Bumbu halus "
- "8 siung Bawang merah"
- "2 siung Bawang putih"
- "3 butir Kemiri"
- "2-3 cm Jahe"
- "2-3 cm Kunyit bakar"
- "2 batang Serai ambil bagian putihnya"
- "15 buah Cabe merah keriting"
- "2 buah Cabe rawit merah"
- "1 sdt Gula pasir"
- "1 sdt Kaldu jamur"
- "secukupnya Garam"
recipeinstructions:
- "Siangi ikan teri, buang kepalanya. Lalu cuci bersih. Beri air jeruk nipis dan sedikit garam, diamkan sebentar lalu cuci lg."
- "Campur ikan teri dengan sebagian bumbu halus, tambahkan air asam sundai (air jeruk nipis), aduk2 sampai rata."
- "Campur kelapa parut, daun jeruk, daun bawang dengan sisa bumbu halus. Aduk2 sampai rata."
- "Campur jadi satu (ikan teri dan kelapa parut berbumbu), aduk2 sampai rata. Koreksi rasa."
- "Siapkan daun pisang, beri 2-3 sdm ikan teri berbumbu, beri 1 lembar daun salam. Bungkus. Lakukan sampai habis. Di resep asli ngga pake daun salam ya. Sesuai selera aja."
- "Bakar sampai matang, gunakan api kecil biar matang sempurna."
- "Sajikan."
categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT42M"
recipeyield: "4"
recipecategory: Lunch

---


![Palai Bada](https://img-global.cpcdn.com/recipes/5e8af2ea8a5c3f22/751x532cq70/palai-bada-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep palai bada yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal palai bada yang enak seharusnya punya aroma dan rasa yang dapat memancing selera kita.

Palai bada adalah salah satu hidangan yang berasal dari Sumatra Barat. Hidangan ini menggunakan ikan teri sebagai bahan utamanya, yang oleh penduduk setempat disebut dengan \"ikan bada\" atau \"maco bada\" (dalam bentuk ikan asin). Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\".

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari palai bada, mulai dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing jika mau menyiapkan palai bada enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan palai bada sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Palai Bada menggunakan 21 bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Palai Bada:

1. Ambil 350 gram Teri basah
1. Ambil 75 gram Kelapa parut, dihaluskan (sy sangrai dl biar ngga gampang basi)
1. Gunakan 1 batang Daun bawang, iris halus
1. Ambil 2 lembar Daun jeruk, iris halus
1. Siapkan 3 lembar Daun mangkokan, iris halus (sy ngga ada)
1. Ambil 1 lembar Daun kunyit, iris halus (sy ngga ada)
1. Siapkan 1 buah Asam sundai, ambil airnya (pake jeruk nipis jg boleh)
1. Sediakan secukupnya Daun salam
1. Siapkan Secukupnya Daun pisang untuk membungkus
1. Siapkan  Bumbu halus :
1. Gunakan 8 siung Bawang merah
1. Sediakan 2 siung Bawang putih
1. Sediakan 3 butir Kemiri
1. Siapkan 2-3 cm Jahe
1. Gunakan 2-3 cm Kunyit bakar
1. Ambil 2 batang Serai, ambil bagian putihnya
1. Gunakan 15 buah Cabe merah keriting
1. Gunakan 2 buah Cabe rawit merah
1. Sediakan 1 sdt Gula pasir
1. Ambil 1 sdt Kaldu jamur
1. Gunakan secukupnya Garam


Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. 

##### Langkah-langkah mengolah Palai Bada:

1. Siangi ikan teri, buang kepalanya. Lalu cuci bersih. Beri air jeruk nipis dan sedikit garam, diamkan sebentar lalu cuci lg.
1. Campur ikan teri dengan sebagian bumbu halus, tambahkan air asam sundai (air jeruk nipis), aduk2 sampai rata.
1. Campur kelapa parut, daun jeruk, daun bawang dengan sisa bumbu halus. Aduk2 sampai rata.
1. Campur jadi satu (ikan teri dan kelapa parut berbumbu), aduk2 sampai rata. Koreksi rasa.
1. Siapkan daun pisang, beri 2-3 sdm ikan teri berbumbu, beri 1 lembar daun salam. Bungkus. Lakukan sampai habis. Di resep asli ngga pake daun salam ya. Sesuai selera aja.
1. Bakar sampai matang, gunakan api kecil biar matang sempurna.
1. Sajikan.


Palai Bada (Pepes Teri Basah) terbuat dari ikan teri basah yang dicampur dengan parutan kelapa, serta beragam bumbu seperti daun kunyit, daun serei, lengkuas, asam, dan lainnya. Semua lagu disini hanya untuk review saja, Jika kamu suka lagu Palai Bada belilah CD original. Yo … palai bada, lamak rasonyo makan baduo Yo … palai bada, lamak rasonyo makan baduo. Urang Rao pai ka danau Ambiak rumpuik si bilang-bilang Yo kok tuan indak picayo Bali sabungkuih baok. Palai Bada sprot met kruiden gegrild in bananenblad. 

Bagaimana? Mudah bukan? Itulah cara membuat palai bada yang bisa Anda praktikkan di rumah. Selamat mencoba!
