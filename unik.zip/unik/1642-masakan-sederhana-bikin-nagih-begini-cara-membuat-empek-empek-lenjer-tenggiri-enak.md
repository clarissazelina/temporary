---
description: "BIKIN NAGIH! Begini Cara Membuat Empek empek lenjer tenggiri Enak"
title: "BIKIN NAGIH! Begini Cara Membuat Empek empek lenjer tenggiri Enak"
slug: 1642-masakan-sederhana-bikin-nagih-begini-cara-membuat-empek-empek-lenjer-tenggiri-enak
date: 2020-04-30T04:03:35.005Z
image: https://img-global.cpcdn.com/recipes/272c909da882431e/751x532cq70/empek-empek-lenjer-tenggiri-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/272c909da882431e/751x532cq70/empek-empek-lenjer-tenggiri-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/272c909da882431e/751x532cq70/empek-empek-lenjer-tenggiri-foto-resep-utama.jpg
author: Earl McCoy
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "1 kg filet ikan tenggiri"
- "500 gr sagu tanitapioka"
- "1/2 gelas air"
- "1 sdm garam"
- "50 ml minyak goreng1 sendok sayur"
- "250 gr tepung terigu encerkan dg air mendidih sckpnya"
- " Pelengkap "
- "1 bh timun potong2 kotak"
- " Cuko "
- "1 bh gula merah"
- "3/4 gelas air"
- "2 bj mata asam"
- "2 siung bawang putih haluskan"
- "Secukupnya cabe rawit optional"
- "Secukupnya garam optional"
recipeinstructions:
- "Buat adonan basah, yg terdiri tepung terigu dn air mendidih/panas secukupnya (jgn terlalu encer)...aduk2 smp rata dn tdk ada gumpalan seperti pasta.dinginkan"
- "Setelah ikan dibersihkan dn diambil bagian dagingnya saja, campur dgn garam, tepung cair yg sdh didinginkan, tambahkan jg tepung tepioka secara bertahap (3 atau 4 kali) diselingi penambahan air, lakukan smp sagu tersisa kurleb 3 sdm (utk olesan tangan saat mmbentuk empek2 agar tdk lengket) adon dg menggunakan tangan agar merata tp jgn ditekan."
- "Setelah semua tercampur rata, tambahkan minyak goreng aduk sebentar dn siap dibentuk (jgn ditekan) Langsung cemplungin dlm panci yg airnya sdh mendidih. Angkat empek2 bila sdh mengapung=matang"
- "Rebus semua bahan cuko smp mendidih dn gula larut sempurna. Goreng empek2 sblm disajikan. Tambahkan cuko dn pelengkap"
categories:
- Resep
tags:
- empek
- empek
- lenjer

katakunci: empek empek lenjer 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT31M"
recipeyield: "3"
recipecategory: Lunch

---


![Empek empek lenjer tenggiri](https://img-global.cpcdn.com/recipes/272c909da882431e/751x532cq70/empek-empek-lenjer-tenggiri-foto-resep-utama.jpg)

Lagi mencari ide resep empek empek lenjer tenggiri yang unik? Cara membuatnya memang susah-susah gampang. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal empek empek lenjer tenggiri yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari empek empek lenjer tenggiri, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan empek empek lenjer tenggiri yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.

Resep Pempek (empek empek) ikan gabus Empuk, Putih dan Lezat Resep Cara Membuat Empek Empek Palembang Asli Yang Enak Pempek atau yang biasa dikenal dengan empek-empek adalah makanan khas Kota Pel.


Di bawah ini ada beberapa tips dan trik praktis untuk membuat empek empek lenjer tenggiri yang siap dikreasikan. Anda dapat membuat Empek empek lenjer tenggiri memakai 15 jenis bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Empek empek lenjer tenggiri:

1. Gunakan 1 kg filet ikan tenggiri
1. Gunakan 500 gr sagu tani/tapioka
1. Siapkan 1/2 gelas air
1. Sediakan 1 sdm garam
1. Sediakan 50 ml minyak goreng=1 sendok sayur
1. Ambil 250 gr tepung terigu (encerkan dg air mendidih sckpnya)
1. Gunakan  Pelengkap :
1. Ambil 1 bh timun (potong2 kotak)
1. Siapkan  Cuko :
1. Ambil 1 bh gula merah
1. Ambil 3/4 gelas air
1. Ambil 2 bj mata asam
1. Gunakan 2 siung bawang putih (haluskan)
1. Ambil Secukupnya cabe rawit (optional)
1. Sediakan Secukupnya garam (optional)


It\'s very delicious Ing: (empek) fish, Flour, egg yolk & salt (Sauce / cuko) water, palm sugar, vinegar $ salt. Empek-empek lenjer banyak dijual oleh pedagang empek-empek keliling. Empek-empek palembang ikan belida dijamin tanpa pengawet. Resep empek empek berbeda-beda tergantung dari jenis ikan. 

##### Cara membuat Empek empek lenjer tenggiri:

1. Buat adonan basah, yg terdiri tepung terigu dn air mendidih/panas secukupnya (jgn terlalu encer)...aduk2 smp rata dn tdk ada gumpalan seperti pasta.dinginkan
1. Setelah ikan dibersihkan dn diambil bagian dagingnya saja, campur dgn garam, tepung cair yg sdh didinginkan, tambahkan jg tepung tepioka secara bertahap (3 atau 4 kali) diselingi penambahan air, lakukan smp sagu tersisa kurleb 3 sdm (utk olesan tangan saat mmbentuk empek2 agar tdk lengket) adon dg menggunakan tangan agar merata tp jgn ditekan.
1. Setelah semua tercampur rata, tambahkan minyak goreng aduk sebentar dn siap dibentuk (jgn ditekan) Langsung cemplungin dlm panci yg airnya sdh mendidih. Angkat empek2 bila sdh mengapung=matang
1. Rebus semua bahan cuko smp mendidih dn gula larut sempurna. Goreng empek2 sblm disajikan. Tambahkan cuko dn pelengkap


Seperti kita ketahui bahan baku bisa terbuat dari ikan belida, ikan tenggiri, ikan Lince menerima warisan resep empek-empek palembang ini dari keluarga-keluarganya. Untuk jenis pempek lenjer, cara membuatnya diajarkan langsung oleh. Jika kemarin sudah membuat pempek kapal selam, sekarang kita coba membuat pempek lenjer yang tak kalah enak dari empek empek isi telur. Pempek Lenjer tidak menggunakan isi telur dalam pembuatannya sehingga lebih simple dari pempek kapal selam karena tidak perlu susah susah. Empek Empek sudah dikenal oleh seluruh lapisan masyarakat Indonesia karena suka akan rasanya. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Harapan kami, olahan Empek empek lenjer tenggiri yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
