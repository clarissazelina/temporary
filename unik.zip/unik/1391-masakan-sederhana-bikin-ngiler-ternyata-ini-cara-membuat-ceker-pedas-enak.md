---
description: "BIKIN NGILER! Ternyata Ini Cara Membuat Ceker Pedas Enak"
title: "BIKIN NGILER! Ternyata Ini Cara Membuat Ceker Pedas Enak"
slug: 1391-masakan-sederhana-bikin-ngiler-ternyata-ini-cara-membuat-ceker-pedas-enak
date: 2020-07-08T22:55:07.743Z
image: https://img-global.cpcdn.com/recipes/6436c0762002a37a/751x532cq70/ceker-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6436c0762002a37a/751x532cq70/ceker-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6436c0762002a37a/751x532cq70/ceker-pedas-foto-resep-utama.jpg
author: Mable Tucker
ratingvalue: 4
reviewcount: 6
recipeingredient:
- "1/2 kg ceker ayam"
- "3 siung bawang putih geprek"
- "2 batang sereh geprek"
- "2 lembar daun salam"
- "4 lembar daun jeruk"
- "1 ruas jahe"
- " Gula"
- " Garam"
- " Bumbu halus"
- "5 siung bawang merah"
- "3 siung bawang putih"
- "8 cabe merah boleh ditambah rawit kalau mau lebih pedas"
- "1 buah tomat"
- "1/4 sdm terasi"
recipeinstructions:
- "Bersihkan ceker, rebus dengan 1 batang sereh (geprek) dan 3 siung bawang putih (geprek). Sisihkan."
- "Tumis bumbu halus bersama sereh, jahe, daun salam, daun jeruk hingga harum."
- "Masukkan ceker. Cek rasa, masukkan gula dan garam sesuai selera. Tambahkan air sedikit."
- "Masak hingga air menyusut. Siap disajikan✌️"
categories:
- Resep
tags:
- ceker
- pedas

katakunci: ceker pedas 
nutrition: 294 calories
recipecuisine: Indonesian
preptime: "PT35M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Ceker Pedas](https://img-global.cpcdn.com/recipes/6436c0762002a37a/751x532cq70/ceker-pedas-foto-resep-utama.jpg)

Lagi mencari ide resep ceker pedas yang unik? Cara menyiapkannya memang susah-susah gampang. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal ceker pedas yang enak selayaknya punya aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ceker pedas, pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan ceker pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat ceker pedas yang siap dikreasikan. Anda bisa membuat Ceker Pedas memakai 14 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam meracik Ceker Pedas:

1. Ambil 1/2 kg ceker ayam
1. Sediakan 3 siung bawang putih (geprek)
1. Siapkan 2 batang sereh (geprek)
1. Siapkan 2 lembar daun salam
1. Sediakan 4 lembar daun jeruk
1. Ambil 1 ruas jahe
1. Ambil  Gula
1. Siapkan  Garam
1. Sediakan  Bumbu halus
1. Ambil 5 siung bawang merah
1. Gunakan 3 siung bawang putih
1. Siapkan 8 cabe merah (boleh ditambah rawit kalau mau lebih pedas)
1. Ambil 1 buah tomat
1. Siapkan 1/4 sdm terasi




##### Langkah-langkah menyiapkan Ceker Pedas:

1. Bersihkan ceker, rebus dengan 1 batang sereh (geprek) dan 3 siung bawang putih (geprek). Sisihkan.
1. Tumis bumbu halus bersama sereh, jahe, daun salam, daun jeruk hingga harum.
1. Masukkan ceker. Cek rasa, masukkan gula dan garam sesuai selera. Tambahkan air sedikit.
1. Masak hingga air menyusut. Siap disajikan✌️




Bagaimana? Gampang kan? Itulah cara membuat ceker pedas yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
