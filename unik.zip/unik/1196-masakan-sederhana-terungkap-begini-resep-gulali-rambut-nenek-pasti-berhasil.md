---
description: "TERUNGKAP! Begini Resep Gulali Rambut Nenek Pasti Berhasil"
title: "TERUNGKAP! Begini Resep Gulali Rambut Nenek Pasti Berhasil"
slug: 1196-masakan-sederhana-terungkap-begini-resep-gulali-rambut-nenek-pasti-berhasil
date: 2020-05-23T05:34:42.980Z
image: https://img-global.cpcdn.com/recipes/8c54770bdf11008c/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/8c54770bdf11008c/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/8c54770bdf11008c/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
author: Fannie Miles
ratingvalue: 4.1
reviewcount: 12
recipeingredient:
- "250 gr Tepung Ketan"
- "250 gr Gula Pasir"
- "1/4 sdm Citrun"
- "200 gr Air"
- "2-3 tetes Pewarna makanan"
- "2 sdm susu dancow putih optional"
- " Wajan berisi air dingin atau air es dan taro teflon kosong diatas wajan tersebut"
recipeinstructions:
- "Sangrai tepung ketan dan susu dancow 10-15menit dgn api sedang sampai harum"
- "Masukan gula, air, dan citrun kedalam teflon anti lengket, jangan terlalu sering diaduk, tunggu hingga mendidih dan berbusa 8-10menit"
- "Utk mengetes apakah sudah menjadi gulali atau belum, ketika sudah mendidih dan kompor dimatikan gelembungny cepat hilangnya tandanya gula blm siap diolah menjadi gulali, kalau setelah dimatikan kompornya, gelembungnya lama hilangnya berarti sudah siap diolah."
- "Setelah mendidih dan agak mengental, siapkan teflon diatas air es, pindahkan gula yg dmasak tadi ke teflon yg diatas air es, aduk aduk sampai menjadi gulali. Sudah jadi gulali lalu pindahkan kedalam adonan tepung yg sudah disangrai lalu bentuk dan eratkannsampai jadi gulali rambut nenek."
categories:
- Resep
tags:
- gulali
- rambut
- nenek

katakunci: gulali rambut nenek 
nutrition: 145 calories
recipecuisine: Indonesian
preptime: "PT19M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Gulali Rambut Nenek](https://img-global.cpcdn.com/recipes/8c54770bdf11008c/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg)

Lagi mencari ide resep gulali rambut nenek yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gulali rambut nenek yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gulali rambut nenek, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan gulali rambut nenek yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah gulali rambut nenek yang siap dikreasikan. Anda dapat menyiapkan Gulali Rambut Nenek menggunakan 7 bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Gulali Rambut Nenek:

1. Ambil 250 gr Tepung Ketan
1. Ambil 250 gr Gula Pasir
1. Gunakan 1/4 sdm Citrun
1. Siapkan 200 gr Air
1. Sediakan 2-3 tetes Pewarna makanan
1. Siapkan 2 sdm susu dancow putih (optional)
1. Ambil  Wajan berisi air dingin atau air es dan taro teflon kosong diatas wajan tersebut




##### Langkah-langkah mengolah Gulali Rambut Nenek:

1. Sangrai tepung ketan dan susu dancow 10-15menit dgn api sedang sampai harum
1. Masukan gula, air, dan citrun kedalam teflon anti lengket, jangan terlalu sering diaduk, tunggu hingga mendidih dan berbusa 8-10menit
1. Utk mengetes apakah sudah menjadi gulali atau belum, ketika sudah mendidih dan kompor dimatikan gelembungny cepat hilangnya tandanya gula blm siap diolah menjadi gulali, kalau setelah dimatikan kompornya, gelembungnya lama hilangnya berarti sudah siap diolah.
1. Setelah mendidih dan agak mengental, siapkan teflon diatas air es, pindahkan gula yg dmasak tadi ke teflon yg diatas air es, aduk aduk sampai menjadi gulali. Sudah jadi gulali lalu pindahkan kedalam adonan tepung yg sudah disangrai lalu bentuk dan eratkannsampai jadi gulali rambut nenek.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Harapan kami, olahan Gulali Rambut Nenek yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
