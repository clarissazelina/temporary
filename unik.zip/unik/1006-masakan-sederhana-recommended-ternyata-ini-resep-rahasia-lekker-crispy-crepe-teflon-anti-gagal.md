---
description: "RECOMMENDED! Ternyata Ini Resep Rahasia Lekker / Crispy Crepe Teflon Anti Gagal"
title: "RECOMMENDED! Ternyata Ini Resep Rahasia Lekker / Crispy Crepe Teflon Anti Gagal"
slug: 1006-masakan-sederhana-recommended-ternyata-ini-resep-rahasia-lekker-crispy-crepe-teflon-anti-gagal
date: 2020-05-08T07:25:13.662Z
image: https://img-global.cpcdn.com/recipes/6a6ef3ac9384782b/751x532cq70/lekker-crispy-crepe-teflon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/6a6ef3ac9384782b/751x532cq70/lekker-crispy-crepe-teflon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/6a6ef3ac9384782b/751x532cq70/lekker-crispy-crepe-teflon-foto-resep-utama.jpg
author: Iva Wheeler
ratingvalue: 3.1
reviewcount: 11
recipeingredient:
- "150 gr tepung beras"
- "50 gr terigu"
- "50 gr tapioka"
- "75 gr gula pasir"
- "1/2 sdt baking powder"
- "1/2 sdt garam"
- "1 butir telur"
- "300 ml air"
- "1 sdm minyak sayur"
- " Isian  meses  keju sukasuka"
recipeinstructions:
- "Dalam baskom campurkan semua bahan kering. Aduk rata."
- "Tuang air perlahan sambil diaduk. Tambahkan telur, aduk kembali hingga tidak bergerindil."
- "Terakhir tambahkan minyak sayur. Aduk kembali."
- "Panaskan teflon dengan api sedang. Sy oles sedikit minyak ya."
- "Tuang 1 sendok sayur adonan ke teflon, ratakan seperti membuat kulit risol ya buibu."
- "Tunggu pinggiran agak kering, beri isian. Jika pinggiran telah kering kecoklatan, lipat lekker sesuai selera. Angkat."
- "1 resep ini jadi kurang lebih 15 lekker ya buibu."
- "Selamat mencoba!"
categories:
- Resep
tags:
- lekker- crispy

katakunci: lekker  crispy 
nutrition: 238 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Lekker / Crispy Crepe Teflon](https://img-global.cpcdn.com/recipes/6a6ef3ac9384782b/751x532cq70/lekker-crispy-crepe-teflon-foto-resep-utama.jpg)

Lagi mencari ide resep lekker / crispy crepe teflon yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal lekker / crispy crepe teflon yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari lekker / crispy crepe teflon, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tak perlu pusing kalau hendak menyiapkan lekker / crispy crepe teflon yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan lekker / crispy crepe teflon sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Lekker / Crispy Crepe Teflon menggunakan 10 bahan dan 8 langkah pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Lekker / Crispy Crepe Teflon:

1. Ambil 150 gr tepung beras
1. Siapkan 50 gr terigu
1. Siapkan 50 gr tapioka
1. Siapkan 75 gr gula pasir
1. Sediakan 1/2 sdt baking powder
1. Sediakan 1/2 sdt garam
1. Siapkan 1 butir telur
1. Gunakan 300 ml air
1. Sediakan 1 sdm minyak sayur
1. Siapkan  Isian : meses & keju (suka-suka)




##### Cara membuat Lekker / Crispy Crepe Teflon:

1. Dalam baskom campurkan semua bahan kering. Aduk rata.
1. Tuang air perlahan sambil diaduk. Tambahkan telur, aduk kembali hingga tidak bergerindil.
1. Terakhir tambahkan minyak sayur. Aduk kembali.
1. Panaskan teflon dengan api sedang. Sy oles sedikit minyak ya.
1. Tuang 1 sendok sayur adonan ke teflon, ratakan seperti membuat kulit risol ya buibu.
1. Tunggu pinggiran agak kering, beri isian. Jika pinggiran telah kering kecoklatan, lipat lekker sesuai selera. Angkat.
1. 1 resep ini jadi kurang lebih 15 lekker ya buibu.
1. Selamat mencoba!




Gimana nih? Gampang kan? Itulah cara menyiapkan lekker / crispy crepe teflon yang bisa Anda praktikkan di rumah. Selamat mencoba!
