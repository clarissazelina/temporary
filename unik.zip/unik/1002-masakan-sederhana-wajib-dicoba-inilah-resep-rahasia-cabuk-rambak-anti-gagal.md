---
description: "WAJIB DICOBA! Inilah Resep Rahasia Cabuk Rambak Anti Gagal"
title: "WAJIB DICOBA! Inilah Resep Rahasia Cabuk Rambak Anti Gagal"
slug: 1002-masakan-sederhana-wajib-dicoba-inilah-resep-rahasia-cabuk-rambak-anti-gagal
date: 2020-09-13T08:34:30.057Z
image: https://img-global.cpcdn.com/recipes/80e00691569caddc/751x532cq70/cabuk-rambak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/80e00691569caddc/751x532cq70/cabuk-rambak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/80e00691569caddc/751x532cq70/cabuk-rambak-foto-resep-utama.jpg
author: Scott Moore
ratingvalue: 3
reviewcount: 6
recipeingredient:
- "4 buah kupat bisa beli di pasar yang sudah jadi"
- "8 buah kerupuk gendar saya beli di tukang sayur"
- "4 lembar daun pisang dan 4 buah lidi"
- " bahan sambal"
- "150 gr wijen di sangrai"
- "2 lembar daun jeruk buang tulangnya iris halus"
- "150 ml air panas"
- " bumbu halus"
- "2 butir kemiri disangrai"
- "1/2 sdt garam"
- "1/2 sdt merica bubuk"
- "2 sdt gula pasir"
- "1/2 sdt kencur bubuk  2 cm kencur"
- "4 siung bawang putih di geprek halus di goreng"
recipeinstructions:
- "Siapkan semua bahan nya. lalu Sangrai wijen hingga kecoklatan."
- "Haluskan bumbu, haluskan juga wijen sangrai tambahkan daun jeruk iris. siram dengan air panas. aduk rata."
- "Siapkan ketupat yang sudah matang, iris tipis."
- "Penyajian: iris ketupat tata di daun pisang yang di pincuk (disemat dengan lidi di bagian ujung daun pisang) lalu siram dengan adonan sambal. tambahkan kerupuk gendar. (kerupuk gendar nya saya beli di tukang sayur)."
- "Selamat menikmati, kuliner khas kota Solo. ❤"
categories:
- Resep
tags:
- cabuk
- rambak

katakunci: cabuk rambak 
nutrition: 270 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT52M"
recipeyield: "4"
recipecategory: Dessert

---


![Cabuk Rambak](https://img-global.cpcdn.com/recipes/80e00691569caddc/751x532cq70/cabuk-rambak-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep cabuk rambak yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal cabuk rambak yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cabuk rambak, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tak perlu pusing kalau ingin menyiapkan cabuk rambak enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat cabuk rambak sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Cabuk Rambak menggunakan 14 jenis bahan dan 5 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Cabuk Rambak:

1. Gunakan 4 buah kupat (bisa beli di pasar yang sudah jadi)
1. Ambil 8 buah kerupuk gendar (saya beli di tukang sayur)
1. Siapkan 4 lembar daun pisang dan 4 buah lidi
1. Gunakan  bahan sambal
1. Ambil 150 gr wijen di sangrai
1. Sediakan 2 lembar daun jeruk, buang tulangnya, iris halus
1. Ambil 150 ml air panas
1. Siapkan  bumbu halus
1. Gunakan 2 butir kemiri, disangrai
1. Sediakan 1/2 sdt garam
1. Ambil 1/2 sdt merica bubuk
1. Gunakan 2 sdt gula pasir
1. Ambil 1/2 sdt kencur bubuk / 2 cm kencur
1. Gunakan 4 siung bawang putih, di geprek halus, di goreng




##### Cara mengolah Cabuk Rambak:

1. Siapkan semua bahan nya. lalu Sangrai wijen hingga kecoklatan.
1. Haluskan bumbu, haluskan juga wijen sangrai tambahkan daun jeruk iris. siram dengan air panas. aduk rata.
1. Siapkan ketupat yang sudah matang, iris tipis.
1. Penyajian: iris ketupat tata di daun pisang yang di pincuk (disemat dengan lidi di bagian ujung daun pisang) lalu siram dengan adonan sambal. tambahkan kerupuk gendar. (kerupuk gendar nya saya beli di tukang sayur).
1. Selamat menikmati, kuliner khas kota Solo. ❤




Gimana nih? Mudah bukan? Itulah cara menyiapkan cabuk rambak yang bisa Anda lakukan di rumah. Selamat mencoba!
