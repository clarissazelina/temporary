---
description: "BIKIN NAGIH! Begini Resep Cucur gula jawa Spesial"
title: "BIKIN NAGIH! Begini Resep Cucur gula jawa Spesial"
slug: 1830-masakan-sederhana-bikin-nagih-begini-resep-cucur-gula-jawa-spesial
date: 2020-07-05T12:44:25.169Z
image: https://img-global.cpcdn.com/recipes/906fe4b42a276d83/751x532cq70/cucur-gula-jawa-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/906fe4b42a276d83/751x532cq70/cucur-gula-jawa-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/906fe4b42a276d83/751x532cq70/cucur-gula-jawa-foto-resep-utama.jpg
author: Agnes Delgado
ratingvalue: 4.4
reviewcount: 14
recipeingredient:
- "100 gr tepung terigu"
- "100 gr tepung beras"
- "150 gr gula jawa"
- "250 ml air kelapa"
- "1/2 sdt garam"
- "Secukupnya minyak untuk menggoreng"
recipeinstructions:
- "Sisir gula jawa, campurkan dengan air kelapa dan garam. Masak hingga gula larut"
- "Tunggu sampai hangat-hangat kuku"
- "Campur semua bahan kering, campurkan setengah cairan gula. Aduk rata"
- "Tambahkan air gula sisanya. Aduk rata kembali"
- "Diamkan 30 menit. Tutup serbet bersih"
- "Panaskan minyak di wajan cekung, api sedang cenderung kecil"
- "Tuangkan 1 centung adonan. Tunggu berserat. Siram-siram dengan minyak yang ada di pinggirnya"
- "Tunggu matang, balik. Tusuk dengan tusuk sate. Tiriskan"
- "Siap dinikmati"
categories:
- Resep
tags:
- cucur
- gula
- jawa

katakunci: cucur gula jawa 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dessert

---


![Cucur gula jawa](https://img-global.cpcdn.com/recipes/906fe4b42a276d83/751x532cq70/cucur-gula-jawa-foto-resep-utama.jpg)

Sedang mencari inspirasi resep cucur gula jawa yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal cucur gula jawa yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.

Nama je jawa, tapi asal-usulnya dari Utara. Keras di tepi lembut di dalam seperti apam berongga. Kue cucur ini asli dari Jawa.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari cucur gula jawa, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan cucur gula jawa yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Nah, kali ini kita coba, yuk, buat cucur gula jawa sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa membuat Cucur gula jawa menggunakan 6 jenis bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam mengolah Cucur gula jawa:

1. Ambil 100 gr tepung terigu
1. Gunakan 100 gr tepung beras
1. Sediakan 150 gr gula jawa
1. Sediakan 250 ml air kelapa
1. Siapkan 1/2 sdt garam
1. Ambil Secukupnya minyak untuk menggoreng


Kuih Cucur pun ada beberapa jenis, cucur badak, cucur berlauk, cucur gula merah dan cucur Jawa. Di Brunei Darussalam Kue Cucur dikenal dikenal dengan nama Kuih Pinyaram. Saat gula merah berubah menjadi karamel, tambahkan sedikit air ke dalamnya. Panaskan minyak yang ada di dalam wajan, kemudian goreng adonan kue cucur sampai berwarna keemasan. 

##### Cara meracik Cucur gula jawa:

1. Sisir gula jawa, campurkan dengan air kelapa dan garam. Masak hingga gula larut
1. Tunggu sampai hangat-hangat kuku
1. Campur semua bahan kering, campurkan setengah cairan gula. Aduk rata
1. Tambahkan air gula sisanya. Aduk rata kembali
1. Diamkan 30 menit. Tutup serbet bersih
1. Panaskan minyak di wajan cekung, api sedang cenderung kecil
1. Tuangkan 1 centung adonan. Tunggu berserat. Siram-siram dengan minyak yang ada di pinggirnya
1. Tunggu matang, balik. Tusuk dengan tusuk sate. Tiriskan
1. Siap dinikmati


Kue cucur gula merah ini merupakan kue tradisional khas Betawi. Cita rasanya begitu enak dan lezat, sehingga membuat siapa saja yang menyantapnya ketagihan. Langkah pertama kita campur beberapa bahan seperti tepung beras, tepung terigu dan berikan taburan garam sedikit untuk. Cucur jawa merupakan sebuah kuih lama kegemaran ramai yang berasal dari utara. Ia dianggap berhasil apabila bahagian tepinya menjadi bertebing dan tebingnya itu perlulah kerinting dan bergerigi. cucur kue jadło jedzenie pożywienie żywność deser indonezja indonezyjski tradycyjne aren as azja azjatycki dalszy plan drugi plan kontekst tapeta tło brąz brązowy bua ciastko ciasto kolorowy. 

Bagaimana? Mudah bukan? Itulah cara membuat cucur gula jawa yang bisa Anda lakukan di rumah. Selamat mencoba!
