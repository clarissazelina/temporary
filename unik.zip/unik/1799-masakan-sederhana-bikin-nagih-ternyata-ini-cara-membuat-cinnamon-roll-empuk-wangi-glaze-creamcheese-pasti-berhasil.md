---
description: "BIKIN NAGIH! Ternyata Ini Cara Membuat Cinnamon Roll Empuk Wangi - glaze creamcheese🤩 Pasti Berhasil"
title: "BIKIN NAGIH! Ternyata Ini Cara Membuat Cinnamon Roll Empuk Wangi - glaze creamcheese🤩 Pasti Berhasil"
slug: 1799-masakan-sederhana-bikin-nagih-ternyata-ini-cara-membuat-cinnamon-roll-empuk-wangi-glaze-creamcheese-pasti-berhasil
date: 2020-07-30T13:47:07.362Z
image: https://img-global.cpcdn.com/recipes/4ffa7a539767b0d7/751x532cq70/cinnamon-roll-empuk-wangi-glaze-creamcheese🤩-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4ffa7a539767b0d7/751x532cq70/cinnamon-roll-empuk-wangi-glaze-creamcheese🤩-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/4ffa7a539767b0d7/751x532cq70/cinnamon-roll-empuk-wangi-glaze-creamcheese🤩-foto-resep-utama.jpg
author: Mitchell Aguilar
ratingvalue: 4.8
reviewcount: 7
recipeingredient:
- " Bahan Biang"
- "120 ml air hangat"
- "1 sdt gula pasir"
- "4 gr ragi instan fermipan atau mauripan"
- " Bahan A"
- "230 tepung terigu Cakra kembar"
- "50 gr tepung Segitiga biru"
- "40 gr gula pasir"
- "1 sdm susu bubuk"
- "1 butir telur ayam"
- " Bahan B"
- "50 gr butter"
- "1/4 sdt garam"
- " Isian"
- "30 gr gula palem"
- "20 gr gula pasir"
- "1 sdt cinnamon bubuk"
- "1 genggam kismis potong kecil kecil"
- " Olesan"
- "30 gr butter dicairkan"
- " Topping  Glaze"
- "80 ml susu cair full cream"
- "80 gr creamcheese"
- "3 sdm gula pasir"
recipeinstructions:
- "Campurkan bahan biang, tutup dan diamkan 10 menit, bila permukaan berbuih maka tanda ragi aktif, bila tidak ulangi proses dengan bahan yang baru ya."
- "Tuang perlahan bahan biang ke bahan A, aduk menggunakan tangan sampai kalis. Kemudian tambahkan bahan B ditengah adonan, uleni sampai kalis elastis, bisa pakai tangan juga ya💪"
- "Istirahatkan adonan hingga mengembang 2 kali lipat sekitar 40-60 menit. Tutup dengan plastik wrap atau lap bersih."
- "Setelah mengembang, tinju dan kempiskan adonan, uleni sebentar, bulatkan kemudian gilas dengan rolling pin. Bentuk sama rata ya seperti persegi panjang, agar setiap potongannya simetris👍"
- "Campur gula palem, gula pasir dan bubuk cinnamon kemudian taburi diatas permukaan adonan roti, tekan tekan supaya menempel, baru taburi kismis❤️"
- "Gulung adonan kemudian potong sepanjang 3 cm sama besar atau sesuai selera ya, saya jadi 12 potong menggunakan loyang 24 cm x 24 cm, potongnya pakai pisau tidak apa tapi jangan lupa taburi tepung terigu biar ga nempel🥳 Susun pada loyang yang telah dioles margarin tipis dan dialas kertas roti😚"
- "Panaskan oven api bawah 180 derajat minimal 10 menit sebelum loyang dimasukkan. Oles butter cair pada permukaan Cinnamon. Masukan ke oven, panggang selama 20 menit, kemudian pindah ke api atas 3-5 menit supaya atasnya coklat cantik atau silakan sesuaikan dengan oven dan selera masing masing yaa😄☺️"
- "Keluarkan dari oven, dinginkan di cooling rack sambil buat glazenya, campur semua bahan jadi satu kemudian didihkan diatas kompor dengan api kecil sampai creamcheese mencair. Dinginkan."
- "Siap dihidangkan, wihh wangi cinnamon empuk roti berpadu glaze creamcheese, pas bangetttt buat pecinta cinnamon roll❤️ ga pake lama langsung lenyap🤪"
- "Kalau buat sendiri glazenya bebass😍😍"
categories:
- Resep
tags:
- cinnamon
- roll
- empuk

katakunci: cinnamon roll empuk 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT59M"
recipeyield: "4"
recipecategory: Lunch

---


![Cinnamon Roll Empuk Wangi - glaze creamcheese🤩](https://img-global.cpcdn.com/recipes/4ffa7a539767b0d7/751x532cq70/cinnamon-roll-empuk-wangi-glaze-creamcheese🤩-foto-resep-utama.jpg)

Lagi mencari ide resep cinnamon roll empuk wangi - glaze creamcheese🤩 yang unik? Cara membuatnya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal cinnamon roll empuk wangi - glaze creamcheese🤩 yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari cinnamon roll empuk wangi - glaze creamcheese🤩, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan cinnamon roll empuk wangi - glaze creamcheese🤩 enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.




Nah, kali ini kita coba, yuk, kreasikan cinnamon roll empuk wangi - glaze creamcheese🤩 sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Cinnamon Roll Empuk Wangi - glaze creamcheese🤩 menggunakan 24 jenis bahan dan 10 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Cinnamon Roll Empuk Wangi - glaze creamcheese🤩:

1. Ambil  Bahan Biang
1. Ambil 120 ml air hangat
1. Siapkan 1 sdt gula pasir
1. Sediakan 4 gr ragi instan (fermipan atau mauripan)
1. Siapkan  Bahan A
1. Siapkan 230 tepung terigu Cakra kembar
1. Gunakan 50 gr tepung Segitiga biru
1. Gunakan 40 gr gula pasir
1. Sediakan 1 sdm susu bubuk
1. Siapkan 1 butir telur ayam
1. Ambil  Bahan B
1. Siapkan 50 gr butter
1. Ambil 1/4 sdt garam
1. Gunakan  Isian
1. Sediakan 30 gr gula palem
1. Gunakan 20 gr gula pasir
1. Sediakan 1 sdt cinnamon bubuk
1. Ambil 1 genggam kismis (potong kecil kecil)
1. Gunakan  Olesan
1. Siapkan 30 gr butter (dicairkan)
1. Sediakan  Topping / Glaze
1. Sediakan 80 ml susu cair full cream
1. Ambil 80 gr creamcheese
1. Siapkan 3 sdm gula pasir




##### Cara membuat Cinnamon Roll Empuk Wangi - glaze creamcheese🤩:

1. Campurkan bahan biang, tutup dan diamkan 10 menit, bila permukaan berbuih maka tanda ragi aktif, bila tidak ulangi proses dengan bahan yang baru ya.
1. Tuang perlahan bahan biang ke bahan A, aduk menggunakan tangan sampai kalis. Kemudian tambahkan bahan B ditengah adonan, uleni sampai kalis elastis, bisa pakai tangan juga ya💪
1. Istirahatkan adonan hingga mengembang 2 kali lipat sekitar 40-60 menit. Tutup dengan plastik wrap atau lap bersih.
1. Setelah mengembang, tinju dan kempiskan adonan, uleni sebentar, bulatkan kemudian gilas dengan rolling pin. Bentuk sama rata ya seperti persegi panjang, agar setiap potongannya simetris👍
1. Campur gula palem, gula pasir dan bubuk cinnamon kemudian taburi diatas permukaan adonan roti, tekan tekan supaya menempel, baru taburi kismis❤️
1. Gulung adonan kemudian potong sepanjang 3 cm sama besar atau sesuai selera ya, saya jadi 12 potong menggunakan loyang 24 cm x 24 cm, potongnya pakai pisau tidak apa tapi jangan lupa taburi tepung terigu biar ga nempel🥳 Susun pada loyang yang telah dioles margarin tipis dan dialas kertas roti😚
1. Panaskan oven api bawah 180 derajat minimal 10 menit sebelum loyang dimasukkan. Oles butter cair pada permukaan Cinnamon. Masukan ke oven, panggang selama 20 menit, kemudian pindah ke api atas 3-5 menit supaya atasnya coklat cantik atau silakan sesuaikan dengan oven dan selera masing masing yaa😄☺️
1. Keluarkan dari oven, dinginkan di cooling rack sambil buat glazenya, campur semua bahan jadi satu kemudian didihkan diatas kompor dengan api kecil sampai creamcheese mencair. Dinginkan.
1. Siap dihidangkan, wihh wangi cinnamon empuk roti berpadu glaze creamcheese, pas bangetttt buat pecinta cinnamon roll❤️ ga pake lama langsung lenyap🤪
1. Kalau buat sendiri glazenya bebass😍😍




Bagaimana? Mudah bukan? Itulah cara membuat cinnamon roll empuk wangi - glaze creamcheese🤩 yang bisa Anda praktikkan di rumah. Selamat mencoba!
