---
description: "WAJIB DICOBA! Ternyata Ini Cara Membuat Sup Tegean khas Banyumas Enak"
title: "WAJIB DICOBA! Ternyata Ini Cara Membuat Sup Tegean khas Banyumas Enak"
slug: 1723-masakan-sederhana-wajib-dicoba-ternyata-ini-cara-membuat-sup-tegean-khas-banyumas-enak
date: 2020-04-13T22:24:40.479Z
image: https://img-global.cpcdn.com/recipes/7641b536765db521/751x532cq70/sup-tegean-khas-banyumas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/7641b536765db521/751x532cq70/sup-tegean-khas-banyumas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/7641b536765db521/751x532cq70/sup-tegean-khas-banyumas-foto-resep-utama.jpg
author: Belle Gray
ratingvalue: 4.3
reviewcount: 6
recipeingredient:
- "1 ikat daun bayam"
- "3 buah jagung manis"
- "1 ruas kencur"
- "3 siung bawang putih"
- "1 batang daun bawang"
- "secukupnya Garam"
- "secukupnya Gula"
- "secukupnya Kaldu bubuk"
- "secukupnya Air"
recipeinstructions:
- "Siangi daun bayam dan cuci kemudian sisihkan"
- "Potong-potong jagung manis dan cuci kemudian sisihkan"
- "Iris-iris bawang putih,kencur juga daun bawang sisihkan"
- "Siapkan air dalam panci kemudian didihkan, setelah mendidih masukkan jagung manis"
- "Kemudian masukkan bawang putih juga kencur jangan lupa masukkan garam, gula juga kaldu bubuk"
- "Aduk-aduk koreksi rasa setelah jagung agak lunak kemudian masukkan daun bayam dan daun bawang"
- "Masak sampe daun bayam agak layu (jangan sampe kematangan)"
- "Setelah pas tingkat kematangan nya angkat dan sajikan bersama nasi"
categories:
- Resep
tags:
- sup
- tegean
- khas

katakunci: sup tegean khas 
nutrition: 110 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT46M"
recipeyield: "1"
recipecategory: Lunch

---


![Sup Tegean khas Banyumas](https://img-global.cpcdn.com/recipes/7641b536765db521/751x532cq70/sup-tegean-khas-banyumas-foto-resep-utama.jpg)

Sedang mencari inspirasi resep sup tegean khas banyumas yang unik? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal sup tegean khas banyumas yang enak selayaknya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sup tegean khas banyumas, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan sup tegean khas banyumas enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.

Salah satu makanan khas Banyumas ini berupa sup sayur berkuah bening yang bernama tegean. Meski penampilannya tampak sangat sederhana tapi terasa sangat menyegarkan. Sup ini berisi beragam sayuran yang diracik dengan ditambahkan bumbu khusus sehingga sayuran jadi terasa.


Berikut ini ada beberapa cara mudah dan praktis dalam mengolah sup tegean khas banyumas yang siap dikreasikan. Anda bisa menyiapkan Sup Tegean khas Banyumas menggunakan 9 bahan dan 8 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat Sup Tegean khas Banyumas:

1. Sediakan 1 ikat daun bayam
1. Sediakan 3 buah jagung manis
1. Sediakan 1 ruas kencur
1. Gunakan 3 siung bawang putih
1. Gunakan 1 batang daun bawang
1. Ambil secukupnya Garam
1. Sediakan secukupnya Gula
1. Siapkan secukupnya Kaldu bubuk
1. Gunakan secukupnya Air


Tegean adalah sebutan khas banyumas untuk sup sayur berkuah bening, yang tampak sederhana. namun sangat menyegarkan, isinya bermacam-macam sayuran yang diracik menggunakan bumbu khusus sehingga menjadi sayuran yang enak dan lezat. sayur-mayur berupa bayam, wortel, jagung. Tegean ini adalah sayuran bening khas dari Banyumas. Sayuran yang digunakan sebagai bahan masakan bermacam-macam seperti kentang, wortel, kubis, sawi, bayam, seledri, muncang. Sayuran-sayuran tersebut diracik menggunakan bumbu khusus dengan taburan bawang goreng sehingga. 

##### Langkah-langkah mengolah Sup Tegean khas Banyumas:

1. Siangi daun bayam dan cuci kemudian sisihkan
1. Potong-potong jagung manis dan cuci kemudian sisihkan
1. Iris-iris bawang putih,kencur juga daun bawang sisihkan
1. Siapkan air dalam panci kemudian didihkan, setelah mendidih masukkan jagung manis
1. Kemudian masukkan bawang putih juga kencur jangan lupa masukkan garam, gula juga kaldu bubuk
1. Aduk-aduk koreksi rasa setelah jagung agak lunak kemudian masukkan daun bayam dan daun bawang
1. Masak sampe daun bayam agak layu (jangan sampe kematangan)
1. Setelah pas tingkat kematangan nya angkat dan sajikan bersama nasi


Tegean adalah sebutan khas banyumas untuk sup sayur berkuah bening, yang tampak sederhana. namun sangat menyegarkan, isinya bermacam-macam sayuran yang diracik menggunakan bumbu khusus sehingga menjadi sayuran yang enak dan lezat. sayur-mayur berupa bayam, wortel, jagung. Sup sayur berkuah bening khas Purwokerto dan Banyumas ini bernama Tegean. Berbahan dasar jagung muda, bayam, daun katuk, kecambah, kedelai hitam, wortel, dan ditambah racikan bumbu. Tegean biasa disajikan bersama dengan daging sapi atau daging ayam, rasanya segar dan gurih. Satu lagi camilan tradisonal yang berasal dari Banyumas dan Cilacap Jawa Tengah yang sayang bila terlewatkan. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Sup Tegean khas Banyumas yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi ide dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
