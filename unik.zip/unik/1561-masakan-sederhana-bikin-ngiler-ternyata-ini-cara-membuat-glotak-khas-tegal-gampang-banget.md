---
description: "BIKIN NGILER! Ternyata Ini Cara Membuat Glotak khas tegal Gampang Banget"
title: "BIKIN NGILER! Ternyata Ini Cara Membuat Glotak khas tegal Gampang Banget"
slug: 1561-masakan-sederhana-bikin-ngiler-ternyata-ini-cara-membuat-glotak-khas-tegal-gampang-banget
date: 2020-06-17T17:28:22.497Z
image: https://img-global.cpcdn.com/recipes/15580ca5c125511a/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/15580ca5c125511a/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/15580ca5c125511a/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
author: Danny Hicks
ratingvalue: 4.4
reviewcount: 3
recipeingredient:
- "1 bungkus gembus ampas tahu1k"
- "2 lembar daun jeruk"
- "1 daun salam"
- "1 ruas lengkuas geprek"
- "1 batang sereh"
- "100 grm tulang  cekerkepala ayam"
- "1 jeruk nipis"
- " Air"
- " Garamgularoyco"
- "2 cabe ijo"
- " Bumbu uleg"
- "2 buah bawang merah"
- "1 bawang putih"
- "5 cabe merah"
- "5 cabe setan"
recipeinstructions:
- "Lumuri jeruk nipis tulang ayam/ ceker+ kepala biar ga amis, diamkan beberapa menit dan bilas menggunakan air bersih"
- "Rebus air dan masukan tulang /ceker tadi hingga matang (air jgn di buang)"
- "Halus kan bumbu uleg beri garam sedikit (tiriskan) kemudian uleg gembus tadi, dan iris cabe ijo"
- "Masukan minyak sedikit dan tumis bumbu uleg tadi, kemudian masukan salam, lengkuas, daun jeruk, sereh, cabe ijo, tulang/ceker+kepala"
- "Masukan gembus yg sudah di haluskan, air rebusan tulang dan bisa di tambah air lagi"
- "Terakhir masukan garam+royco+gula tes rasa.. Hidangkan"
- "Paling cucook dicocol pake kerupukk 😋👌"
categories:
- Resep
tags:
- glotak
- khas
- tegal

katakunci: glotak khas tegal 
nutrition: 293 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dessert

---


![Glotak khas tegal](https://img-global.cpcdn.com/recipes/15580ca5c125511a/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg)

Lagi mencari inspirasi resep glotak khas tegal yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal glotak khas tegal yang enak harusnya sih punya aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari glotak khas tegal, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan glotak khas tegal yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.

Glotak salah satu kuliner unik khas Tegal. Karena bunyinya \' glotak-glotak \' maka disebutlah si makanan tradisional ini dengan nama glotak xD Glotak, banyak ditemuin di pasar-pasar tradisional. Glotak adalah makanan khas tegal, dengan bahan dasar Gembus/Dage.


Nah, kali ini kita coba, yuk, ciptakan glotak khas tegal sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Glotak khas tegal menggunakan 15 jenis bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk mengolah Glotak khas tegal:

1. Ambil 1 bungkus gembus/ ampas tahu(1k)
1. Siapkan 2 lembar daun jeruk
1. Ambil 1 daun salam
1. Siapkan 1 ruas lengkuas geprek
1. Sediakan 1 batang sereh
1. Sediakan 100 grm tulang / ceker+kepala ayam
1. Sediakan 1 jeruk nipis
1. Gunakan  Air
1. Gunakan  Garam+gula+royco
1. Ambil 2 cabe ijo
1. Ambil  Bumbu uleg
1. Ambil 2 buah bawang merah
1. Ambil 1 bawang putih
1. Ambil 5 cabe merah
1. Ambil 5 cabe setan


Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya. Proses pemasakan jajanan glotak ini menyebabkan tulang ayam bergesekan dengan panci, sehingga menimbulkan suara glotak-glotak, sehingga jajanan ini pun dikenal dengan. Ke Tegal jangan sampai melewatkan jajanan khas yang sudah dikenal ratusan tahun silam ini ya. Berikut ini adalah beberapa makanan khas Tegal yang sering diburu pecinta kuliner. 

##### Langkah-langkah menyiapkan Glotak khas tegal:

1. Lumuri jeruk nipis tulang ayam/ ceker+ kepala biar ga amis, diamkan beberapa menit dan bilas menggunakan air bersih
1. Rebus air dan masukan tulang /ceker tadi hingga matang (air jgn di buang)
1. Halus kan bumbu uleg beri garam sedikit (tiriskan) kemudian uleg gembus tadi, dan iris cabe ijo
1. Masukan minyak sedikit dan tumis bumbu uleg tadi, kemudian masukan salam, lengkuas, daun jeruk, sereh, cabe ijo, tulang/ceker+kepala
1. Masukan gembus yg sudah di haluskan, air rebusan tulang dan bisa di tambah air lagi
1. Terakhir masukan garam+royco+gula tes rasa.. Hidangkan
1. Paling cucook dicocol pake kerupukk 😋👌


Anda bisa mendapatkan sate kambing khas Tegal dengan mudah di seluruh kota Tegal. Glotak pada umumnya terbuat dari gembus yang dimasak dengan berbagai bumbu. Ada banyak warung makan di Tegal yang menjual Nasi Lengko, sehingga kamu bisa mencarinya dengan mudah. Itulah sejumlah makanan khas Tegal yang patut kamu ketahui. Dari makanan-makanan di atas, kita pun jadi tahu kalau Tegal itu punya banyak makanan khas, dan bukan hanya sekadar. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan glotak khas tegal yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
