---
description: "RECOMMENDED! Begini Cara Membuat Nagasari Potong "
title: "RECOMMENDED! Begini Cara Membuat Nagasari Potong "
slug: 1179-masakan-sederhana-recommended-begini-cara-membuat-nagasari-potong
date: 2020-05-28T08:52:56.924Z
image: https://img-global.cpcdn.com/recipes/0f4f7755c1605c90/751x532cq70/nagasari-potong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/0f4f7755c1605c90/751x532cq70/nagasari-potong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/0f4f7755c1605c90/751x532cq70/nagasari-potong-foto-resep-utama.jpg
author: Leonard Rivera
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- " Bahan A "
- "12 Buah Pisang Raja kukus"
- "900 ml Santan kekentalan sedang"
- "200 gR gula PasirSesuai selera"
- "1/2 Sdt gaRam halus"
- "1/4 Vanilli bubuk"
- " Bahan B "
- "250 gR Tepung beras"
- "100 gR Tepung Tapioka"
- "3 Lembar daun Pandan"
recipeinstructions:
- "Siapkan Semua Bahan.."
- "Kukus Pisang selama 15 menit & iris tipis sesuai selera saya bagi 2 iris"
- "Rebus Jadi 1 Bahan A,Aduk sampai mendidih & Biarkan Sampai Agak dingin"
- "Masukkan Bahan B secara bertahap ke dalam bahan A sambil di Aduk menggunakan Whisk sampai Tercampur rata Lalu saring"
- "Panaskan dandang/Kukusan siapkan loyang & oles tipis menggunakan minyak goreng"
- "Tuang Adonan ke dalam loyang sebanyak 3 sendok Sayur / ketebalan sesuai selera/Tiap lapisan saya kukus 10 menit tergantung ketebalanx"
- "Setelah permukaan atas set/hampir matang,Susun Pisang yang sudah di kukus & ratakan Tuang lagi Adonan,Lanjutkan Lapisan Adonan & Pisang Sampai Habis"
- "Selamat mencoBa.."
categories:
- Resep
tags:
- nagasari
- potong

katakunci: nagasari potong 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Dessert

---


![Nagasari Potong](https://img-global.cpcdn.com/recipes/0f4f7755c1605c90/751x532cq70/nagasari-potong-foto-resep-utama.jpg)

Lagi mencari ide resep nagasari potong yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal nagasari potong yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Hallo sahabat dapurku semua. 😃 Kali ini Wangi Pandan bagikan resep Kue Nagasari pake loyang, dan tanpa daun pisang. Masak santan, gula pasir, garam dan daun pandan. Nagasari merupakan kue basah yang dibuat dari tepung beras, sagu, santan, dan gula yang Tekstur kuenya legit, kenyal, dan manis.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari nagasari potong, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan nagasari potong yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian spesial.


Nah, kali ini kita coba, yuk, variasikan nagasari potong sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Nagasari Potong memakai 10 jenis bahan dan 8 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Nagasari Potong:

1. Ambil  Bahan A :
1. Siapkan 12 Buah Pisang Raja kukus
1. Siapkan 900 ml Santan kekentalan sedang
1. Ambil 200 gR gula Pasir/Sesuai selera
1. Gunakan 1/2 Sdt gaRam halus
1. Siapkan 1/4 Vanilli bubuk
1. Ambil  Bahan B :
1. Gunakan 250 gR Tepung beras
1. Ambil 100 gR Tepung Tapioka
1. Gunakan 3 Lembar daun Pandan


Camilan yang ini dapat Anda buat sendiri di rumah. Nagasari adalah kue basah tradisional Indonesia yang cukup mudah dibuat di rumah. Faktanya tidak semua kue tradisional sulit pembuatannya loh. Seperti Resep Kue Nagasari dari SajianSedap berikut. 

##### Langkah-langkah membuat Nagasari Potong:

1. Siapkan Semua Bahan..
1. Kukus Pisang selama 15 menit & iris tipis sesuai selera saya bagi 2 iris
1. Rebus Jadi 1 Bahan A,Aduk sampai mendidih & Biarkan Sampai Agak dingin
1. Masukkan Bahan B secara bertahap ke dalam bahan A sambil di Aduk menggunakan Whisk sampai Tercampur rata Lalu saring
1. Panaskan dandang/Kukusan siapkan loyang & oles tipis menggunakan minyak goreng
1. Tuang Adonan ke dalam loyang sebanyak 3 sendok Sayur / ketebalan sesuai selera/Tiap lapisan saya kukus 10 menit tergantung ketebalanx
1. Setelah permukaan atas set/hampir matang,Susun Pisang yang sudah di kukus & ratakan Tuang lagi Adonan,Lanjutkan Lapisan Adonan & Pisang Sampai Habis
1. Selamat mencoBa..


Nagasari is a traditional Southeast Asian steamed cake, originating from Indonesia, made from rice flour, coconut milk and sugar, filled with slices of banana. It is usually wrapped in banana leaves before being steamed, or prepared with pandan that gives it aroma. Keluarkan nagasari dari cetakan, potong-potong tipis, lalu sajikan. Kamu bisa merebus pisang terlebih dahulu selama lima menit sebelum dipotong tipis-tipis dan digunakan. Kayu nagasari atau bisa juga disebut galih nagasari adalah salah satu kayu yang dianggap memiliki daya magis bagi masyarakat Jawa khususnya Cirebon. 

Gimana nih? Gampang kan? Itulah cara membuat nagasari potong yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
