---
description: "TERUNGKAP! Ternyata Ini Resep Bu Payeh Aceh Enak"
title: "TERUNGKAP! Ternyata Ini Resep Bu Payeh Aceh Enak"
slug: 155-masakan-sederhana-terungkap-ternyata-ini-resep-bu-payeh-aceh-enak
date: 2020-04-09T06:22:33.880Z
image: https://img-global.cpcdn.com/recipes/86b016a5be6a5f99/751x532cq70/bu-payeh-aceh-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/86b016a5be6a5f99/751x532cq70/bu-payeh-aceh-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/86b016a5be6a5f99/751x532cq70/bu-payeh-aceh-foto-resep-utama.jpg
author: Ronnie Gilbert
ratingvalue: 4.6
reviewcount: 9
recipeingredient:
- "250 gr Beras ketan"
- "300 ml santan cair"
- "1 sdm Gula Pasir"
- " Garam secukup nya"
- " Daun Pandan"
- " Daun pisang muda"
- " Kuah Santan"
- "700 ml Santan cair"
- "150 gr Gula Pasir sesuai selera"
- "secukupnya Garam"
- "2 Nangka masak potong potong"
- " Atau pisang masak"
- "1 lembar Daun pandan"
recipeinstructions:
- "Cuci beras hingga bersih, campurkan dengan gula pasir,santan,garam dan daun pandan masak hingga air menyerap"
- "Bungkus dengan daun pisang muda, rekatkan dengan tusuk gigi kemudian kukus hingga matang"
- "Campur bahan kuah menjadi satu kecuali nangka masak hingga mendidih sambil di aduk agar santan nya gak pecah. Setelah mendidih masukkan nangka tunggu hingga mendidih lagi sambil di aduk."
- "Masukkan nasi ketan yang sudah di kukus ke dalam kuah aduk sebentar kemudian matikan api nya dan angkat"
- "Bu Payeh siap dihidangkan"
- "Bisa di tambahkan gula merah kalau suka"
categories:
- Resep
tags:
- bu
- payeh
- aceh

katakunci: bu payeh aceh 
nutrition: 124 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Bu Payeh Aceh](https://img-global.cpcdn.com/recipes/86b016a5be6a5f99/751x532cq70/bu-payeh-aceh-foto-resep-utama.jpg)

Sedang mencari inspirasi resep bu payeh aceh yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal bu payeh aceh yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari bu payeh aceh, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan bu payeh aceh yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, siapkan bu payeh aceh sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Bu Payeh Aceh menggunakan 13 jenis bahan dan 6 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah Bu Payeh Aceh:

1. Gunakan 250 gr Beras ketan
1. Siapkan 300 ml santan cair
1. Ambil 1 sdm Gula Pasir
1. Sediakan  Garam secukup nya
1. Siapkan  Daun Pandan
1. Ambil  Daun pisang muda
1. Siapkan  Kuah Santan
1. Gunakan 700 ml Santan cair
1. Gunakan 150 gr Gula Pasir (sesuai selera)
1. Sediakan secukupnya Garam
1. Gunakan 2 Nangka masak potong potong
1. Siapkan  Atau pisang masak
1. Sediakan 1 lembar Daun pandan




##### Cara meracik Bu Payeh Aceh:

1. Cuci beras hingga bersih, campurkan dengan gula pasir,santan,garam dan daun pandan masak hingga air menyerap
1. Bungkus dengan daun pisang muda, rekatkan dengan tusuk gigi kemudian kukus hingga matang
1. Campur bahan kuah menjadi satu kecuali nangka masak hingga mendidih sambil di aduk agar santan nya gak pecah. Setelah mendidih masukkan nangka tunggu hingga mendidih lagi sambil di aduk.
1. Masukkan nasi ketan yang sudah di kukus ke dalam kuah aduk sebentar kemudian matikan api nya dan angkat
1. Bu Payeh siap dihidangkan
1. Bisa di tambahkan gula merah kalau suka




Bagaimana? Gampang kan? Itulah cara membuat bu payeh aceh yang bisa Anda praktikkan di rumah. Selamat mencoba!
