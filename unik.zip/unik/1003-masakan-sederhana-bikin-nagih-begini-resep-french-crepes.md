---
description: "BIKIN NAGIH! Begini Resep French Crepes "
title: "BIKIN NAGIH! Begini Resep French Crepes "
slug: 1003-masakan-sederhana-bikin-nagih-begini-resep-french-crepes
date: 2020-07-31T08:25:09.010Z
image: https://img-global.cpcdn.com/recipes/963e22c5f8f9181e/751x532cq70/french-crepes-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/963e22c5f8f9181e/751x532cq70/french-crepes-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/963e22c5f8f9181e/751x532cq70/french-crepes-foto-resep-utama.jpg
author: Alberta Robertson
ratingvalue: 4.5
reviewcount: 10
recipeingredient:
- "2 butir telur"
- "240 ml susu cair"
- "128 gr tepung serbaguna"
- "1 sdm butter lelehkan"
- "1 sdt vanilla pasta"
- "1 sdt gula"
- "Sejumput garam"
recipeinstructions:
- "Blender semua bahan jadi satu"
- "Istirahatkan adonan selama 30 minutes"
- "Panaskan pan dan tuangkan adonan secukupnya. Masak hingga kecoklatan. Balik satu kali saja."
categories:
- Resep
tags:
- french
- crepes

katakunci: french crepes 
nutrition: 142 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "3"
recipecategory: Dinner

---


![French Crepes](https://img-global.cpcdn.com/recipes/963e22c5f8f9181e/751x532cq70/french-crepes-foto-resep-utama.jpg)

Lagi mencari ide resep french crepes yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal french crepes yang enak harusnya sih punya aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari french crepes, pertama dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika mau menyiapkan french crepes enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.




Berikut ini ada beberapa cara mudah dan praktis untuk membuat french crepes yang siap dikreasikan. Anda bisa menyiapkan French Crepes menggunakan 7 bahan dan 3 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik French Crepes:

1. Sediakan 2 butir telur
1. Siapkan 240 ml susu cair
1. Sediakan 128 gr tepung serbaguna
1. Siapkan 1 sdm butter, lelehkan
1. Siapkan 1 sdt vanilla pasta
1. Gunakan 1 sdt gula
1. Ambil Sejumput garam




##### Langkah-langkah membuat French Crepes:

1. Blender semua bahan jadi satu
1. Istirahatkan adonan selama 30 minutes
1. Panaskan pan dan tuangkan adonan secukupnya. Masak hingga kecoklatan. Balik satu kali saja.




Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan French Crepes yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Selamat mencoba!
