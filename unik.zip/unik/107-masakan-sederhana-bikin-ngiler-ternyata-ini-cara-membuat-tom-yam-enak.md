---
description: "BIKIN NGILER! Ternyata Ini Cara Membuat Tom yam Enak"
title: "BIKIN NGILER! Ternyata Ini Cara Membuat Tom yam Enak"
slug: 107-masakan-sederhana-bikin-ngiler-ternyata-ini-cara-membuat-tom-yam-enak
date: 2020-08-28T04:31:26.943Z
image: https://img-global.cpcdn.com/recipes/5250033b4212ba92/751x532cq70/tom-yam-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5250033b4212ba92/751x532cq70/tom-yam-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5250033b4212ba92/751x532cq70/tom-yam-foto-resep-utama.jpg
author: Herman Rowe
ratingvalue: 4
reviewcount: 9
recipeingredient:
- "100 grm ayam tanpa tulang"
- "100 grm udang"
- "100 grm cumi cumi"
- "100 grm isi kerang"
- "50 grm asam jawa"
- "3/4 gelas cabe giling"
- "2 bt serai"
- "5 lb daun jeruk"
- "8 cm laos  lengkuas"
- "5 cm jahe"
- "2 labu bawang besar"
- "5 siung bawang puteh"
- "1/4 gelas air jeruk"
- "15 biji cabai"
- "2 biji tomato"
- "1 lt air bagi 2"
- "2 biji tom yam kiub paste"
- "secukupnya garam"
recipeinstructions:
- "Cuci bersih bahan utama, lalu rebus dalam 5 mnt"
- "Setelah masak, tumis bawang putih, bawang merah, jahe, lengkuas, serai daun jeruk, setelah layu masukkan cabai giling"
- "Masukkan air asam, air jeruk, lalu setelah mendidih matikan dan campur kan dg daging yg telah di rebus,"
- "Tunggu sampai mendidih sambil lalu buang busa yg ada di atas kuah"
- "Masukkan cabai, tomat, dan tomyam kiub, garam"
- "Setelah rasa masam, dan pedas nya balance baru angkat. boleh di makan dg nasi sbg kuah, atau mihun"
categories:
- Resep
tags:
- tom
- yam

katakunci: tom yam 
nutrition: 196 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT55M"
recipeyield: "4"
recipecategory: Lunch

---


![Tom yam](https://img-global.cpcdn.com/recipes/5250033b4212ba92/751x532cq70/tom-yam-foto-resep-utama.jpg)

Anda sedang mencari ide resep tom yam yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal tom yam yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Tom yum or tom yam is a type of hot and sour Thai soup, usually cooked with shrimp (prawn). Tom yum has its origin in Thailand. The words \"tom yam\" are derived from two Thai words.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari tom yam, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan tom yam yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian spesial.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah tom yam yang siap dikreasikan. Anda bisa membuat Tom yam memakai 18 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Tom yam:

1. Ambil 100 grm ayam tanpa tulang
1. Siapkan 100 grm udang
1. Siapkan 100 grm cumi cumi
1. Ambil 100 grm isi kerang
1. Gunakan 50 grm asam jawa
1. Ambil 3/4 gelas cabe giling
1. Sediakan 2 bt serai
1. Gunakan 5 lb daun jeruk
1. Ambil 8 cm laos / lengkuas
1. Gunakan 5 cm jahe
1. Sediakan 2 labu bawang besar
1. Sediakan 5 siung bawang puteh
1. Siapkan 1/4 gelas air jeruk
1. Siapkan 15 biji cabai
1. Siapkan 2 biji tomato
1. Gunakan 1 lt air (bagi 2)
1. Ambil 2 biji tom yam kiub paste
1. Gunakan secukupnya garam




##### Cara membuat Tom yam:

1. Cuci bersih bahan utama, lalu rebus dalam 5 mnt
1. Setelah masak, tumis bawang putih, bawang merah, jahe, lengkuas, serai daun jeruk, setelah layu masukkan cabai giling
1. Masukkan air asam, air jeruk, lalu setelah mendidih matikan dan campur kan dg daging yg telah di rebus,
1. Tunggu sampai mendidih sambil lalu buang busa yg ada di atas kuah
1. Masukkan cabai, tomat, dan tomyam kiub, garam
1. Setelah rasa masam, dan pedas nya balance baru angkat. boleh di makan dg nasi sbg kuah, atau mihun




Bagaimana? Mudah bukan? Itulah cara menyiapkan tom yam yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
