---
description: "RECOMMENDED! Begini Cara Membuat Olos Tegal Anti Gagal"
title: "RECOMMENDED! Begini Cara Membuat Olos Tegal Anti Gagal"
slug: 1589-masakan-sederhana-recommended-begini-cara-membuat-olos-tegal-anti-gagal
date: 2020-06-20T17:53:50.614Z
image: https://img-global.cpcdn.com/recipes/2eaf3255a245cd51/751x532cq70/olos-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2eaf3255a245cd51/751x532cq70/olos-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2eaf3255a245cd51/751x532cq70/olos-tegal-foto-resep-utama.jpg
author: Fred Berry
ratingvalue: 4.7
reviewcount: 5
recipeingredient:
- "10 Sdm tepung terigu"
- "10 sdm tepung tapioka"
- " Air panas"
- " Isian"
- "10 lembar kol kubis potong tipis2"
- "1 buah wortel potong dadu kecil"
- "2 helai daun bawang iris tipis"
- " Bumbu yang dihakuskan"
- "2 siung Bawang putih"
- "3 siung bawang merah"
- "10 buah cabe rawit sesuai selera"
- " Garam"
- " Penyedap rasa kaldu bubuk"
- " Merica bubuk"
recipeinstructions:
- "Tumis bumbu yang sudah dihaluskan sampai harum"
- "Masukkan irisan wortel, kol dan daun bawang, tumis sampai layu"
- "Tambahkan garam dan penyedap rasa, aduk sebentar lalu sisihkan"
- "Sementara itu tuang tepung terigu dan tepung tapioka ke dalam baskom, tambahkan garam, kaldu bubuk dan merica bubuk secukupnya"
- "Tuang air panas yang sudah mendidih sedikit demi sedikit sambil diaduk dengan sendok sampai kalis, dan bisa dibentuk (jika masih lengket tambah dengan tepung terigu dan tapioka sampai adonan bisa dibentuk)"
- "Isi adonan dengan tumisan sayur"
- "Bentuk bulat-bulat"
- "Siapkan wajan, tuang minyak lalu masukkan adonan olos (ini tips agar olos tidak meledak-ledak saat digoreng) baru hidupkan kompor"
- "Goreng dengan api sedang sampai coklat kekuningan"
- "Sajikan dengan saos dan mayonaise"
categories:
- Resep
tags:
- olos
- tegal

katakunci: olos tegal 
nutrition: 158 calories
recipecuisine: Indonesian
preptime: "PT10M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Lunch

---


![Olos Tegal](https://img-global.cpcdn.com/recipes/2eaf3255a245cd51/751x532cq70/olos-tegal-foto-resep-utama.jpg)

Lagi mencari ide resep olos tegal yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal olos tegal yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari olos tegal, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan olos tegal enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Berikut ini ada beberapa cara mudah dan praktis untuk membuat olos tegal yang siap dikreasikan. Anda dapat membuat Olos Tegal menggunakan 14 jenis bahan dan 10 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk membuat Olos Tegal:

1. Siapkan 10 Sdm tepung terigu
1. Ambil 10 sdm tepung tapioka
1. Gunakan  Air panas
1. Gunakan  Isian
1. Siapkan 10 lembar kol (kubis) potong tipis2
1. Siapkan 1 buah wortel potong dadu kecil
1. Siapkan 2 helai daun bawang iris tipis
1. Siapkan  Bumbu yang dihakuskan:
1. Siapkan 2 siung Bawang putih
1. Ambil 3 siung bawang merah
1. Sediakan 10 buah cabe rawit (sesuai selera)
1. Siapkan  Garam
1. Siapkan  Penyedap rasa /kaldu bubuk
1. Ambil  Merica bubuk




##### Langkah-langkah meracik Olos Tegal:

1. Tumis bumbu yang sudah dihaluskan sampai harum
1. Masukkan irisan wortel, kol dan daun bawang, tumis sampai layu
1. Tambahkan garam dan penyedap rasa, aduk sebentar lalu sisihkan
1. Sementara itu tuang tepung terigu dan tepung tapioka ke dalam baskom, tambahkan garam, kaldu bubuk dan merica bubuk secukupnya
1. Tuang air panas yang sudah mendidih sedikit demi sedikit sambil diaduk dengan sendok sampai kalis, dan bisa dibentuk (jika masih lengket tambah dengan tepung terigu dan tapioka sampai adonan bisa dibentuk)
1. Isi adonan dengan tumisan sayur
1. Bentuk bulat-bulat
1. Siapkan wajan, tuang minyak lalu masukkan adonan olos (ini tips agar olos tidak meledak-ledak saat digoreng) baru hidupkan kompor
1. Goreng dengan api sedang sampai coklat kekuningan
1. Sajikan dengan saos dan mayonaise




Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Olos Tegal yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi inspirasi dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
