---
description: "WAJIB DICOBA! Ternyata Ini Cara Membuat Olos Teri Pedas Gampang Banget"
title: "WAJIB DICOBA! Ternyata Ini Cara Membuat Olos Teri Pedas Gampang Banget"
slug: 1582-masakan-sederhana-wajib-dicoba-ternyata-ini-cara-membuat-olos-teri-pedas-gampang-banget
date: 2020-05-31T09:43:23.480Z
image: https://img-global.cpcdn.com/recipes/cd4bdacb2347e44b/751x532cq70/olos-teri-pedas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/cd4bdacb2347e44b/751x532cq70/olos-teri-pedas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/cd4bdacb2347e44b/751x532cq70/olos-teri-pedas-foto-resep-utama.jpg
author: Nina Garrett
ratingvalue: 4.7
reviewcount: 4
recipeingredient:
- " Isian"
- "50 gr kol iris halus"
- "25 gr teri goreng"
- "1 buah daun bawang iris halus"
- "1 siung bwg putih cincang"
- " Garam"
- " Gula"
- " Bon cabe secukupnya bila suka pedas"
- " Cilok"
- "125 tepung terigu"
- "125 tepung tapioka"
- "190 ml air hangat"
- "1/2 sdm garam"
- "1/2 sdt lada bubuk"
- "3 siung bwg putih"
recipeinstructions:
- "Isian : tumis bawang putih hingga harum, masukkan kol, daun bawang, garam dan gula"
- "Apabila sdh layu, masukkan teri dan bon cabe. Koreksi rasa, angkat dan sisihkan"
- "Membuat cilok : campur semua bahan, tambahkan air sedikit2 sampai adonan bisa dibentuk."
- "Penyelesaian : ambil sedikit adonan cilok, pipihkan. Isi dg isian kol, lalu bulatkan. Olos bisa direbus atau digoreng. Apabila digoreng masukkan dl dlm minyak dingin kemudian panaskan perlahan supaya olos tidak meletus2."
categories:
- Resep
tags:
- olos
- teri
- pedas

katakunci: olos teri pedas 
nutrition: 275 calories
recipecuisine: Indonesian
preptime: "PT25M"
cooktime: "PT39M"
recipeyield: "4"
recipecategory: Lunch

---


![Olos Teri Pedas](https://img-global.cpcdn.com/recipes/cd4bdacb2347e44b/751x532cq70/olos-teri-pedas-foto-resep-utama.jpg)

Sedang mencari inspirasi resep olos teri pedas yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal olos teri pedas yang enak harusnya sih mempunyai aroma dan rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari olos teri pedas, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara membuat dan menyajikannya. Tidak usah pusing kalau mau menyiapkan olos teri pedas yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan olos teri pedas sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Olos Teri Pedas menggunakan 15 bahan dan 4 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat Olos Teri Pedas:

1. Siapkan  Isian
1. Siapkan 50 gr kol, iris halus
1. Siapkan 25 gr teri, goreng
1. Siapkan 1 buah daun bawang, iris halus
1. Sediakan 1 siung bwg putih, cincang
1. Gunakan  Garam
1. Gunakan  Gula
1. Siapkan  Bon cabe secukupnya bila suka pedas
1. Siapkan  Cilok
1. Siapkan 125 tepung terigu
1. Gunakan 125 tepung tapioka
1. Siapkan 190 ml air hangat
1. Siapkan 1/2 sdm garam
1. Sediakan 1/2 sdt lada bubuk
1. Ambil 3 siung bwg putih




##### Cara mengolah Olos Teri Pedas:

1. Isian : tumis bawang putih hingga harum, masukkan kol, daun bawang, garam dan gula
1. Apabila sdh layu, masukkan teri dan bon cabe. Koreksi rasa, angkat dan sisihkan
1. Membuat cilok : campur semua bahan, tambahkan air sedikit2 sampai adonan bisa dibentuk.
1. Penyelesaian : ambil sedikit adonan cilok, pipihkan. Isi dg isian kol, lalu bulatkan. Olos bisa direbus atau digoreng. Apabila digoreng masukkan dl dlm minyak dingin kemudian panaskan perlahan supaya olos tidak meletus2.




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Olos Teri Pedas yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
