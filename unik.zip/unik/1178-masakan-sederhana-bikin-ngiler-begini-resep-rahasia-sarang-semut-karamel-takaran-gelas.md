---
description: "BIKIN NGILER! Begini Resep Rahasia Sarang semut / karamel (takaran gelas) "
title: "BIKIN NGILER! Begini Resep Rahasia Sarang semut / karamel (takaran gelas) "
slug: 1178-masakan-sederhana-bikin-ngiler-begini-resep-rahasia-sarang-semut-karamel-takaran-gelas
date: 2020-04-10T05:23:46.855Z
image: https://img-global.cpcdn.com/recipes/f12c34a2a38ed285/751x532cq70/sarang-semut-karamel-takaran-gelas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f12c34a2a38ed285/751x532cq70/sarang-semut-karamel-takaran-gelas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f12c34a2a38ed285/751x532cq70/sarang-semut-karamel-takaran-gelas-foto-resep-utama.jpg
author: Augusta Jenkins
ratingvalue: 3.7
reviewcount: 15
recipeingredient:
- "4 butir telur"
- "2 gelas gula pasir gelas blimbing"
- "2 gelas air panas gelas blimbing"
- "6 sendok minyak goreng"
- "1 gelas tepung terigu gelas blimbing"
- "1 gelas tepung tapioka  sagu gelas blimbing"
- "1/2 sdm soda kue"
- "1/2 sdm baking powder"
- "1 saset vanili bubuk"
- " Mentega secukupnya untuk oles"
- "1 saset susu cair"
recipeinstructions:
- "Pertama cairkan gula pasir, dengan cara di panaskan di waja dengan api kecil (jangan di aduk biar larut sendiri) sehabis larut siram dengan air panas (dekit demi sedikit) lalu biarkan larut semua lalu dingingkan"
- "Campurkan tepung terigu, tepung tapioka, vanili, baking soda, baking powder jadi satu lalu saring (adonan kering)"
- "Kocok lepas terus dan susu kental manis sampi berbuih, lalu masukan adonan kering sedikit demi sedikit dan aduk rata"
- "Lalu masukan cairan gula sedkit demi sedikt lalu aduk rata sampai tercampur dan masukan juga minyak goreng dan aduk kembali"
- "Lalu taruh kedalam loyang yang sudah diolesi margarin lalu panggang dengan api kecil"
- "Lalu siap sajikan"
categories:
- Resep
tags:
- sarang
- semut
katakunci: sarang semut  
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT48M"
recipeyield: "2"
recipecategory: Dessert

---


![Sarang semut / karamel (takaran gelas)](https://img-global.cpcdn.com/recipes/f12c34a2a38ed285/751x532cq70/sarang-semut-karamel-takaran-gelas-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep sarang semut / karamel (takaran gelas) yang unik? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal sarang semut / karamel (takaran gelas) yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sarang semut / karamel (takaran gelas), mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan sarang semut / karamel (takaran gelas) yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.

Resepnya cuma pakai takaran sendok saja Resepnya cuma pakai takaran sendok saja lho. Lihat juga resep Bolu karamel sarang semut takaran gelas enak lainnya. Cara Sederhana Membuat Resep Bolu Karamel Seperti Rumah Sarang Semut.


Nah, kali ini kita coba, yuk, ciptakan sarang semut / karamel (takaran gelas) sendiri di rumah. Tetap dengan bahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Sarang semut / karamel (takaran gelas) menggunakan 11 jenis bahan dan 6 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Sarang semut / karamel (takaran gelas):

1. Siapkan 4 butir telur
1. Sediakan 2 gelas gula pasir (gelas blimbing)
1. Sediakan 2 gelas air panas (gelas blimbing)
1. Siapkan 6 sendok minyak goreng
1. Gunakan 1 gelas tepung terigu (gelas blimbing)
1. Sediakan 1 gelas tepung tapioka / sagu (gelas blimbing)
1. Sediakan 1/2 sdm soda kue
1. Siapkan 1/2 sdm baking powder
1. Sediakan 1 saset vanili bubuk
1. Gunakan  Mentega secukupnya (untuk oles)
1. Ambil 1 saset susu cair


Cara Bikin Bolu Caramel (Sarang Semut) Anti Gagal. Sajian kue bolu caramel sarang semut adalah hidangan yang enak dan lezat. Sajian kue ini akan bisa anda sajikan untuk beberapa acara seperti arisan dirumah, hajatan dan lain Bahan-Bahan yang Diperlukan Untuk Membuat Kue Bolu Karamel Sarang Semut yang Lembut, Enak dan Sederhana. Saya buat resep kue sarang semut karamel ini tidak terlalu banyak, takaranya anda bisa menyesuaikan kebutuhan. kesesuain takaran akan sanagt berpengaruh dengan hasilnya oleh karena itu melakukan improvisasi boleh sesudah percoban. 

##### Langkah-langkah mengolah Sarang semut / karamel (takaran gelas):

1. Pertama cairkan gula pasir, dengan cara di panaskan di waja dengan api kecil (jangan di aduk biar larut sendiri) sehabis larut siram dengan air panas (dekit demi sedikit) lalu biarkan larut semua lalu dingingkan
1. Campurkan tepung terigu, tepung tapioka, vanili, baking soda, baking powder jadi satu lalu saring (adonan kering)
1. Kocok lepas terus dan susu kental manis sampi berbuih, lalu masukan adonan kering sedikit demi sedikit dan aduk rata
1. Lalu masukan cairan gula sedkit demi sedikt lalu aduk rata sampai tercampur dan masukan juga minyak goreng dan aduk kembali
1. Lalu taruh kedalam loyang yang sudah diolesi margarin lalu panggang dengan api kecil
1. Lalu siap sajikan


Gambar Caramel Cake Kue Sarang Semut. Membuat karamel, langkah pertama adalah gosongkan gula di atas wajan teflon, gunakan api kecil saja. Pakailah wajan yang tebal supaya panasnya merata sehingga karamel yang dihasilkan tidak akan gosong. Bolu karamel atau sarang semut ini adalah salah satu kue khas Indonesia. Klo sebutan orang Betawi bolu sarang semut, karena bolunya berongg. 

Gimana nih? Mudah bukan? Itulah cara menyiapkan sarang semut / karamel (takaran gelas) yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
