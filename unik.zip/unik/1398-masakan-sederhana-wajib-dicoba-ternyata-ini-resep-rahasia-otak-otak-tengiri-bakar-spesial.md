---
description: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Otak Otak Tengiri Bakar Spesial"
title: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Otak Otak Tengiri Bakar Spesial"
slug: 1398-masakan-sederhana-wajib-dicoba-ternyata-ini-resep-rahasia-otak-otak-tengiri-bakar-spesial
date: 2020-06-11T01:59:40.045Z
image: https://img-global.cpcdn.com/recipes/a30982ad7bf8b034/751x532cq70/otak-otak-tengiri-bakar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a30982ad7bf8b034/751x532cq70/otak-otak-tengiri-bakar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a30982ad7bf8b034/751x532cq70/otak-otak-tengiri-bakar-foto-resep-utama.jpg
author: Pauline George
ratingvalue: 3.6
reviewcount: 11
recipeingredient:
- "500 gr daging ikan tengiri giling"
- "300 ml santan kental"
- "80 gr sagu tani"
- "1 butir telur putihnya saja"
- "1/2 sdt merica bubuk"
- "1 sdt totole kaldu jamur"
- "1/2 sdt gula pasir"
- "1 sdm garam"
- "3 siung bawang putih haluskan"
- "6 siung bawang merah potong tipis"
- "Secukupnya daun bawang potong kecil"
- "Secukupnya daun pisang"
recipeinstructions:
- "Siapkan semua bahan yg akan dicampur dengan adonan ikan. Giling daging ikan tengiri tanpa air sampai halus. Tambahkan santan kental sebagian(sedikit demi sedikit) lalu giling kembali."
- "Campur sisa santan dengan gula, garam, lada dan kaldu jamur bubuk larutkan hingga rata, setelah rata, masukkan kegilingan ikan lalu gilih kembali sampai adonan ikan menjadi sintal lebih padat. Masukkan lagi putih telur, giling smpai sintal padat kembali"
- "Masukkan potongan bawang merah dan daun bawang. Aduk sebentar saja."
- "Lalu keluarkan adonan pada wadah. Tambahkan sagu tani sedikit demi sedikit, uleni hingga kalis. Jika sdh kalis, banting2 adonan beberapa saat(Proses ini untuk menghasilkan otak2 yg kenyal renyah dan kesat)"
- "Masukkan adonan dalam papingbag dan potong ujungnya. Dilain sisi kita bs mengukus sebentar saja daun pisang agar lentur dan tdk mudah robek ketika digulung"
- "Cetak adonan diatas daun pisang, gulung dan pipihkan. Lalu ditutup dengan lidi atau bs jg dng stepless"
- "Panggang diatas api kecil, bolak balik semua bagian agar matang merata. Panggang hingga kesat, daun layu dan mengeluarkan aroma khas ikan tengiri. Bs diamati juga dari bentuk yg berubah menjadi sintal kenyal juga disentuh, itu tandanya otak otak sudah matang. Siap dihidangkan dengan cocolan saus kacang 😉"
categories:
- Resep
tags:
- otak
- otak
- tengiri

katakunci: otak otak tengiri 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Lunch

---


![Otak Otak Tengiri Bakar](https://img-global.cpcdn.com/recipes/a30982ad7bf8b034/751x532cq70/otak-otak-tengiri-bakar-foto-resep-utama.jpg)

Sedang mencari ide resep otak otak tengiri bakar yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal otak otak tengiri bakar yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari otak otak tengiri bakar, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika ingin menyiapkan otak otak tengiri bakar enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat otak otak tengiri bakar sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat membuat Otak Otak Tengiri Bakar memakai 12 bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam mengolah Otak Otak Tengiri Bakar:

1. Ambil 500 gr daging ikan tengiri giling
1. Sediakan 300 ml santan kental
1. Gunakan 80 gr sagu tani
1. Ambil 1 butir telur putihnya saja
1. Ambil 1/2 sdt merica bubuk
1. Gunakan 1 sdt totole kaldu jamur
1. Ambil 1/2 sdt gula pasir
1. Gunakan 1 sdm garam
1. Gunakan 3 siung bawang putih haluskan
1. Sediakan 6 siung bawang merah potong tipis
1. Ambil Secukupnya daun bawang potong kecil
1. Ambil Secukupnya daun pisang




##### Langkah-langkah mengolah Otak Otak Tengiri Bakar:

1. Siapkan semua bahan yg akan dicampur dengan adonan ikan. Giling daging ikan tengiri tanpa air sampai halus. Tambahkan santan kental sebagian(sedikit demi sedikit) lalu giling kembali.
1. Campur sisa santan dengan gula, garam, lada dan kaldu jamur bubuk larutkan hingga rata, setelah rata, masukkan kegilingan ikan lalu gilih kembali sampai adonan ikan menjadi sintal lebih padat. Masukkan lagi putih telur, giling smpai sintal padat kembali
1. Masukkan potongan bawang merah dan daun bawang. Aduk sebentar saja.
1. Lalu keluarkan adonan pada wadah. Tambahkan sagu tani sedikit demi sedikit, uleni hingga kalis. Jika sdh kalis, banting2 adonan beberapa saat(Proses ini untuk menghasilkan otak2 yg kenyal renyah dan kesat)
1. Masukkan adonan dalam papingbag dan potong ujungnya. Dilain sisi kita bs mengukus sebentar saja daun pisang agar lentur dan tdk mudah robek ketika digulung
1. Cetak adonan diatas daun pisang, gulung dan pipihkan. Lalu ditutup dengan lidi atau bs jg dng stepless
1. Panggang diatas api kecil, bolak balik semua bagian agar matang merata. Panggang hingga kesat, daun layu dan mengeluarkan aroma khas ikan tengiri. Bs diamati juga dari bentuk yg berubah menjadi sintal kenyal juga disentuh, itu tandanya otak otak sudah matang. Siap dihidangkan dengan cocolan saus kacang 😉




Terima kasih telah membaca resep yang kami tampilkan di sini. Harapan kami, olahan Otak Otak Tengiri Bakar yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
