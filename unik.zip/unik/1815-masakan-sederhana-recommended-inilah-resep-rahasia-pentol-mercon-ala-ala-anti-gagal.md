---
description: "RECOMMENDED! Inilah Resep Rahasia Pentol Mercon ala ala Anti Gagal"
title: "RECOMMENDED! Inilah Resep Rahasia Pentol Mercon ala ala Anti Gagal"
slug: 1815-masakan-sederhana-recommended-inilah-resep-rahasia-pentol-mercon-ala-ala-anti-gagal
date: 2020-08-18T21:04:56.545Z
image: https://img-global.cpcdn.com/recipes/b35642c6507a7b30/751x532cq70/pentol-mercon-ala-ala-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b35642c6507a7b30/751x532cq70/pentol-mercon-ala-ala-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/b35642c6507a7b30/751x532cq70/pentol-mercon-ala-ala-foto-resep-utama.jpg
author: Brett Burton
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "1/2 kg Pentol Sapi iris tengah"
- "9 bji cabe rawit uleg kasar"
- "3 siung Bawang Putih"
- "1 Siung Bawang Merah"
- "Secukupnya Saos Tiram"
- "Secukupnya Kecap Manis"
- "Secukupnya Saos Tomat  Saus Sambal"
- "Secukupnya Seledri"
- "1/2 siung bawang Bombay iris Tipis"
- " Kaldu Jamur Lada Bubuk Garam Gula"
- "Secukupnya air"
recipeinstructions:
- "Tumis Bawang Bombay, Bawang putih n Bawang merah sampai Harum"
- "Masukkan uleg an cabe rawit, daun seledri"
- "Setelah layu masukkan pentol, tambahkan penyedap juga sedikit air"
- "Setelah air berkurang, koreksi rasa. Angkat dan siap di santap bersama nasi hangat."
categories:
- Resep
tags:
- pentol
- mercon
- ala

katakunci: pentol mercon ala 
nutrition: 112 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT48M"
recipeyield: "3"
recipecategory: Dinner

---


![Pentol Mercon ala ala](https://img-global.cpcdn.com/recipes/b35642c6507a7b30/751x532cq70/pentol-mercon-ala-ala-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep pentol mercon ala ala yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal pentol mercon ala ala yang enak selayaknya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari pentol mercon ala ala, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan pentol mercon ala ala enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.

Yeeeaayyy kali ini kita masak PENTOL MERCON bareng AYU maaf ya kita gak tahu takarannya jadi selalu bilang secukupnya aja terserah kalian deh sesuai. Siapa sih yang kenal, sudah menjadi makanan favorite kalian kan?? Nahhh ngakuu aja iya kannn eaaaa Oh iyaa kalian mau request makan apa.


Nah, kali ini kita coba, yuk, buat pentol mercon ala ala sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Pentol Mercon ala ala menggunakan 11 jenis bahan dan 4 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk mengolah Pentol Mercon ala ala:

1. Siapkan 1/2 kg Pentol Sapi iris tengah
1. Siapkan 9 bji cabe rawit, uleg kasar
1. Gunakan 3 siung Bawang Putih
1. Siapkan 1 Siung Bawang Merah
1. Gunakan Secukupnya Saos Tiram
1. Gunakan Secukupnya Kecap Manis
1. Sediakan Secukupnya Saos Tomat / Saus Sambal
1. Siapkan Secukupnya Seledri
1. Gunakan 1/2 siung bawang Bombay iris Tipis
1. Siapkan  Kaldu Jamur, Lada Bubuk, Garam, Gula
1. Ambil Secukupnya air


The Legend of Pentol Mercon menawarkan menu pentol dgn aneka saus seperti saus tomat, blackpaper, barbeque, saus kacang & sambal super pedas. Haii hari ini aku masak pentol bakso mercon Aduuuh ini pedeeessss banget banget banget !! Tp ketagihan sih hehe Disini aku. Ide jualan musim panas jadi musim ujan pun jadi pentol ayam mercon Di ide jualan kali ini saya akan membagikan resep jajanan. 

##### Langkah-langkah meracik Pentol Mercon ala ala:

1. Tumis Bawang Bombay, Bawang putih n Bawang merah sampai Harum
1. Masukkan uleg an cabe rawit, daun seledri
1. Setelah layu masukkan pentol, tambahkan penyedap juga sedikit air
1. Setelah air berkurang, koreksi rasa. Angkat dan siap di santap bersama nasi hangat.


TRIBUNNEWS,COM - Berikut ini resep dan cara membuat bakso cilok atau pentol mercon yang mudah dan anti gagal. Masakan ini bisa dilakukan di rumah dengan bahan dan alat sederhana. Uploaded by. inahoda. [caption caption=\"Pentol Mercon \"Abang Ijo\" Super Pedas\"]. Restoran dengan menu tradisional enak selalu cocok buat keluarga. Ada pula camilan pentol mercon yang pedasnya nampol. 

Gimana nih? Mudah bukan? Itulah cara menyiapkan pentol mercon ala ala yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
