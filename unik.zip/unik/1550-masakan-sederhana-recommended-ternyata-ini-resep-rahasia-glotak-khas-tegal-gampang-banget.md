---
description: "RECOMMENDED! Ternyata Ini Resep Rahasia Glotak Khas Tegal Gampang Banget"
title: "RECOMMENDED! Ternyata Ini Resep Rahasia Glotak Khas Tegal Gampang Banget"
slug: 1550-masakan-sederhana-recommended-ternyata-ini-resep-rahasia-glotak-khas-tegal-gampang-banget
date: 2020-06-28T05:08:48.456Z
image: https://img-global.cpcdn.com/recipes/20efd027a886ab81/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/20efd027a886ab81/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/20efd027a886ab81/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
author: Curtis Gomez
ratingvalue: 4.9
reviewcount: 5
recipeingredient:
- "300 gr gembus"
- "350 gr tulang sapi"
- "15 buah ceker ayam"
- "1 btg sereh digeprek"
- "2 lbr daun salam"
- "1 ruas lengkuas digeprek"
- "8 buah cabe ijo iris panjang"
- "10 buah cabe rawit merah utuh"
- "1 sdt kaldu bubuk"
- "secukupnya Garam"
- "750 ml air"
- "2 sdm minyak goreng"
- " Bumbu halus"
- "8 siung bawang merah"
- "5 siung bawang putih"
- "3 buah kemiri"
- "1 sdt ketumbar"
- "1 ruas kunyit bisa juga 12 sdk kunyit bubuk"
- "1 ruas jahe"
- "7 buah cabe merah sesuai selera"
recipeinstructions:
- "Siapkan bahan dan bumbu2"
- "Rebus tulang sapi sampai empuk, sayap juga direbus sampai empuk"
- "Kukus gembus lalu dihaluskan"
- "Haluskan bumbu-bumbu bawang merah, bawang putih, kemiri, kunyit, ketumbar dan jahe. Haluskan juga cabe merah."
- "Panaskan minyak goreng lalu masukan bumbu halus tumis sampai harum, sereh, daun salam dan lengkuas, setelah wangi masukan cabe yang sdh dihaluskan. Tambahkan lada bubuk."
- "Setelah bumbu harum masukan gembus aduk terus sampai bumbu tercampur. Lalu masukan air aduk masak sampai mendidih, lalu masukan tulang sapi dan ceker ayamnya, aduk terus biarkan sampai air berkurang. Terakhir masukan cabe ijo dan cabe rawit utuh. Masak sampai asat tapi masih nyemek ya bun."
- "Tes rasa dan angkat."
categories:
- Resep
tags:
- glotak
- khas
- tegal

katakunci: glotak khas tegal 
nutrition: 183 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT30M"
recipeyield: "4"
recipecategory: Lunch

---


![Glotak Khas Tegal](https://img-global.cpcdn.com/recipes/20efd027a886ab81/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg)

Lagi mencari inspirasi resep glotak khas tegal yang unik? Cara menyiapkannya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal glotak khas tegal yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Glotak adalah makanan tradisional dari Tegal. Banyak sih yang gak tau glotak. Glotak ini sendiri terbuat dari degan atau bahan dasar pembuat gembus atau lebih tenar meng-Indonesia dengan sebutan oncom.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari glotak khas tegal, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan glotak khas tegal enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah glotak khas tegal yang siap dikreasikan. Anda dapat membuat Glotak Khas Tegal menggunakan 20 bahan dan 7 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam meracik Glotak Khas Tegal:

1. Gunakan 300 gr gembus
1. Siapkan 350 gr tulang sapi
1. Sediakan 15 buah ceker ayam
1. Gunakan 1 btg sereh digeprek
1. Sediakan 2 lbr daun salam
1. Ambil 1 ruas lengkuas digeprek
1. Gunakan 8 buah cabe ijo iris panjang
1. Siapkan 10 buah cabe rawit merah utuh
1. Sediakan 1 sdt kaldu bubuk
1. Sediakan secukupnya Garam
1. Ambil 750 ml air
1. Sediakan 2 sdm minyak goreng
1. Gunakan  Bumbu halus
1. Gunakan 8 siung bawang merah
1. Sediakan 5 siung bawang putih
1. Siapkan 3 buah kemiri
1. Ambil 1 sdt ketumbar
1. Siapkan 1 ruas kunyit bisa juga 1/2 sdk kunyit bubuk
1. Sediakan 1 ruas jahe
1. Ambil 7 buah cabe merah/ sesuai selera


Glotak adalah makanan tradisional dari Tegal. Banyak sih yang gak tau glotak. Glotak ini sendiri terbuat dari degan atau bahan dasar pembuat gembus atau lebih tenar meng-Indonesia dengan sebutan oncom. glotak khas tegal Kemaren ini aku masak menu baru dan unik, menu eksotis khas Tegal, namanya Glotak. Glotak itu terbuat dari tempe gembus ( menjes) yang di masak pedas dengan balungan, bisa balungan sapi atau ayam, kalau aku pakai balungan ayam. 

##### Cara meracik Glotak Khas Tegal:

1. Siapkan bahan dan bumbu2
1. Rebus tulang sapi sampai empuk, sayap juga direbus sampai empuk
1. Kukus gembus lalu dihaluskan
1. Haluskan bumbu-bumbu bawang merah, bawang putih, kemiri, kunyit, ketumbar dan jahe. Haluskan juga cabe merah.
1. Panaskan minyak goreng lalu masukan bumbu halus tumis sampai harum, sereh, daun salam dan lengkuas, setelah wangi masukan cabe yang sdh dihaluskan. Tambahkan lada bubuk.
1. Setelah bumbu harum masukan gembus aduk terus sampai bumbu tercampur. Lalu masukan air aduk masak sampai mendidih, lalu masukan tulang sapi dan ceker ayamnya, aduk terus biarkan sampai air berkurang. Terakhir masukan cabe ijo dan cabe rawit utuh. Masak sampai asat tapi masih nyemek ya bun.
1. Tes rasa dan angkat.


Glotak pada umumnya terbuat dari gembus yang dimasak dengan berbagai bumbu. Glotak itu memiliki rasa yang lezat, meski sekarang banyak yang tidak tahu mengenai kuliner khas Tegal yang satu ini. Bahan dasar pembuatannya Glotak itu ialah gembus, yakni bahan semacam oncom yang dimasak dengan berbagai macam bumbu. Untuk menambah kelezatannya, maka gembus itu diberi kaldu dari rebusan tulang sapi atau ayam. Glotak Khas Tegal - via instagram: @menu_andalangue. 

Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Glotak Khas Tegal yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
