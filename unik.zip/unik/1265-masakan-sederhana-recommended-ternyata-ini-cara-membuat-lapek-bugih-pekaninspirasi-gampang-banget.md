---
description: "RECOMMENDED! Ternyata Ini Cara Membuat Lapek Bugih #PekanInspirasi Gampang Banget"
title: "RECOMMENDED! Ternyata Ini Cara Membuat Lapek Bugih #PekanInspirasi Gampang Banget"
slug: 1265-masakan-sederhana-recommended-ternyata-ini-cara-membuat-lapek-bugih-pekaninspirasi-gampang-banget
date: 2020-04-06T22:10:07.128Z
image: https://img-global.cpcdn.com/recipes/89577a90a5decc0e/751x532cq70/lapek-bugih-pekaninspirasi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/89577a90a5decc0e/751x532cq70/lapek-bugih-pekaninspirasi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/89577a90a5decc0e/751x532cq70/lapek-bugih-pekaninspirasi-foto-resep-utama.jpg
author: Russell Sullivan
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "500 gr tepung Ketan"
- "250 ml santan"
- "1 buah kelapa parut"
- "50 gr gula pasir"
- "200 gr gula aren"
- "100 ml air"
- " Daun pisang muda"
- " Daun Pandan"
- " Garam"
- " Vanili"
recipeinstructions:
- "Cara memasak isian. Cairkan gula aren dan gula pasir dengan sedikit air, masukan daun pandan, vanili, dan garam. Kemudian tambahkan kelapa parut. Masak hingga gula meresap di kelapa."
- "Setalah isian kelapa masak. Aduk adonan tepung ketan dengan santan. Tambahkan garam dan koreksi rasa."
- "Setelah adonan cukup kalis. Adonan siap di bentuk. Ambil adonan sikitar 30gr. Pipihkan adonan kemudian isi dengan kelapa yang sudah di masak sesuai selera, lalu tutup adonan."
- "Ambil daun pisang pembukus lapek Bugih. Sebelumnya daun bisa dipanaskan selayang agar daun mudah di bentuk dan tidak sobek."
- "Daun pisang juga di olesi dengan minyak makan, agar lapek bugih tidak lengket di daun saat hendak di makan."
- "Kemudian, siap kan dandang untuk mengukukus, tunggu hingga 30 menit."
- "Lapek bugih siap di santap."
categories:
- Resep
tags:
- lapek
- bugih
- pekaninspirasi

katakunci: lapek bugih pekaninspirasi 
nutrition: 170 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dinner

---


![Lapek Bugih #PekanInspirasi](https://img-global.cpcdn.com/recipes/89577a90a5decc0e/751x532cq70/lapek-bugih-pekaninspirasi-foto-resep-utama.jpg)

Sedang mencari inspirasi resep lapek bugih #pekaninspirasi yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal lapek bugih #pekaninspirasi yang enak harusnya sih memiliki aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari lapek bugih #pekaninspirasi, mulai dari jenis bahan, kedua pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan lapek bugih #pekaninspirasi yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah lapek bugih #pekaninspirasi yang siap dikreasikan. Anda dapat membuat Lapek Bugih #PekanInspirasi menggunakan 10 bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam membuat Lapek Bugih #PekanInspirasi:

1. Sediakan 500 gr tepung Ketan
1. Sediakan 250 ml santan
1. Siapkan 1 buah kelapa parut
1. Ambil 50 gr gula pasir
1. Sediakan 200 gr gula aren
1. Siapkan 100 ml air
1. Sediakan  Daun pisang muda
1. Siapkan  Daun Pandan
1. Siapkan  Garam
1. Siapkan  Vanili




##### Cara mengolah Lapek Bugih #PekanInspirasi:

1. Cara memasak isian. Cairkan gula aren dan gula pasir dengan sedikit air, masukan daun pandan, vanili, dan garam. Kemudian tambahkan kelapa parut. Masak hingga gula meresap di kelapa.
1. Setalah isian kelapa masak. Aduk adonan tepung ketan dengan santan. Tambahkan garam dan koreksi rasa.
1. Setelah adonan cukup kalis. Adonan siap di bentuk. Ambil adonan sikitar 30gr. Pipihkan adonan kemudian isi dengan kelapa yang sudah di masak sesuai selera, lalu tutup adonan.
1. Ambil daun pisang pembukus lapek Bugih. Sebelumnya daun bisa dipanaskan selayang agar daun mudah di bentuk dan tidak sobek.
1. Daun pisang juga di olesi dengan minyak makan, agar lapek bugih tidak lengket di daun saat hendak di makan.
1. Kemudian, siap kan dandang untuk mengukukus, tunggu hingga 30 menit.
1. Lapek bugih siap di santap.




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Lapek Bugih #PekanInspirasi yang mudah di atas dapat membantu Anda menyiapkan makanan yang sedap untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
