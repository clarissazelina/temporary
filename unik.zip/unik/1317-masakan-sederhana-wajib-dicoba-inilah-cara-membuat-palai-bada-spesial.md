---
description: "WAJIB DICOBA! Inilah Cara Membuat Palai Bada Spesial"
title: "WAJIB DICOBA! Inilah Cara Membuat Palai Bada Spesial"
slug: 1317-masakan-sederhana-wajib-dicoba-inilah-cara-membuat-palai-bada-spesial
date: 2020-04-25T06:16:41.170Z
image: https://img-global.cpcdn.com/recipes/462be620f002691d/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/462be620f002691d/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/462be620f002691d/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Rosa Snyder
ratingvalue: 3.7
reviewcount: 5
recipeingredient:
- " Bada"
- " Daun salam"
- " Daun rukuruku"
- " Sereh"
- " Garam"
- " Penyedap rasa opsional"
- " minyak goreng"
- " Daun pisang"
- " Bumbu halus "
- "10 buah bawang merah"
- "5 siung bawang putih"
- " Jahe kira2 1 cm"
- " kunyit kira2 2 cm"
- "10 buah cabe jika suka pedes bisa ditambah"
recipeinstructions:
- "Tumis bumbu halus."
- "Setelah masak matikan kompor, masukkan sereh, ruku2, sereh, garam, dan penyedap rasa. Koreksi rasa."
- "Masukkan bada yang sudah di cuci bersih. Aduk pelan2 sampai bumbu rata."
- "Bungkus dengan daun pisang dan sematkan dengan lidi/tusuk gigi"
- "Kukus kira2 10 menit"
- "Bakar pada teflon sebentar"
- "Palai bada siap dinikmati bersama nasi hangat....hmm nyammi"
categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 163 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Dessert

---


![Palai Bada](https://img-global.cpcdn.com/recipes/462be620f002691d/751x532cq70/palai-bada-foto-resep-utama.jpg)

Lagi mencari inspirasi resep palai bada yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal palai bada yang enak harusnya sih mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari palai bada, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan palai bada enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan spesial.




Nah, kali ini kita coba, yuk, ciptakan palai bada sendiri di rumah. Tetap berbahan sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Palai Bada menggunakan 14 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Palai Bada:

1. Siapkan  Bada
1. Sediakan  Daun salam
1. Ambil  Daun ruku-ruku
1. Sediakan  Sereh
1. Gunakan  Garam
1. Siapkan  Penyedap rasa (opsional)
1. Gunakan  minyak goreng
1. Siapkan  Daun pisang
1. Siapkan  Bumbu halus :
1. Gunakan 10 buah bawang merah
1. Sediakan 5 siung bawang putih
1. Siapkan  Jahe (kira2 1 cm)
1. Gunakan  kunyit (kira2 2 cm)
1. Gunakan 10 buah cabe (jika suka pedes bisa ditambah)




##### Langkah-langkah membuat Palai Bada:

1. Tumis bumbu halus.
1. Setelah masak matikan kompor, masukkan sereh, ruku2, sereh, garam, dan penyedap rasa. Koreksi rasa.
1. Masukkan bada yang sudah di cuci bersih. Aduk pelan2 sampai bumbu rata.
1. Bungkus dengan daun pisang dan sematkan dengan lidi/tusuk gigi
1. Kukus kira2 10 menit
1. Bakar pada teflon sebentar
1. Palai bada siap dinikmati bersama nasi hangat....hmm nyammi




Bagaimana? Mudah bukan? Itulah cara menyiapkan palai bada yang bisa Anda praktikkan di rumah. Selamat mencoba!
