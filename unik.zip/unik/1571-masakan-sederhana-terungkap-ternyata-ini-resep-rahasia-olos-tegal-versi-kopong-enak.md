---
description: "TERUNGKAP! Ternyata Ini Resep Rahasia Olos Tegal versi Kopong Enak"
title: "TERUNGKAP! Ternyata Ini Resep Rahasia Olos Tegal versi Kopong Enak"
slug: 1571-masakan-sederhana-terungkap-ternyata-ini-resep-rahasia-olos-tegal-versi-kopong-enak
date: 2020-06-01T02:30:23.465Z
image: https://img-global.cpcdn.com/recipes/ff4c96f72abfadff/751x532cq70/olos-tegal-versi-kopong-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ff4c96f72abfadff/751x532cq70/olos-tegal-versi-kopong-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ff4c96f72abfadff/751x532cq70/olos-tegal-versi-kopong-foto-resep-utama.jpg
author: Robert Soto
ratingvalue: 4.8
reviewcount: 3
recipeingredient:
- " Bahan Tepung masak"
- "5 sdm tepung kanji"
- "220 ml air"
- " Garamkaldu bubu sesuai selera Saya Masako Ayam"
- " Bahan kering tepung"
- "250 gr Tepung kanji"
- " Bahan Isian"
- " Kol iris tipis sedikit banyaknya sesuai selera"
- "2 buah sosis apa aja saya so nice boleh skip gnti ayam lbh enak"
- "10 buah cabai setan iris"
- "3 buah cabai merah keriting haluskan"
- "3 siung bawang merah haluskan"
- "2 siung bawang putih haluskan"
- " Bubuk cabe untuk taburan boleh skip"
- " Minyak goreng untuk menggoreng"
recipeinstructions:
- "Masukan tepung kanji 5sdm,garam/kaldu bubuk dengan air ke panci/teplon anti lengket didihkan sambil diaduk"
- "Pindahkan tepung basah/masak ke wadah berbeda aduk dengan tepung kanji 200gr tadi aduk hingga tercampur.. jika kurang air boleh tambahkan"
- "Selesai mengaduk adonan tadi kita bikin isiannya, tumis cabai, bawang merah dan bawang putih yang sudah dihaluskan sampai wangi"
- "Masukan sosis yang sudah f potong kotak kecil, kol yang sudah di iris, dan cabai iris ke dalam tumisan bumbu koreksi rasa sesuai selera. Selesai"
- "Bulatkan adonan kanji yang tadi (kira-kira secomot) isi dengan tumisan kol yang tadi bulat2 lumuri dengan kanji kering agar tidak menempel. Lakukan sampai habis"
- "Goreng dalam api yang belum nyala, nyalakan api kecil banget ya bund diam kan sampai olos mengapung.. setelah mengapung boleh ganti api sedang.. goreng sampe matang jangan lupa di bolak balik"
- "Sajikan hangat dan taburi dengan bubuk cabe, Seperti cireng isi rasanya🔥🤤"
categories:
- Resep
tags:
- olos
- tegal
- versi

katakunci: olos tegal versi 
nutrition: 200 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT47M"
recipeyield: "1"
recipecategory: Dinner

---


![Olos Tegal versi Kopong](https://img-global.cpcdn.com/recipes/ff4c96f72abfadff/751x532cq70/olos-tegal-versi-kopong-foto-resep-utama.jpg)

Anda sedang mencari ide resep olos tegal versi kopong yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal olos tegal versi kopong yang enak seharusnya punya aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari olos tegal versi kopong, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menyajikannya. Tidak usah pusing kalau ingin menyiapkan olos tegal versi kopong yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.

Alhamdulilah Ini aku bikin OLOS, cemilan khas Tegal, Peka. Maaf ya kemarin libur upload video karena sakit, tapi sekarang udah enakan nih. Alhamdulilah Ini aku bikin OLOS, cemilan khas Tegal, Pekalongan, Pemalang sekitarnya yang biasa dijual dipinggir jalan, cuma ini aku bikin yg versi aku.


Nah, kali ini kita coba, yuk, variasikan olos tegal versi kopong sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda bisa menyiapkan Olos Tegal versi Kopong memakai 15 bahan dan 7 langkah pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam meracik Olos Tegal versi Kopong:

1. Sediakan  Bahan Tepung masak:
1. Sediakan 5 sdm tepung kanji
1. Gunakan 220 ml air
1. Sediakan  Garam/kaldu bubu sesuai selera (Saya Masako Ayam)
1. Sediakan  Bahan kering tepung:
1. Gunakan 250 gr Tepung kanji
1. Gunakan  Bahan Isian:
1. Gunakan  Kol iris tipis sedikit banyaknya sesuai selera
1. Siapkan 2 buah sosis apa aja (saya so nice) boleh skip gnti ayam lbh enak
1. Sediakan 10 buah cabai setan (iris)
1. Ambil 3 buah cabai merah keriting (haluskan)
1. Sediakan 3 siung bawang merah (haluskan)
1. Ambil 2 siung bawang putih (haluskan
1. Ambil  Bubuk cabe (untuk taburan boleh skip)
1. Siapkan  Minyak goreng untuk menggoreng


Olos adalah camilan berbentuk bulat dan di dalamnya terdapat. Beberapa waktu yang lalu ngobrol sama mba Emma dan mba Dewi yang asli Tegal.tentang olos ini. Olos ini salah satu jajanan Tegal yang lagi booming.selain tahu aci. Hemm jadi penasaran dech pengen buat juga. 

##### Langkah-langkah menyiapkan Olos Tegal versi Kopong:

1. Masukan tepung kanji 5sdm,garam/kaldu bubuk dengan air ke panci/teplon anti lengket didihkan sambil diaduk
1. Pindahkan tepung basah/masak ke wadah berbeda aduk dengan tepung kanji 200gr tadi aduk hingga tercampur.. jika kurang air boleh tambahkan
1. Selesai mengaduk adonan tadi kita bikin isiannya, tumis cabai, bawang merah dan bawang putih yang sudah dihaluskan sampai wangi
1. Masukan sosis yang sudah f potong kotak kecil, kol yang sudah di iris, dan cabai iris ke dalam tumisan bumbu koreksi rasa sesuai selera. Selesai
1. Bulatkan adonan kanji yang tadi (kira-kira secomot) isi dengan tumisan kol yang tadi bulat2 lumuri dengan kanji kering agar tidak menempel. Lakukan sampai habis
1. Goreng dalam api yang belum nyala, nyalakan api kecil banget ya bund diam kan sampai olos mengapung.. setelah mengapung boleh ganti api sedang.. goreng sampe matang jangan lupa di bolak balik
1. Sajikan hangat dan taburi dengan bubuk cabe, Seperti cireng isi rasanya🔥🤤


Tegal Laka-laka - Tegal Keminclong Moncer Kotane. Olos, merupakan jajanan khas yang berasal dari Tegal, Jawa Tengah. Olos dapat digoreng hingga garing ataupun tidak tergantung selera kita. Kita hanya memerlukan tepung dan beberapa bumbu dapur seperti garam, ketumbar, lada, dan isiannya seperti sayuran, cabai, sosis, atau ayam. Day after day, the Olos Laboratory studies nature and selects the most effective, pure and genuine elements for its active ingredients. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Olos Tegal versi Kopong yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi ide untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
