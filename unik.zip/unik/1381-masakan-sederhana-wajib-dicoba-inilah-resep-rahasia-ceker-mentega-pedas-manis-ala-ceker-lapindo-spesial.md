---
description: "WAJIB DICOBA! Inilah Resep Rahasia Ceker Mentega Pedas Manis ala Ceker Lapindo Spesial"
title: "WAJIB DICOBA! Inilah Resep Rahasia Ceker Mentega Pedas Manis ala Ceker Lapindo Spesial"
slug: 1381-masakan-sederhana-wajib-dicoba-inilah-resep-rahasia-ceker-mentega-pedas-manis-ala-ceker-lapindo-spesial
date: 2020-05-21T14:12:04.694Z
image: https://img-global.cpcdn.com/recipes/f2950c2a396a5929/751x532cq70/ceker-mentega-pedas-manis-ala-ceker-lapindo-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/f2950c2a396a5929/751x532cq70/ceker-mentega-pedas-manis-ala-ceker-lapindo-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/f2950c2a396a5929/751x532cq70/ceker-mentega-pedas-manis-ala-ceker-lapindo-foto-resep-utama.jpg
author: Clifford Graves
ratingvalue: 3.5
reviewcount: 12
recipeingredient:
- "1 kg ceker ayam"
- " Bumbu "
- "6 siung bawang putih cincang"
- "2 cm jahe cincang"
- "100 gram mentega"
- "100 gram Gula pasir"
- "1 sendok makan Garam sesuai selera"
- "1 bungkus Masako"
- "5 sdm kecap manis bisa ditambah jika ingin lebih hitam"
- "100 gram cabai rawit  sesuai selera dipotongpotong"
recipeinstructions:
- "Cuci bersih ceker ayam dan potong kukunya"
- "Presto ceker ayam 20 menit. Kemudian cuci / bilas untuk menghilangkan kotoran sisa presto dan tiriskan."
- "Masak air 2L sampai mendidih lalu masukkan ceker."
- "Panaskan wajan dan lelehkan mentega"
- "Masukkan cincangan jahe dan bawang putih."
- "Tumis hingga harum. Kemudian masukkan ke dalam panci yang berisi ceker."
- "Masukkan gula, garam, masako, kecap. Tes rasa"
- "Masak dan tutup panci selama 30 menit. Kemudian masukkan irisan cabai. Masak dan tutup lagi selama 30 menit."
- "Matikan kompor dan koreksi rasa."
- "Jika warna belum terlalu hitam tidak masalah karena Semakin lama nanti bumbu semakin masuk."
- "Pedas dan manis sesuai selera, kalau saya suka yang pedas manis. Jika mau lebih hitam tambahkan lebih banyak kecap."
categories:
- Resep
tags:
- ceker
- mentega
- pedas

katakunci: ceker mentega pedas 
nutrition: 283 calories
recipecuisine: Indonesian
preptime: "PT28M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Ceker Mentega Pedas Manis ala Ceker Lapindo](https://img-global.cpcdn.com/recipes/f2950c2a396a5929/751x532cq70/ceker-mentega-pedas-manis-ala-ceker-lapindo-foto-resep-utama.jpg)

Lagi mencari ide resep ceker mentega pedas manis ala ceker lapindo yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal ceker mentega pedas manis ala ceker lapindo yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari ceker mentega pedas manis ala ceker lapindo, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan ceker mentega pedas manis ala ceker lapindo yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, ciptakan ceker mentega pedas manis ala ceker lapindo sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Ceker Mentega Pedas Manis ala Ceker Lapindo memakai 10 bahan dan 11 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk meracik Ceker Mentega Pedas Manis ala Ceker Lapindo:

1. Ambil 1 kg ceker ayam
1. Gunakan  Bumbu :
1. Siapkan 6 siung bawang putih (cincang)
1. Siapkan 2 cm jahe (cincang)
1. Ambil 100 gram mentega
1. Siapkan 100 gram Gula pasir
1. Siapkan 1 sendok makan Garam (sesuai selera)
1. Gunakan 1 bungkus Masako
1. Gunakan 5 sdm kecap manis (bisa ditambah jika ingin lebih hitam)
1. Gunakan 100 gram cabai rawit / sesuai selera (dipotong-potong)




##### Cara menyiapkan Ceker Mentega Pedas Manis ala Ceker Lapindo:

1. Cuci bersih ceker ayam dan potong kukunya
1. Presto ceker ayam 20 menit. Kemudian cuci / bilas untuk menghilangkan kotoran sisa presto dan tiriskan.
1. Masak air 2L sampai mendidih lalu masukkan ceker.
1. Panaskan wajan dan lelehkan mentega
1. Masukkan cincangan jahe dan bawang putih.
1. Tumis hingga harum. Kemudian masukkan ke dalam panci yang berisi ceker.
1. Masukkan gula, garam, masako, kecap. Tes rasa
1. Masak dan tutup panci selama 30 menit. Kemudian masukkan irisan cabai. Masak dan tutup lagi selama 30 menit.
1. Matikan kompor dan koreksi rasa.
1. Jika warna belum terlalu hitam tidak masalah karena Semakin lama nanti bumbu semakin masuk.
1. Pedas dan manis sesuai selera, kalau saya suka yang pedas manis. Jika mau lebih hitam tambahkan lebih banyak kecap.




Terima kasih telah menggunakan resep yang tim kami tampilkan di halaman ini. Besar harapan kami, olahan Ceker Mentega Pedas Manis ala Ceker Lapindo yang mudah di atas dapat membantu Anda menyiapkan hidangan yang sedap untuk keluarga/teman ataupun menjadi inspirasi bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
