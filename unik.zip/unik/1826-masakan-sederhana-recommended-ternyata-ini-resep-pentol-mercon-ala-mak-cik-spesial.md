---
description: "RECOMMENDED! Ternyata Ini Resep Pentol Mercon Ala Mak Cik Spesial"
title: "RECOMMENDED! Ternyata Ini Resep Pentol Mercon Ala Mak Cik Spesial"
slug: 1826-masakan-sederhana-recommended-ternyata-ini-resep-pentol-mercon-ala-mak-cik-spesial
date: 2020-04-09T08:02:55.946Z
image: https://img-global.cpcdn.com/recipes/c449763db166d585/751x532cq70/pentol-mercon-ala-mak-cik-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c449763db166d585/751x532cq70/pentol-mercon-ala-mak-cik-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c449763db166d585/751x532cq70/pentol-mercon-ala-mak-cik-foto-resep-utama.jpg
author: Eleanor Logan
ratingvalue: 3.4
reviewcount: 11
recipeingredient:
- " Pentol ayam  sapi"
- "2 Siung Bawang putih"
- "4 Siung Bawang merah"
- "1 Butir Kemiri"
- "20 Buah Cabai Keriting"
- "1 Buah Tomat"
- " Terasi sesuai selera"
- " Bahan Tambahan"
- "secukupnya Garam"
- "secukupnya Bumbu kaldu"
- "3 helai daun jeruk"
- "1 helai daun salam"
- " Bawang goreng untuk taburan"
- "secukupnya Minyak goreng"
recipeinstructions:
- "Goreng Bawang putih, Bawang merah, cabai, kemiri, dan tomat sampai setengah matang. Angkat tiriskan lalu haluskan bersamaan dengan terasi. Bisa di ulek atau di blend"
- "Siapkan wajan dan sedikit minyak untuk menumis bumbu halus. Ketika sudah harum masukkan pentol, taburi garam dan bumbu kaldu serta daun jeruk dan daun salam."
- "Jika dirasa bumbu dan pentol sudah menyatu sajikan dan taburi dengan bawang goreng."
- "Siap dimakan hangat-hangat 🥰"
categories:
- Resep
tags:
- pentol
- mercon
- ala

katakunci: pentol mercon ala 
nutrition: 285 calories
recipecuisine: Indonesian
preptime: "PT27M"
cooktime: "PT38M"
recipeyield: "3"
recipecategory: Dinner

---


![Pentol Mercon Ala Mak Cik](https://img-global.cpcdn.com/recipes/c449763db166d585/751x532cq70/pentol-mercon-ala-mak-cik-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep pentol mercon ala mak cik yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal pentol mercon ala mak cik yang enak seharusnya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari pentol mercon ala mak cik, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan pentol mercon ala mak cik yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah pentol mercon ala mak cik yang siap dikreasikan. Anda bisa menyiapkan Pentol Mercon Ala Mak Cik menggunakan 14 jenis bahan dan 4 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk mengolah Pentol Mercon Ala Mak Cik:

1. Ambil  Pentol ayam / sapi
1. Gunakan 2 Siung Bawang putih
1. Siapkan 4 Siung Bawang merah
1. Siapkan 1 Butir Kemiri
1. Siapkan 20 Buah Cabai Keriting
1. Sediakan 1 Buah Tomat
1. Gunakan  Terasi (sesuai selera)
1. Gunakan  Bahan Tambahan
1. Siapkan secukupnya Garam
1. Sediakan secukupnya Bumbu kaldu
1. Ambil 3 helai daun jeruk
1. Gunakan 1 helai daun salam
1. Siapkan  Bawang goreng untuk taburan
1. Siapkan secukupnya Minyak goreng




##### Langkah-langkah menyiapkan Pentol Mercon Ala Mak Cik:

1. Goreng Bawang putih, Bawang merah, cabai, kemiri, dan tomat sampai setengah matang. Angkat tiriskan lalu haluskan bersamaan dengan terasi. Bisa di ulek atau di blend
1. Siapkan wajan dan sedikit minyak untuk menumis bumbu halus. Ketika sudah harum masukkan pentol, taburi garam dan bumbu kaldu serta daun jeruk dan daun salam.
1. Jika dirasa bumbu dan pentol sudah menyatu sajikan dan taburi dengan bawang goreng.
1. Siap dimakan hangat-hangat 🥰




Terima kasih telah membaca resep yang tim kami tampilkan di sini. Besar harapan kami, olahan Pentol Mercon Ala Mak Cik yang mudah di atas dapat membantu Anda menyiapkan hidangan yang enak untuk keluarga/teman maupun menjadi inspirasi dalam berjualan makanan. Semoga bermanfaat dan selamat mencoba!
