---
description: "RECOMMENDED! Ternyata Ini Cara Membuat Pinyaram/Cucur Gula Merah Gampang Banget"
title: "RECOMMENDED! Ternyata Ini Cara Membuat Pinyaram/Cucur Gula Merah Gampang Banget"
slug: 1393-masakan-sederhana-recommended-ternyata-ini-cara-membuat-pinyaram-cucur-gula-merah-gampang-banget
date: 2020-05-08T11:40:19.146Z
image: https://img-global.cpcdn.com/recipes/12040b7069f6e7c2/751x532cq70/pinyaramcucur-gula-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/12040b7069f6e7c2/751x532cq70/pinyaramcucur-gula-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/12040b7069f6e7c2/751x532cq70/pinyaramcucur-gula-merah-foto-resep-utama.jpg
author: Kenneth Guzman
ratingvalue: 3.6
reviewcount: 3
recipeingredient:
- "100 gr tepung terigu"
- "125 gr tepung beras"
- "150 gr gula merah"
- "1/2 sdt garam"
- "210 ml air"
recipeinstructions:
- "Iris2 gula merah, masukkan ke dalam panci. Beri air, panaskan hingga gula larut. Tidak perlu sampai mendidih, angkat dan dinginkan."
- "Di wadah lain campur tepung terigu, tepung beras dan garam. Aduk rata. Kemudian tuang larutan gula merah."
- "Aduk2 hingga licin dan tidak ada tepung yang bergerindil. Saring bila perlu. Diamkan minimal 15 menit. Saya diamkan 30 menit"
- "Panaskan sedikit minyak di wajan sampai benar2 panas. Tuang 1 sendok sayur adonan. Tunggu hingga terbentuk serat sampai ke tengah. Siram2 minyak dari pinggiran kue cucur.Angkat dan tiriskan. Lakukan sampai semua adonan habis."
- "Kue cucur siap disajikan..."
- "Lembut dan kenyal...yang pasti.. maniiis... hehe"
categories:
- Resep
tags:
- pinyaramcucur
- gula
- merah

katakunci: pinyaramcucur gula merah 
nutrition: 101 calories
recipecuisine: Indonesian
preptime: "PT22M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Dessert

---


![Pinyaram/Cucur Gula Merah](https://img-global.cpcdn.com/recipes/12040b7069f6e7c2/751x532cq70/pinyaramcucur-gula-merah-foto-resep-utama.jpg)

Lagi mencari inspirasi resep pinyaram/cucur gula merah yang unik? Cara membuatnya memang susah-susah gampang. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pinyaram/cucur gula merah yang enak selayaknya punya aroma dan rasa yang mampu memancing selera kita.



Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari pinyaram/cucur gula merah, mulai dari jenis bahan, lalu pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan pinyaram/cucur gula merah yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi suguhan istimewa.


Nah, kali ini kita coba, yuk, buat pinyaram/cucur gula merah sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Pinyaram/Cucur Gula Merah menggunakan 5 bahan dan 6 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam mengolah Pinyaram/Cucur Gula Merah:

1. Ambil 100 gr tepung terigu
1. Gunakan 125 gr tepung beras
1. Gunakan 150 gr gula merah
1. Sediakan 1/2 sdt garam
1. Siapkan 210 ml air




##### Cara menyiapkan Pinyaram/Cucur Gula Merah:

1. Iris2 gula merah, masukkan ke dalam panci. Beri air, panaskan hingga gula larut. Tidak perlu sampai mendidih, angkat dan dinginkan.
1. Di wadah lain campur tepung terigu, tepung beras dan garam. Aduk rata. Kemudian tuang larutan gula merah.
1. Aduk2 hingga licin dan tidak ada tepung yang bergerindil. Saring bila perlu. Diamkan minimal 15 menit. Saya diamkan 30 menit
1. Panaskan sedikit minyak di wajan sampai benar2 panas. Tuang 1 sendok sayur adonan. Tunggu hingga terbentuk serat sampai ke tengah. Siram2 minyak dari pinggiran kue cucur.Angkat dan tiriskan. Lakukan sampai semua adonan habis.
1. Kue cucur siap disajikan...
1. Lembut dan kenyal...yang pasti.. maniiis... hehe




Gimana nih? Gampang kan? Itulah cara membuat pinyaram/cucur gula merah yang bisa Anda lakukan di rumah. Selamat mencoba!
