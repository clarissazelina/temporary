---
description: "WAJIB DICOBA! Begini Cara Membuat Gulali tepung / gulali basah rambut nenek Enak"
title: "WAJIB DICOBA! Begini Cara Membuat Gulali tepung / gulali basah rambut nenek Enak"
slug: 1187-masakan-sederhana-wajib-dicoba-begini-cara-membuat-gulali-tepung-gulali-basah-rambut-nenek-enak
date: 2020-09-16T00:57:05.493Z
image: https://img-global.cpcdn.com/recipes/c6403a65296c3042/751x532cq70/gulali-tepung-gulali-basah-rambut-nenek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c6403a65296c3042/751x532cq70/gulali-tepung-gulali-basah-rambut-nenek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c6403a65296c3042/751x532cq70/gulali-tepung-gulali-basah-rambut-nenek-foto-resep-utama.jpg
author: Mike Wheeler
ratingvalue: 4.5
reviewcount: 14
recipeingredient:
- "250 grm tepung Beras"
- "250 grm gula pasir"
- "200 ml air"
- "1/2 sdt air jeruk nipis"
- "Secukupnya pewarna biru sesuai selera"
recipeinstructions:
- "Siapkan semua bahan"
- "Sangrai tepung beras sampai harum, matikan kompor. Selanjutnya tuang tepung Beras yang sudah disangrai tersebut ke atas wadah yang lebar seperti loyang untuk membuat kue. Taburkan dengan merata dan diamkan hingga panasnya menghilang. Sambil menunggu dingin, sekarang kita membuat adonan gulalinya."
- "Campurkan gula, air, pewarna dan air jeruk. Setelah itu masak menggunakan api sedang sambil terus diaduk sampai mendidih. Terus dimasak sampai berbusa dan agak kental kira-kira 8-10 menit. Tapi untuk sesi ini setelah mendidih, cukup aduk sesekali ya. Jadi kalau sudah mendidih jangan sering-sering diaduk agar gula tidak mengkristal."
- "TIPS: Untuk mengetahui apakah gulanya sudah cukup kental atau belum yaitu: ketika sudah mendidih dan berbusa. Matikan kompor, terus diaduk-aduk jika busanya cepat hilang berarti adonan masih cair jadi silahkan dimasak lagi. Tapi jika kompornya sudah mati, terus diaduk-aduk busanya lama menghilang berarti adonan sudah pas tingkat kekentalannya. Jadi bisa dikatakan sudah jadi Gulali."
- "Aduk hingga busa hilang dan menjadi bening. Angkat wajan tersebut lalu tuang adonan gulali panas ke wajan lain yang sudah ditempatkan diatas bak berisi air. Diamkan gulali hingga kental dan agak mengeras."
- "Setelah mengental dan agak mengeras ambil adonan secukupnya lalu bentuk melingkar seperti karet gelang. Lalu gulingkan ke atas tepung yang sudah disangrai tadi sambil terus lipat ulang dan dipilin ulang lalu ditarik. Jadi begitu terus hingga berbentuk menjadi seperti mie atau rambut nenek."
- "Jika Sudah Jadi Bisa Langsung Dimakan atau bisa disimpan di tempat kedap udara.Karena rambut nenek Gulali basah ini tidak bisa tahan di udara luar.Jika terlalu lama diluar,gulali bisa mencair dan menempel kembali satu sama lain, seperti foto ke dua dibawah ini."
categories:
- Resep
tags:
- gulali
- tepung
katakunci: gulali tepung  
nutrition: 137 calories
recipecuisine: Indonesian
preptime: "PT34M"
cooktime: "PT49M"
recipeyield: "1"
recipecategory: Lunch

---


![Gulali tepung / gulali basah rambut nenek](https://img-global.cpcdn.com/recipes/c6403a65296c3042/751x532cq70/gulali-tepung-gulali-basah-rambut-nenek-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep gulali tepung / gulali basah rambut nenek yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gulali tepung / gulali basah rambut nenek yang enak harusnya sih mempunyai aroma dan rasa yang dapat memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gulali tepung / gulali basah rambut nenek, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau ingin menyiapkan gulali tepung / gulali basah rambut nenek enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan spesial.

Hai semuannya, hari ini aku akan membuat GULALI TEPUNG atau GULALI BASAH. Aku juga akan bagikan tips dalam membuat gulali ini. Jajanan Jadul rambut nenek nih Gaes.


Nah, kali ini kita coba, yuk, ciptakan gulali tepung / gulali basah rambut nenek sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Gulali tepung / gulali basah rambut nenek menggunakan 5 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Gulali tepung / gulali basah rambut nenek:

1. Ambil 250 grm tepung Beras
1. Ambil 250 grm gula pasir
1. Sediakan 200 ml air
1. Sediakan 1/2 sdt air jeruk nipis
1. Ambil Secukupnya pewarna biru (sesuai selera)


Mencoba Bikin Gulali Tepung Rambut Nenek Acak Acakan Andriani Mareth. Gulali yang selanjutnya dibuat dengan campuran tepung. Para pedagang biasanya menarik-narik adonan gulali ini sedemikian rupa hingga berbentuk seperti mie atau seperti benang sutra. Kebanyakan orang menyebut gulali ini sebagai rambut nenek karena bentuknya yang kusut dan acak-acakan. 

##### Cara membuat Gulali tepung / gulali basah rambut nenek:

1. Siapkan semua bahan
1. Sangrai tepung beras sampai harum, matikan kompor. Selanjutnya tuang tepung Beras yang sudah disangrai tersebut ke atas wadah yang lebar seperti loyang untuk membuat kue. Taburkan dengan merata dan diamkan hingga panasnya menghilang. Sambil menunggu dingin, sekarang kita membuat adonan gulalinya.
1. Campurkan gula, air, pewarna dan air jeruk. Setelah itu masak menggunakan api sedang sambil terus diaduk sampai mendidih. Terus dimasak sampai berbusa dan agak kental kira-kira 8-10 menit. Tapi untuk sesi ini setelah mendidih, cukup aduk sesekali ya. Jadi kalau sudah mendidih jangan sering-sering diaduk agar gula tidak mengkristal.
1. TIPS: Untuk mengetahui apakah gulanya sudah cukup kental atau belum yaitu: ketika sudah mendidih dan berbusa. Matikan kompor, terus diaduk-aduk jika busanya cepat hilang berarti adonan masih cair jadi silahkan dimasak lagi. Tapi jika kompornya sudah mati, terus diaduk-aduk busanya lama menghilang berarti adonan sudah pas tingkat kekentalannya. Jadi bisa dikatakan sudah jadi Gulali.
1. Aduk hingga busa hilang dan menjadi bening. Angkat wajan tersebut lalu tuang adonan gulali panas ke wajan lain yang sudah ditempatkan diatas bak berisi air. Diamkan gulali hingga kental dan agak mengeras.
1. Setelah mengental dan agak mengeras ambil adonan secukupnya lalu bentuk melingkar seperti karet gelang. Lalu gulingkan ke atas tepung yang sudah disangrai tadi sambil terus lipat ulang dan dipilin ulang lalu ditarik. Jadi begitu terus hingga berbentuk menjadi seperti mie atau rambut nenek.
1. Jika Sudah Jadi Bisa Langsung Dimakan atau bisa disimpan di tempat kedap udara.Karena rambut nenek Gulali basah ini tidak bisa tahan di udara luar.Jika terlalu lama diluar,gulali bisa mencair dan menempel kembali satu sama lain, seperti foto ke dua dibawah ini.


Membuat Gulali Tepung Gulali Rambut Nenek Gulali Basah Jajanan Sd. Hai semuannya, hari ini aku akan membuat GULALI TEPUNG atau GULALI BASAH. Aku juga akan bagikan tips dalam membuat gulali ini. Gulali Basah Rambut Nenek Jajanan Jadul Anti Gagal. Japanese Street Food Cotton Candy Art Chicken Rabbit Bear Japan. 

Gimana nih? Mudah bukan? Itulah cara membuat gulali tepung / gulali basah rambut nenek yang bisa Anda praktikkan di rumah. Selamat mencoba!
