---
description: "BIKIN NAGIH! Ternyata Ini Resep Palai Bada Enak"
title: "BIKIN NAGIH! Ternyata Ini Resep Palai Bada Enak"
slug: 1320-masakan-sederhana-bikin-nagih-ternyata-ini-resep-palai-bada-enak
date: 2020-05-03T02:03:43.646Z
image: https://img-global.cpcdn.com/recipes/2d4195452b8720a5/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2d4195452b8720a5/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2d4195452b8720a5/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Alejandro Morris
ratingvalue: 4.9
reviewcount: 4
recipeingredient:
- "300 gr teri basah"
- "1 bh kelapa parut halus"
- "2 lbr daun kunyit iris halus"
- "2 ikat kemangi ambil daunnya"
- "1 bh jeruk nipis"
- "Seikat daun singkong ambil yg muda"
- " Daun pisang dan tusuk gigi secukupnya utk membungkus"
- " Bumbu halus"
- "30 bh cabe merah keriting  rawit merah"
- "10 bh bawang merah besar"
- "4 siung bawang putih besar"
- "Seruas kunyit"
- "1,5 ruas jahe"
- "secukupnya garam"
recipeinstructions:
- "Bersihkan ikan teri dan siapkan bahan lainnya"
- "Masukan dlm wadah bumbu halus, kelapa parut, daun kunyit, kemangi dan perasan air jeruk nipis. Aduk rata, masukan teri, aduk rata lagi."
- "Siapkan daun pisang (saya dicuci dulu). Tata sedikit daun singkong di atas daun pisang, taro campuran ikan teri tadi di atas daun singkong sebanyak 1 centong nasi, tutup lagi dg sdikit daun singkong."
- "Bungkus, lalu tusuk kedua ujung daun dengan tusuk gigi"
- "Kukus selama 20 menit"
- "Setelah dikukus, panggang dg panggangan atau dg teflon."
- "Palai bada siap disantap dg nasi panas"

categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 157 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT59M"
recipeyield: "2"
recipecategory: Lunch

---


![Palai Bada](https://img-global.cpcdn.com/recipes/2d4195452b8720a5/751x532cq70/palai-bada-foto-resep-utama.jpg)

Lagi mencari inspirasi resep palai bada yang unik? Cara membuatnya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal palai bada yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.

Palai bada adalah salah satu hidangan yang berasal dari Sumatra Barat. Hidangan ini menggunakan ikan teri sebagai bahan utamanya, yang oleh penduduk setempat disebut dengan \"ikan bada\" atau \"maco bada\" (dalam bentuk ikan asin). Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\".

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari palai bada, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan palai bada yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi sajian spesial.


Berikut ini ada beberapa tips dan trik praktis dalam mengolah palai bada yang siap dikreasikan. Anda bisa menyiapkan Palai Bada menggunakan 14 bahan dan 8 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Palai Bada:

1. Siapkan 300 gr teri basah
1. Gunakan 1 bh kelapa parut halus
1. Sediakan 2 lbr daun kunyit (iris halus)
1. Sediakan 2 ikat kemangi (ambil daunnya)
1. Sediakan 1 bh jeruk nipis
1. Sediakan Seikat daun singkong (ambil yg muda)
1. Sediakan  Daun pisang dan tusuk gigi secukupnya utk membungkus
1. Siapkan  Bumbu halus:
1. Siapkan 30 bh cabe merah keriting + rawit merah
1. Sediakan 10 bh bawang merah besar
1. Siapkan 4 siung bawang putih besar
1. Gunakan Seruas kunyit
1. Gunakan 1,5 ruas jahe
1. Sediakan secukupnya garam


Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. 

##### Cara meracik Palai Bada:

1. Bersihkan ikan teri dan siapkan bahan lainnya
1. Masukan dlm wadah bumbu halus, kelapa parut, daun kunyit, kemangi dan perasan air jeruk nipis. Aduk rata, masukan teri, aduk rata lagi.
1. Siapkan daun pisang (saya dicuci dulu). Tata sedikit daun singkong di atas daun pisang, taro campuran ikan teri tadi di atas daun singkong sebanyak 1 centong nasi, tutup lagi dg sdikit daun singkong.
1. Bungkus, lalu tusuk kedua ujung daun dengan tusuk gigi
1. Kukus selama 20 menit
1. Setelah dikukus, panggang dg panggangan atau dg teflon.
1. Palai bada siap disantap dg nasi panas

Palai Bada (Pepes Teri Basah) terbuat dari ikan teri basah yang dicampur dengan parutan kelapa, serta beragam bumbu seperti daun kunyit, daun serei, lengkuas, asam, dan lainnya. Semua lagu disini hanya untuk review saja, Jika kamu suka lagu Palai Bada belilah CD original. Yo … palai bada, lamak rasonyo makan baduo Yo … palai bada, lamak rasonyo makan baduo. Urang Rao pai ka danau Ambiak rumpuik si bilang-bilang Yo kok tuan indak picayo Bali sabungkuih baok. Palai Bada sprot met kruiden gegrild in bananenblad. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Palai Bada yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman maupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
