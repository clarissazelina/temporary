---
description: "TERUNGKAP! Inilah Cara Membuat Pensi ↔ Olahan Kerang Air Tawar Khas Padang Enak"
title: "TERUNGKAP! Inilah Cara Membuat Pensi ↔ Olahan Kerang Air Tawar Khas Padang Enak"
slug: 1351-masakan-sederhana-terungkap-inilah-cara-membuat-pensi-olahan-kerang-air-tawar-khas-padang-enak
date: 2020-05-02T01:55:05.857Z
image: https://img-global.cpcdn.com/recipes/5d5bfcc54f3a46fa/751x532cq70/pensi-↔-olahan-kerang-air-tawar-khas-padang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5d5bfcc54f3a46fa/751x532cq70/pensi-↔-olahan-kerang-air-tawar-khas-padang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5d5bfcc54f3a46fa/751x532cq70/pensi-↔-olahan-kerang-air-tawar-khas-padang-foto-resep-utama.jpg
author: Lina Jones
ratingvalue: 4.4
reviewcount: 6
recipeingredient:
- "3 liter Kerang Air Tawar Bercangkang di sini jualnya literan"
- "2,5 liter Air Panas Mendidih"
- "3 sdm Cabe Giling"
- "3 sdt Bubuk Masak Kambing"
- "5 lembar Daun Pandan"
- "5 batang Daun Bawang"
- "2 batang Sereh"
- "2 lembar Daun Jeruk"
- "2 lembar Daun Salam"
- "2 lembar Daun Kunyit"
- "2 sdt Garam"
- "5 sdm Minyak Sayur Secukupnya untuk menggoreng"
- " Bumbu Halus"
- "5 siung Bawang Merah"
- "4 siung Bawang Putih"
- "1/4 sdt Garam"
recipeinstructions:
- "Siapkan bumbu dan daun daunan. Cuci bersih kemudian iris tipis sereh, daun pandan dan daun bawang. Cuci pula daun jeruk dan daun kunyit (duo daun ini cukup dikucai). Jangan lupa siapkan bumbu halus. Sisihkan"
- "Cuci bersih kerang. Tips agar tidak bau tanah adalah rendam kerang dengan air bersih (mentah) minimal 30 menit sebelum diolah, lalu bilas sekali. Setelah itu lanjut rendam dengan air panas selama 10 menit. Tiriskan."
- "Tumis bumbu halus hingga wangi. Tambahkan cabe giling tumis hingga aroma tidak menyengat hidung. Tambahkan irisan dedaunan. Aduk rata."
- "Tambahkan bumbu masak kambing, daun kunyit dan daun jeruk. Lalu masukan kerang. Aduk hingga kerang tercampur bumbu secara merata. Tambahkan garam, aduk sebentar lalu biarkan tertutup."
- "Setelah lima belas menit kerang dimasak dengan api sedang. Kerang sudah mulai terbuka. Aduk agar daging kerang tercampur bumbu tutup kembali selama kurleb 10 menit. Tes rasa."
- "Setelah dirasa daging kerang sudah meresap bumbu dengan sempurna. Matikan api. Olahan kerang air tawar khas padang siap disajikan. Pensi pun siap menemani sore bersama keluarga.. Happy cooking 🤗"
categories:
- Resep
tags:
- pensi- olahan

katakunci: pensi  olahan 
nutrition: 133 calories
recipecuisine: Indonesian
preptime: "PT37M"
cooktime: "PT38M"
recipeyield: "2"
recipecategory: Lunch

---


![Pensi ↔ Olahan Kerang Air Tawar Khas Padang](https://img-global.cpcdn.com/recipes/5d5bfcc54f3a46fa/751x532cq70/pensi-↔-olahan-kerang-air-tawar-khas-padang-foto-resep-utama.jpg)

Sedang mencari inspirasi resep pensi ↔ olahan kerang air tawar khas padang yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pensi ↔ olahan kerang air tawar khas padang yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari pensi ↔ olahan kerang air tawar khas padang, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan pensi ↔ olahan kerang air tawar khas padang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.


Nah, kali ini kita coba, yuk, variasikan pensi ↔ olahan kerang air tawar khas padang sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Pensi ↔ Olahan Kerang Air Tawar Khas Padang menggunakan 16 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Pensi ↔ Olahan Kerang Air Tawar Khas Padang:

1. Sediakan 3 liter Kerang Air Tawar Bercangkang (di sini jualnya literan)
1. Siapkan 2,5 liter Air Panas Mendidih
1. Ambil 3 sdm Cabe Giling
1. Sediakan 3 sdt Bubuk Masak Kambing
1. Ambil 5 lembar Daun Pandan
1. Ambil 5 batang Daun Bawang
1. Siapkan 2 batang Sereh
1. Sediakan 2 lembar Daun Jeruk
1. Gunakan 2 lembar Daun Salam
1. Sediakan 2 lembar Daun Kunyit
1. Ambil 2 sdt Garam
1. Siapkan 5 sdm Minyak Sayur (Secukupnya untuk menggoreng)
1. Ambil  Bumbu Halus
1. Sediakan 5 siung Bawang Merah
1. Siapkan 4 siung Bawang Putih
1. Ambil 1/4 sdt Garam




##### Cara meracik Pensi ↔ Olahan Kerang Air Tawar Khas Padang:

1. Siapkan bumbu dan daun daunan. Cuci bersih kemudian iris tipis sereh, daun pandan dan daun bawang. Cuci pula daun jeruk dan daun kunyit (duo daun ini cukup dikucai). Jangan lupa siapkan bumbu halus. Sisihkan
1. Cuci bersih kerang. Tips agar tidak bau tanah adalah rendam kerang dengan air bersih (mentah) minimal 30 menit sebelum diolah, lalu bilas sekali. Setelah itu lanjut rendam dengan air panas selama 10 menit. Tiriskan.
1. Tumis bumbu halus hingga wangi. Tambahkan cabe giling tumis hingga aroma tidak menyengat hidung. Tambahkan irisan dedaunan. Aduk rata.
1. Tambahkan bumbu masak kambing, daun kunyit dan daun jeruk. Lalu masukan kerang. Aduk hingga kerang tercampur bumbu secara merata. Tambahkan garam, aduk sebentar lalu biarkan tertutup.
1. Setelah lima belas menit kerang dimasak dengan api sedang. Kerang sudah mulai terbuka. Aduk agar daging kerang tercampur bumbu tutup kembali selama kurleb 10 menit. Tes rasa.
1. Setelah dirasa daging kerang sudah meresap bumbu dengan sempurna. Matikan api. Olahan kerang air tawar khas padang siap disajikan. Pensi pun siap menemani sore bersama keluarga.. Happy cooking 🤗




Bagaimana? Gampang kan? Itulah cara menyiapkan pensi ↔ olahan kerang air tawar khas padang yang bisa Anda lakukan di rumah. Selamat mencoba!
