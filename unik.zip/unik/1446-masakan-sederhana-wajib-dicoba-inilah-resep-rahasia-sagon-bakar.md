---
description: "WAJIB DICOBA! Inilah Resep Rahasia Sagon Bakar "
title: "WAJIB DICOBA! Inilah Resep Rahasia Sagon Bakar "
slug: 1446-masakan-sederhana-wajib-dicoba-inilah-resep-rahasia-sagon-bakar
date: 2020-07-18T03:31:26.356Z
image: https://img-global.cpcdn.com/recipes/41b5f87791832030/751x532cq70/sagon-bakar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/41b5f87791832030/751x532cq70/sagon-bakar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/41b5f87791832030/751x532cq70/sagon-bakar-foto-resep-utama.jpg
author: Beulah Flowers
ratingvalue: 3.3
reviewcount: 11
recipeingredient:
- "250 gr tepung sagu"
- "1/2 buah kelapa setengah tua bersihkan kulitnya parut"
- "1/4 gelas gula pasir saya tidak suka manis silakan tambah y"
- "secukupnya daun pandan saya skip krn gk punya"
recipeinstructions:
- "Sangrai kelapa parut sebentar."
- "Campurkan tepung dengan bahan - bahan yang lain. Aduk hingga rata dengan tangan. Jika kurang manis silakan tambah gula."
- "Cetak adonan dengan cetakan kue satu/cetakan jelly/cetakan nastar daun. Padatkan adonan dengan jempol sambil ditekan."
- "Oles margarin tipis di loyang. Panaskan oven selama 10 menit dengan suhu 150 derajat"
- "Pukul sedikit cetakan agar-hingga adonan terlepas dan letakan di loyang. Jika adonan berantakan, tambahkan setengah sendok makan air pada adonan dan diaduk baru dicetak kembali."
- "Oven selama 25 menit dengan suhu 150 derajat menggunakan api atas bawah. Dinginkan. Lalu simpan dalam wadah kedap udara."
categories:
- Resep
tags:
- sagon
- bakar

katakunci: sagon bakar 
nutrition: 229 calories
recipecuisine: Indonesian
preptime: "PT13M"
cooktime: "PT43M"
recipeyield: "4"
recipecategory: Dessert

---


![Sagon Bakar](https://img-global.cpcdn.com/recipes/41b5f87791832030/751x532cq70/sagon-bakar-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep sagon bakar yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal sagon bakar yang enak seharusnya punya aroma dan rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sagon bakar, mulai dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tak perlu pusing kalau mau menyiapkan sagon bakar yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan spesial.

Sagon Bakar Ciaul sangat dikenal karena mempunyai Cita rasa, Gurih, Renyah, dan Lakersnya (SANGAT BERBEDA DARI SAGON BIASANYA & Lainnya). Sagon Bakar \"CIAUL\" terbuat dari bahan-bahan yang berkualitas,sehingga kue yang kami Produksi ini memiliki keunggulan tekstur dan rasa dibandingkan dengan kue yang sejenisnya. Resep Kue Kering Sagon Kelapa Bakar Ketan Sederhana Spesial Renyah Gurih Asli Enak.


Nah, kali ini kita coba, yuk, kreasikan sagon bakar sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Sagon Bakar memakai 4 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk meracik Sagon Bakar:

1. Gunakan 250 gr tepung sagu
1. Sediakan 1/2 buah kelapa setengah tua, bersihkan kulitnya, parut
1. Siapkan 1/4 gelas gula pasir (saya tidak suka manis, silakan tambah y)
1. Sediakan secukupnya daun pandan (saya skip krn gk punya)


Cari produk Makanan Instan Kaleng lainnya di Tokopedia. Sagon inggih punika salah satunggaling tetedhan tradhisional khas Jawa Tengah. Ing wekdal rumiyin, kathah tiyang ingkang remen damel sagon kanthi bahan-bahan ingkang prasaja tanpa bahan pengawèt. Онлайн видео TUTORIAL IBU IRMA SAGON BAKAR \'CARA MEMBUAT DODOL AGAR\' — смотреть на imperiya.by. Bar in Ho Chi Minh City, Vietnam. 

##### Langkah-langkah mengolah Sagon Bakar:

1. Sangrai kelapa parut sebentar.
1. Campurkan tepung dengan bahan - bahan yang lain. Aduk hingga rata dengan tangan. Jika kurang manis silakan tambah gula.
1. Cetak adonan dengan cetakan kue satu/cetakan jelly/cetakan nastar daun. Padatkan adonan dengan jempol sambil ditekan.
1. Oles margarin tipis di loyang. Panaskan oven selama 10 menit dengan suhu 150 derajat
1. Pukul sedikit cetakan agar-hingga adonan terlepas dan letakan di loyang. Jika adonan berantakan, tambahkan setengah sendok makan air pada adonan dan diaduk baru dicetak kembali.
1. Oven selama 25 menit dengan suhu 150 derajat menggunakan api atas bawah. Dinginkan. Lalu simpan dalam wadah kedap udara.


Sagon bakar dan sagon serbuk yang menjadi makanan ringan pada zaman dahulu telah. Sagon bakar ini berbahan dasar kelapa parut ini menghasilkan rasa yang sangat gurih apalagi ditambah dengan kacang tanah yang juga memiliki rasa gurih. Selain mochi, sagon bakar adalah camilan khas Sukabumi lainnya. Sagon bakar terbuat dari kelapa, aci, dan bahan lainnya. Cocok banget jadi teman ngopi! owl:sameAs. dbpedia-id:Sagon_Bakar. 

Terima kasih telah menggunakan resep yang tim kami tampilkan di sini. Harapan kami, olahan Sagon Bakar yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman maupun menjadi inspirasi bagi Anda yang berkeinginan untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
