---
description: "BIKIN NGILER! Begini Cara Membuat Klapertaart Simpel "
title: "BIKIN NGILER! Begini Cara Membuat Klapertaart Simpel "
slug: 1242-masakan-sederhana-bikin-ngiler-begini-cara-membuat-klapertaart-simpel
date: 2020-05-25T07:59:16.130Z
image: https://img-global.cpcdn.com/recipes/13a764b5ca19c76d/751x532cq70/klapertaart-simpel-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/13a764b5ca19c76d/751x532cq70/klapertaart-simpel-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/13a764b5ca19c76d/751x532cq70/klapertaart-simpel-foto-resep-utama.jpg
author: Peter Curry
ratingvalue: 4.5
reviewcount: 6
recipeingredient:
- "250 ml susu cair full cream"
- "450 ml Air kelapa muda"
- "60 gr SKM atau kurleb 7 sdm ditambah jika suka lbh creamy"
- "80 gram gula pasir kurleb 5 sdm"
- "1 sdt vanilla extractbisa pakai vanila bubuk"
- "80 gram tepung maizena kurleb 6 sdm"
- "1/4 sdt garam"
- "4 buah kuning telur"
- "5 sdm kismis"
- "200 gram kelapa muda keruk isinya saya hanya 140 gr"
- "3 sdm mentega margarin"
- " topping"
- "4 buttir putih telur"
- "1 sdt vanilla extract vanilla bubuk"
- "1 atau 2 sdm gula pasir sesuai selera"
- "secukupnya kayu manis bubuk"
- "secukupnya kenari keping"
- "secukupnya kelapa muda"
- "secukupnya kismis"
recipeinstructions:
- "Campur kuning telur, air kelapa, susu cair, vanilla, maizena, garam dalam panci, aduk rata. Saring. Masukkan gula. Aduk rata."
- "Lalu masak adonan sampai meletup2, aduk terus sampai lembut dan rata. Kemudian tambahkan 3 sdm mentega/margarin, aduk rata. Angkat."
- "Kemudian segera masukkan kelapa muda dan kismis. Aduk rata"
- "Siapkan wadah dan olesi mentega di kelilingnya, saya pakai pinggan tahan panas uk 20 cm (bisa mangkuk almunium atau loyang) Tuang adonan ke dalamnya hg 2/3 penuh."
- "Mixer putih telur sampai mengembang masukkan 1 atau 2 sdm gula pasir dan vanilla extract. Mixer sampai kaku."
- "Tuang atau semprotkan putih telur kocok diatas adonan klappertaart, ratakan."
- "Taburi kayu manis dan beri topping kenari keping, irisan kelapa muda dan kismis"
- "Siapkan loyang besar isi dengan air mendidih kurang lebih 1 ruas jari lalu masukkan klappertaartnya. Panggang selama 15 menit atau sampai permukaan putih telur sedikit kecoklatan, panggang dengan suhu 170℃ (menggunakan otang dgn api sedang). Angkat jika sudah kecoklatan."
- "Sajikan. Klapertart ini tekstur dalemnya lembut manis tapi msh ada gigitan di kelapanya dan foamy dan crunchy dari putinh telur dan kenarinya serta asam manis dari kismis. Note : lebih enak di sajikan dingin dan bisa tahan sampai 3-4 hari di kulkas."
categories:
- Resep
tags:
- klapertaart
- simpel

katakunci: klapertaart simpel 
nutrition: 184 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT45M"
recipeyield: "1"
recipecategory: Lunch

---


![Klapertaart Simpel](https://img-global.cpcdn.com/recipes/13a764b5ca19c76d/751x532cq70/klapertaart-simpel-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep klapertaart simpel yang unik? Cara membuatnya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal klapertaart simpel yang enak harusnya sih mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari klapertaart simpel, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika mau menyiapkan klapertaart simpel yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.

Klappertaart Manado is a very yummy and delicious, kind of sweet Fla. Made from Young Coconut Meat, custard and creamy. Lihat juga resep KLAPPERTART simple without oven and mixer 😁 enak lainnya. 🎦 Klappertaart.


Nah, kali ini kita coba, yuk, buat klapertaart simpel sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuh kita. Anda dapat membuat Klapertaart Simpel memakai 19 jenis bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah dalam membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam membuat Klapertaart Simpel:

1. Gunakan 250 ml susu cair full cream
1. Sediakan 450 ml Air kelapa muda
1. Siapkan 60 gr SKM atau kurleb 7 sdm (ditambah jika suka lbh creamy)
1. Siapkan 80 gram gula pasir kurleb 5 sdm
1. Gunakan 1 sdt vanilla extract/bisa pakai vanila bubuk
1. Siapkan 80 gram tepung maizena kurleb 6 sdm
1. Gunakan 1/4 sdt garam
1. Ambil 4 buah kuning telur
1. Ambil 5 sdm kismis
1. Gunakan 200 gram kelapa muda keruk isinya (saya hanya 140 gr)
1. Gunakan 3 sdm mentega/ margarin
1. Siapkan  topping:
1. Ambil 4 buttir putih telur
1. Gunakan 1 sdt vanilla extract /vanilla bubuk
1. Sediakan 1 atau 2 sdm gula pasir (sesuai selera)
1. Ambil secukupnya kayu manis bubuk
1. Ambil secukupnya kenari keping
1. Sediakan secukupnya kelapa muda
1. Sediakan secukupnya kismis


Our collection of coverlets lends a simple country touch to your bedroom decor. klappertaart. Последние твиты от Hanna\'s Klappertaart (@klappertaart). Happy tummy is a happy heart. Enjoy the tender Salmon En Croûte, the creamy Klappertaart, and the soft Panna. Klappertaart adalah dessert asal Manado yang menjadi favorite banyak orang. 

##### Langkah-langkah membuat Klapertaart Simpel:

1. Campur kuning telur, air kelapa, susu cair, vanilla, maizena, garam dalam panci, aduk rata. Saring. Masukkan gula. Aduk rata.
1. Lalu masak adonan sampai meletup2, aduk terus sampai lembut dan rata. Kemudian tambahkan 3 sdm mentega/margarin, aduk rata. Angkat.
1. Kemudian segera masukkan kelapa muda dan kismis. Aduk rata
1. Siapkan wadah dan olesi mentega di kelilingnya, saya pakai pinggan tahan panas uk 20 cm (bisa mangkuk almunium atau loyang) Tuang adonan ke dalamnya hg 2/3 penuh.
1. Mixer putih telur sampai mengembang masukkan 1 atau 2 sdm gula pasir dan vanilla extract. Mixer sampai kaku.
1. Tuang atau semprotkan putih telur kocok diatas adonan klappertaart, ratakan.
1. Taburi kayu manis dan beri topping kenari keping, irisan kelapa muda dan kismis
1. Siapkan loyang besar isi dengan air mendidih kurang lebih 1 ruas jari lalu masukkan klappertaartnya. Panggang selama 15 menit atau sampai permukaan putih telur sedikit kecoklatan, panggang dengan suhu 170℃ (menggunakan otang dgn api sedang). Angkat jika sudah kecoklatan.
1. Sajikan. Klapertart ini tekstur dalemnya lembut manis tapi msh ada gigitan di kelapanya dan foamy dan crunchy dari putinh telur dan kenarinya serta asam manis dari kismis. Note : lebih enak di sajikan dingin dan bisa tahan sampai 3-4 hari di kulkas.


Klappertaart is a Dutch-influenced Indonesian cake originating from Manado, North Sulawesi. For faster navigation, this Iframe is preloading the Wikiwand page for Klappertaart. Resep dengan petunjuk video: Klappertaart dikenal sebagai kue Khas dari Manado. Teksturnya yang lembut dan rasanya yang manis, bisa dinikmati dingin ataupun hangat. An Indonesian custard-like cake made of coconut and dairy originating from the colonial period, with European and Indonesian influences. 

Bagaimana? Mudah bukan? Itulah cara menyiapkan klapertaart simpel yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
