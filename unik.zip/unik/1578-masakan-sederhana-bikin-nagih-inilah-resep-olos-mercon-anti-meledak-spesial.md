---
description: "BIKIN NAGIH! Inilah Resep Olos Mercon Anti Meledak Spesial"
title: "BIKIN NAGIH! Inilah Resep Olos Mercon Anti Meledak Spesial"
slug: 1578-masakan-sederhana-bikin-nagih-inilah-resep-olos-mercon-anti-meledak-spesial
date: 2020-09-05T01:48:46.926Z
image: https://img-global.cpcdn.com/recipes/2d2c23b26be2e755/751x532cq70/olos-mercon-anti-meledak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2d2c23b26be2e755/751x532cq70/olos-mercon-anti-meledak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2d2c23b26be2e755/751x532cq70/olos-mercon-anti-meledak-foto-resep-utama.jpg
author: Pearl Ross
ratingvalue: 3
reviewcount: 10
recipeingredient:
- "110 gr Tepung Tapioka"
- "100 gr Tepung Terigu"
- "190 ml air didihkan"
- "1/2 sdt Lada Bubuk"
- "1 sdt Penyedap Rasa"
- "1/4 sdt Garam"
- " Bahan Isian Oloss"
- "50 gr Sayur Kok iris iris tipis"
- "15 buah Cabe Setan potong2"
- "1/4 sdt Garam"
- "1/4 sdt Penyedap Rasa"
- "1/4 sdt Ladaa"
- " Bumbu Halus Untuk Isian Oloss"
- "1 siung Bawang Putih"
- "2 Siung Bawang Merah"
- "5 buah Cabe Merah"
- "1/4 sdt Gula Pasir"
recipeinstructions:
- "Kurang lebih beginii ya bahan bahan nyaa, 🤭 itu yg d wadah bumbu halus nyaa"
- "Campurkan semua Bahan untuk kulit olos nya yaa.. Sambil panaskan air."
- "Setalah mendidih, tuang semua air nya ke dalam tepung...aduk aduk sampai rata dan langsung diuleni."
- "Untuk bahan Isian nya, siapkan wajan dan panaskan minyakk... Masukan bumbu halusnya, kemudian masukan sayur kolnya..Masak sampai mateng yaa.. Kurang lebih sampai begini 👇"
- "Tunggu sayur kolnya rada adem yaa 😊Ambil sedikit Adonan kulit dn pipihkan,, lalu tambah kan sayur kol untuk isian nya"
- "Bulet buletin yaa Adonan nyaa,, lakukan pengisian sampai Adonan abis."
- "Siapkan wajan untuk menggoreng yaa.. Dan apinya sedeng ajaa..Goreng sampai Matangg deh 😊Beginii penampakan nya setelah digoreng yaaa😁 Selamat Mencoba gaesss💕"
categories:
- Resep
tags:
- olos
- mercon
- anti

katakunci: olos mercon anti 
nutrition: 262 calories
recipecuisine: Indonesian
preptime: "PT18M"
cooktime: "PT40M"
recipeyield: "1"
recipecategory: Lunch

---


![Olos Mercon Anti Meledak](https://img-global.cpcdn.com/recipes/2d2c23b26be2e755/751x532cq70/olos-mercon-anti-meledak-foto-resep-utama.jpg)

Lagi mencari inspirasi resep olos mercon anti meledak yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal olos mercon anti meledak yang enak selayaknya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Kunci agar cimol tidak meledak pada saat digoreng yaitu masukkan cimol pada minyak yang masih dingin. Day after day, the Olos Laboratory studies nature and selects the most effective, pure and genuine elements for its active ingredients. A professional cosmetic universe to exploit all the beneficial properties and the power of the sea and its elements for the overall well-being of your.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari olos mercon anti meledak, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan olos mercon anti meledak enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Nah, kali ini kita coba, yuk, siapkan olos mercon anti meledak sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Olos Mercon Anti Meledak menggunakan 17 jenis bahan dan 7 tahap pembuatan. Berikut ini cara untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam mengolah Olos Mercon Anti Meledak:

1. Sediakan 110 gr Tepung Tapioka
1. Sediakan 100 gr Tepung Terigu
1. Ambil 190 ml air (didihkan)
1. Siapkan 1/2 sdt Lada Bubuk
1. Gunakan 1 sdt Penyedap Rasa
1. Gunakan 1/4 sdt Garam
1. Gunakan  Bahan Isian Oloss
1. Siapkan 50 gr Sayur Kok (iris iris tipis)
1. Sediakan 15 buah Cabe Setan (potong2)
1. Gunakan 1/4 sdt Garam
1. Ambil 1/4 sdt Penyedap Rasa
1. Sediakan 1/4 sdt Ladaa
1. Sediakan  Bumbu Halus Untuk Isian Oloss
1. Siapkan 1 siung Bawang Putih
1. Ambil 2 Siung Bawang Merah
1. Siapkan 5 buah Cabe Merah
1. Gunakan 1/4 sdt Gula Pasir


Petasan yang dibuatnya meledak saat korban mengisi bubuk petasan. Download as DOCX, PDF, TXT or read online from Scribd. Flag for Inappropriate Content. saveSave MERCON For Later. Oseng mercon merupakan makanan asli Indonesia yang berasal dari Yogyakarta. 

##### Langkah-langkah membuat Olos Mercon Anti Meledak:

1. Kurang lebih beginii ya bahan bahan nyaa, 🤭 itu yg d wadah bumbu halus nyaa
1. Campurkan semua Bahan untuk kulit olos nya yaa.. Sambil panaskan air.
1. Setalah mendidih, tuang semua air nya ke dalam tepung...aduk aduk sampai rata dan langsung diuleni.
1. Untuk bahan Isian nya, siapkan wajan dan panaskan minyakk... Masukan bumbu halusnya, kemudian masukan sayur kolnya..Masak sampai mateng yaa.. Kurang lebih sampai begini 👇
1. Tunggu sayur kolnya rada adem yaa 😊Ambil sedikit Adonan kulit dn pipihkan,, lalu tambah kan sayur kol untuk isian nya
1. Bulet buletin yaa Adonan nyaa,, lakukan pengisian sampai Adonan abis.
1. Siapkan wajan untuk menggoreng yaa.. Dan apinya sedeng ajaa..Goreng sampai Matangg deh 😊Beginii penampakan nya setelah digoreng yaaa😁 Selamat Mencoba gaesss💕


Hal itu untuk menunjukan jika orang yang memakan oseng ini mulutnya akan terasa meledak oleh mercon karena sangat pedas. Mercon, yang dalam Bahasa Indonesia adalah petasan menjadi nama kuliner bukan tanpa sebab. Buntelan mesiu yang sering dipakai dalam perayaan Imlek dan meramaikan lebaran ini seolah meledakkan dirinya di mulut. Seperti pejuang berani mati yang mengantar bom ke sarang musuh. Lihat juga resep Oseng mercon kambing enak lainnya. 

Gimana nih? Mudah bukan? Itulah cara menyiapkan olos mercon anti meledak yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
