---
description: "BIKIN NGILER! Inilah Resep Rahasia Palai bada Gampang Banget"
title: "BIKIN NGILER! Inilah Resep Rahasia Palai bada Gampang Banget"
slug: 1315-masakan-sederhana-bikin-ngiler-inilah-resep-rahasia-palai-bada-gampang-banget
date: 2020-09-29T04:44:47.258Z
image: https://img-global.cpcdn.com/recipes/e42d612984212ee8/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e42d612984212ee8/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e42d612984212ee8/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Seth Bush
ratingvalue: 4.9
reviewcount: 13
recipeingredient:
- "500 gr teri basah"
- "400 gr kelapa parut yg setemgah tua"
- "Iris "
- "3 lbr daun kunyit"
- "6 lbr daun jeruk purut"
- "5 lbr daun tapak leman daun mangkokan sy skip"
- " Bumbu halus "
- "10 bh cabe merah keriting"
- "5 cabe rawit boleh di skip"
- "6 bw merah"
- "1 siung bw putih"
- "2 ruas kunyit"
- "2,5 ruas jahe"
- "1 bh jeruk nipis"
- "Secukupnya garam"
- "Secukupnya daun pisang untuk membungkus"
recipeinstructions:
- "Buang bagian kepala dan isi perut teri basah, lalu cuci bersih. giling kelapa parut hingga halus."
- "Utk jeruk nipis saya keluarkan bulirnya, di ulek bersama bumbu halusnya. Campur semua bahan aduk hingga semua tercampur rata."
- "Bungkus dengan daun pisang seperti membungkus pepes, kemudian panggang dgn bara arang, dibalik jika kira2 sisi bagian bawahnya sudah matang.lalu angkat jika kedua sisinya sudah matang."
- "Gunakan api sedang cenderung kecil jika memanggang dengan menggunakan kompor. Jika menggunakan double Pan cukup jgn sering ditutup https://youtu.be/dcHOem1VtBs"
categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 131 calories
recipecuisine: Indonesian
preptime: "PT39M"
cooktime: "PT56M"
recipeyield: "2"
recipecategory: Lunch

---


![Palai bada](https://img-global.cpcdn.com/recipes/e42d612984212ee8/751x532cq70/palai-bada-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep palai bada yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal palai bada yang enak harusnya sih mempunyai aroma dan cita rasa yang bisa memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari palai bada, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika ingin menyiapkan palai bada yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu menjadi sajian istimewa.

Palai bada adalah salah satu hidangan yang berasal dari Sumatra Barat. Hidangan ini menggunakan ikan teri sebagai bahan utamanya, yang oleh penduduk setempat disebut dengan \"ikan bada\" atau \"maco bada\" (dalam bentuk ikan asin). Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\".


Nah, kali ini kita coba, yuk, variasikan palai bada sendiri di rumah. Tetap dengan bahan sederhana, sajian ini bisa memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Palai bada menggunakan 16 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam mengolah Palai bada:

1. Gunakan 500 gr teri basah
1. Gunakan 400 gr kelapa parut yg setemgah tua
1. Sediakan Iris :
1. Sediakan 3 lbr daun kunyit
1. Sediakan 6 lbr daun jeruk purut
1. Sediakan 5 lbr daun tapak leman (daun mangkokan) sy skip
1. Siapkan  Bumbu halus :
1. Gunakan 10 bh cabe merah keriting
1. Ambil 5 cabe rawit boleh di skip
1. Gunakan 6 bw merah
1. Ambil 1 siung bw putih
1. Ambil 2 ruas kunyit
1. Siapkan 2,5 ruas jahe
1. Gunakan 1 bh jeruk nipis
1. Siapkan Secukupnya garam
1. Gunakan Secukupnya daun pisang untuk membungkus


Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. 

##### Cara menyiapkan Palai bada:

1. Buang bagian kepala dan isi perut teri basah, lalu cuci bersih. giling kelapa parut hingga halus.
1. Utk jeruk nipis saya keluarkan bulirnya, di ulek bersama bumbu halusnya. Campur semua bahan aduk hingga semua tercampur rata.
1. Bungkus dengan daun pisang seperti membungkus pepes, kemudian panggang dgn bara arang, dibalik jika kira2 sisi bagian bawahnya sudah matang.lalu angkat jika kedua sisinya sudah matang.
1. Gunakan api sedang cenderung kecil jika memanggang dengan menggunakan kompor. Jika menggunakan double Pan cukup jgn sering ditutup https://youtu.be/dcHOem1VtBs


Palai Bada (Pepes Teri Basah) terbuat dari ikan teri basah yang dicampur dengan parutan kelapa, serta beragam bumbu seperti daun kunyit, daun serei, lengkuas, asam, dan lainnya. Semua lagu disini hanya untuk review saja, Jika kamu suka lagu Palai Bada belilah CD original. Yo … palai bada, lamak rasonyo makan baduo Yo … palai bada, lamak rasonyo makan baduo. Urang Rao pai ka danau Ambiak rumpuik si bilang-bilang Yo kok tuan indak picayo Bali sabungkuih baok. Palai Bada sprot met kruiden gegrild in bananenblad. 

Terima kasih telah menggunakan resep yang kami tampilkan di halaman ini. Harapan kami, olahan Palai bada yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman ataupun menjadi ide dalam berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
