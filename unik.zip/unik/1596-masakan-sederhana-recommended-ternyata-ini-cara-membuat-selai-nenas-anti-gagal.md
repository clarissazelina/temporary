---
description: "RECOMMENDED! Ternyata Ini Cara Membuat Selai Nenas Anti Gagal"
title: "RECOMMENDED! Ternyata Ini Cara Membuat Selai Nenas Anti Gagal"
slug: 1596-masakan-sederhana-recommended-ternyata-ini-cara-membuat-selai-nenas-anti-gagal
date: 2020-09-09T12:53:44.562Z
image: https://img-global.cpcdn.com/recipes/1960f05eba9107b6/751x532cq70/selai-nenas-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/1960f05eba9107b6/751x532cq70/selai-nenas-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/1960f05eba9107b6/751x532cq70/selai-nenas-foto-resep-utama.jpg
author: Cameron Rios
ratingvalue: 4.9
reviewcount: 11
recipeingredient:
- "2 buah nenas uksedang"
- "1 buah pepaya"
- "500 gula pasir"
- "1 sdt kayu manis bubuk"
- "3 biji cengkeh aku ga pake"
recipeinstructions:
- "Kupas dan potong2 pepaya dan nenas."
- "Blender tapi jangan terlalu halus, aku pakai mode chopper sja biar tetap ada teksturnya."
- "Masak hingga air menyusut, masukkan gula pasir dan bubuk kayu manis."
- "Aduk hingga lengket. Dinginkan. (kalau sudah dingin gampang dibulatkan)"
categories:
- Resep
tags:
- selai
- nenas

katakunci: selai nenas 
nutrition: 220 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT37M"
recipeyield: "3"
recipecategory: Dessert

---


![Selai Nenas](https://img-global.cpcdn.com/recipes/1960f05eba9107b6/751x532cq70/selai-nenas-foto-resep-utama.jpg)

Anda sedang mencari ide resep selai nenas yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal selai nenas yang enak seharusnya memiliki aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas, pertama dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan selai nenas enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.


Berikut ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah selai nenas yang siap dikreasikan. Anda dapat menyiapkan Selai Nenas menggunakan 5 jenis bahan dan 4 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Selai Nenas:

1. Gunakan 2 buah nenas uk.sedang
1. Siapkan 1 buah pepaya
1. Ambil 500 gula pasir
1. Siapkan 1 sdt kayu manis bubuk
1. Sediakan 3 biji cengkeh (aku ga pake)




##### Langkah-langkah membuat Selai Nenas:

1. Kupas dan potong2 pepaya dan nenas.
1. Blender tapi jangan terlalu halus, aku pakai mode chopper sja biar tetap ada teksturnya.
1. Masak hingga air menyusut, masukkan gula pasir dan bubuk kayu manis.
1. Aduk hingga lengket. Dinginkan. (kalau sudah dingin gampang dibulatkan)




Gimana nih? Gampang kan? Itulah cara menyiapkan selai nenas yang bisa Anda praktikkan di rumah. Selamat mencoba!
