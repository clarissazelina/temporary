---
description: "RECOMMENDED! Inilah Resep Rahasia Sroto Sokaraja Gampang Banget"
title: "RECOMMENDED! Inilah Resep Rahasia Sroto Sokaraja Gampang Banget"
slug: 1622-masakan-sederhana-recommended-inilah-resep-rahasia-sroto-sokaraja-gampang-banget
date: 2020-07-16T20:52:27.213Z
image: https://img-global.cpcdn.com/recipes/fcc71bbe09a4383e/751x532cq70/sroto-sokaraja-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/fcc71bbe09a4383e/751x532cq70/sroto-sokaraja-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/fcc71bbe09a4383e/751x532cq70/sroto-sokaraja-foto-resep-utama.jpg
author: Tony Patton
ratingvalue: 4.5
reviewcount: 6
recipeingredient:
- "  Bahan utama"
- "1 ekor ayam kampung"
- "250 gram kecambah rendam dengan air panas tiriskan"
- "250 gram daun kol potong  potong"
- "3 batang sledri potong  potong"
- "2 batang daun bawang potong  potong"
- "3 bks Soun rendam air hangat bilas tiriskan"
- "1 siung bombay potong  potong"
- "4 lembar daun salam"
- "3 batang sereh geprek"
- "5 lembar daun jeruk"
- "1 ruas lengkuas geprek"
- "2 sdm gula merah"
- "1 sdm garam"
- "2 buah tomat potong  potong"
- " Bawang goreng"
- " Krupuk merah goreng"
- "1,5 liter Air"
- " Lontong"
- " Kecap"
- "  Bumbu halus"
- "10 siung bawang putih"
- "6 siung bawang merah"
- "1 ruas kunyit"
- "1 ruas jahe"
- "1 sdt ketumbar"
- "1/2 sdt lada"
- "5 butir kemiri"
- "  Bumbu sambal cabe"
- "5 siung Bawang merah rebus"
- "2 siung Bawang putih rebus"
- "5 buah Cabe rawit merah"
- "8 buah Cabe kriting merah"
- "  Bumbu sambal kacang"
- "250 gram Kacang tanah sangrai"
- "150 gram Gula merah"
- "100 ml Air asem jawa"
recipeinstructions:
- "Goreng bumbu halus, lalu haluskan. Tumis serta masukkan daun salam, sereh, daun jeruk dan lengkuas. Tumis sampai matang."
- "Siapkan panci presto, masukkan air, ayam yang sudah dicuci, bumbu yang sudah ditumis, daun bawang, bombay, dan gula merah. Aduk dan tutup, masak kurang lebih 1 jam."
- "Keluarkan ayam, bisa digoreng atau tidak, lalu suwir kecil - kecil."
- "Rebus bumbu sambal cabe, lalu haluskan. Lalu ulek kasar bumbu sambal kacang."
- "Racik semua bahan dalam mangkok, mulai dari soun, irisan daun kol, kecambah, ayam suwir, sledri, krupuk, bawang goreng, tomat, sambal kacang, sambal cabe, kecap. Tuangkan kuah soto, dan beri perasan jeruk nipis. Sajikan dengan lontong"
categories:
- Resep
tags:
- sroto
- sokaraja

katakunci: sroto sokaraja 
nutrition: 165 calories
recipecuisine: Indonesian
preptime: "PT33M"
cooktime: "PT35M"
recipeyield: "1"
recipecategory: Dinner

---


![Sroto Sokaraja](https://img-global.cpcdn.com/recipes/fcc71bbe09a4383e/751x532cq70/sroto-sokaraja-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep sroto sokaraja yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal sroto sokaraja yang enak seharusnya memiliki aroma dan rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sroto sokaraja, pertama dari jenis bahan, selanjutnya pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan sroto sokaraja enak di rumah, karena asal sudah tahu triknya maka hidangan ini dapat jadi suguhan istimewa.

Soto Sokaraja; sroto Sokaraja nyaéta soto anu dijieun kalawan mibanda ciri anu mandiri ti kota Sokaraja, Banyumas, Jawa Tengah. Sarérét mah ieu soto sarua baé kawas soto hayam séjéna, pédah dina rasana béda tinu lian alatan maké campuran sambél suuk tur didaharna maké kupat. Не пользуетесь Твиттером? Регистрация. Soto Sokaraja & Mendoan Om Puj.


Nah, kali ini kita coba, yuk, ciptakan sroto sokaraja sendiri di rumah. Tetap berbahan sederhana, hidangan ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa menyiapkan Sroto Sokaraja menggunakan 37 bahan dan 5 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk membuat Sroto Sokaraja:

1. Sediakan  ✅ Bahan utama
1. Siapkan 1 ekor ayam kampung
1. Siapkan 250 gram kecambah (rendam dengan air panas, tiriskan)
1. Siapkan 250 gram daun kol (potong - potong)
1. Ambil 3 batang sledri (potong - potong)
1. Gunakan 2 batang daun bawang (potong - potong)
1. Sediakan 3 bks Soun (rendam air hangat, bilas, tiriskan)
1. Gunakan 1 siung bombay (potong - potong)
1. Ambil 4 lembar daun salam
1. Siapkan 3 batang sereh geprek
1. Siapkan 5 lembar daun jeruk
1. Ambil 1 ruas lengkuas geprek
1. Sediakan 2 sdm gula merah
1. Ambil 1 sdm garam
1. Sediakan 2 buah tomat (potong - potong)
1. Gunakan  Bawang goreng
1. Gunakan  Krupuk merah goreng
1. Gunakan 1,5 liter Air
1. Siapkan  Lontong
1. Gunakan  Kecap
1. Sediakan  ✅ Bumbu halus
1. Sediakan 10 siung bawang putih
1. Ambil 6 siung bawang merah
1. Ambil 1 ruas kunyit
1. Gunakan 1 ruas jahe
1. Gunakan 1 sdt ketumbar
1. Sediakan 1/2 sdt lada
1. Siapkan 5 butir kemiri
1. Gunakan  ✅ Bumbu sambal cabe
1. Gunakan 5 siung Bawang merah rebus
1. Gunakan 2 siung Bawang putih rebus
1. Gunakan 5 buah Cabe rawit merah
1. Ambil 8 buah Cabe kriting merah
1. Siapkan  ✅ Bumbu sambal kacang
1. Sediakan 250 gram Kacang tanah sangrai
1. Sediakan 150 gram Gula merah
1. Gunakan 100 ml Air asem jawa


Soto (also known as sroto, tauto, saoto, or coto) is a traditional Indonesian soup mainly composed of broth, meat, and vegetables. Many traditional soups are called soto. Beberapa kali aku mau makan di sana selalu kehabisan saja. Dan soto Sokaraja ini ada dua jenis yaitu yang mengunakan daging ayam dan yang menggunakan daging sapi. 

##### Cara meracik Sroto Sokaraja:

1. Goreng bumbu halus, lalu haluskan. Tumis serta masukkan daun salam, sereh, daun jeruk dan lengkuas. Tumis sampai matang.
1. Siapkan panci presto, masukkan air, ayam yang sudah dicuci, bumbu yang sudah ditumis, daun bawang, bombay, dan gula merah. Aduk dan tutup, masak kurang lebih 1 jam.
1. Keluarkan ayam, bisa digoreng atau tidak, lalu suwir kecil - kecil.
1. Rebus bumbu sambal cabe, lalu haluskan. Lalu ulek kasar bumbu sambal kacang.
1. Racik semua bahan dalam mangkok, mulai dari soun, irisan daun kol, kecambah, ayam suwir, sledri, krupuk, bawang goreng, tomat, sambal kacang, sambal cabe, kecap. Tuangkan kuah soto, dan beri perasan jeruk nipis. Sajikan dengan lontong


Resep Soto Sokaraja - pada kesempatan kali ini kami sajikan resep soto sokaraja, berbagai macam soto di indonesia Soto Kediri, soto Madura, Soto Lamongan. Soto Sokaraja, nama yang sudah sangat terkenal. Diantara soto Sokaraja yang terkenal itu, banyak yang terpampang jelas di pinggir jalan raya Sokaraja, diantaranya Soto Lama dan Soto Kecik. soto sokaraja adalah terletak di Desa Pancurendang. soto sokaraja - Desa Pancurendang pada peta. Soto Sokaraja, merupakan salah satu makanan khas tradisional Indonesia dari daerah yang bernama Sokaraja, Purwokerto. Soto memang sering dinamai sesuai nama tempat awal dimana soto itu lahir. 

Terima kasih telah membaca resep yang kami tampilkan di sini. Besar harapan kami, olahan Sroto Sokaraja yang mudah di atas dapat membantu Anda menyiapkan hidangan yang menarik untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
