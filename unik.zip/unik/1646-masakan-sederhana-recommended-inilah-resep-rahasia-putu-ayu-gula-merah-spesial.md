---
description: "RECOMMENDED! Inilah Resep Rahasia Putu ayu gula merah Spesial"
title: "RECOMMENDED! Inilah Resep Rahasia Putu ayu gula merah Spesial"
slug: 1646-masakan-sederhana-recommended-inilah-resep-rahasia-putu-ayu-gula-merah-spesial
date: 2020-07-27T15:59:45.502Z
image: https://img-global.cpcdn.com/recipes/e6f9c54da2e54417/751x532cq70/putu-ayu-gula-merah-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/e6f9c54da2e54417/751x532cq70/putu-ayu-gula-merah-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/e6f9c54da2e54417/751x532cq70/putu-ayu-gula-merah-foto-resep-utama.jpg
author: Sarah Watts
ratingvalue: 5
reviewcount: 15
recipeingredient:
- "150 gr tepung trigu"
- "2 butir telur"
- "130 gr gula merah sisir halus"
- "1/2 sdt sp"
- "125 ml santan kekentalan sedang"
- "1 sashet vanili bubuk"
- "100 gr kelapa parut"
recipeinstructions:
- "Kukus 15 menit kelapa parut beri sedikit garam (aduk rata). Masukan dalam cetakan yang sudah di oles minyak tipis2."
- "Mixer gula merah, telur, dan sp sampai lembut berwarna pucat, masukan vanili tepung trigu dan santan bergantian mixer dengan speed rendah adal rata, matikan."
- "Masukan adonan ke dalam cetakan yang sudah berisi kelapa parut, kukus selama 15-20 menit (kukusan sebelumnya sudah harus di panaskan terlebih dahulu, alasi tutup dengan kain bersih)."
categories:
- Resep
tags:
- putu
- ayu
- gula

katakunci: putu ayu gula 
nutrition: 241 calories
recipecuisine: Indonesian
preptime: "PT26M"
cooktime: "PT32M"
recipeyield: "1"
recipecategory: Lunch

---


![Putu ayu gula merah](https://img-global.cpcdn.com/recipes/e6f9c54da2e54417/751x532cq70/putu-ayu-gula-merah-foto-resep-utama.jpg)

Sedang mencari inspirasi resep putu ayu gula merah yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal putu ayu gula merah yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari putu ayu gula merah, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau mau menyiapkan putu ayu gula merah yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan spesial.

Kue tradisional seperti ini cocok untuk hidangan dalam acara-acara tertentu. Sampai saat ini, kue basah tradisional banyak sekali penggemarnya salah satunya yaitu kue putu ayu. Banyak sekali variasi dari kue putu ayu,mulai dari kue.


Nah, kali ini kita coba, yuk, siapkan putu ayu gula merah sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Putu ayu gula merah memakai 7 jenis bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah untuk membuat hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Putu ayu gula merah:

1. Siapkan 150 gr tepung trigu
1. Gunakan 2 butir telur
1. Sediakan 130 gr gula merah (sisir halus)
1. Siapkan 1/2 sdt sp
1. Siapkan 125 ml santan kekentalan sedang
1. Siapkan 1 sashet vanili bubuk
1. Sediakan 100 gr kelapa parut


Cara membuat putu ayu gula merah : Campurkan kelapa parut dan garam hingga merata sempurna. Kemudian masukkan ke dasar cetakan putu ayu yang sudah disiapkan, boleh juga di beri tambahan minyak sebelum di beri parutan kelapa, agak tekan agar parutan kelapa rapi. Isian gula merah bisa diganti dengan keju atau coklat sehingga jika dikonsumsi saat masih panas coklat atau keju meleleh. Kue Putu adalah makanan ringan yang biasa dikonsumsi oleh masyarakat Indonesia. 

##### Langkah-langkah membuat Putu ayu gula merah:

1. Kukus 15 menit kelapa parut beri sedikit garam (aduk rata). Masukan dalam cetakan yang sudah di oles minyak tipis2.
1. Mixer gula merah, telur, dan sp sampai lembut berwarna pucat, masukan vanili tepung trigu dan santan bergantian mixer dengan speed rendah adal rata, matikan.
1. Masukan adonan ke dalam cetakan yang sudah berisi kelapa parut, kukus selama 15-20 menit (kukusan sebelumnya sudah harus di panaskan terlebih dahulu, alasi tutup dengan kain bersih).


Kue putu ayu merupakah jenis kue basah tradisional Indonesia yang cukup spesial. Selain menggunakan gula merah, kue putu ayu juga bisa dibuat dengan menggunakan resep putu ayu biasa hijau. Kue putu ayu sebenarnya merupakan hasil kreasi para ibu ibu masa kini, sebab sebelumnya kita hanya mengenal kue putu tepung beras yang berwarna putih menarik yang di dalamnya berisi gula merah sisir. Masukan tepung beras dan tepung terigu sambil diayak, bergantian dengan campuran air Baca Juga: Resep Putu Ayu Untuk Jualan: Contek Resep Putu Ayu Wijen Hitam Super Lembut Ini. Baca Juga: Menu Takjil Buka Puasa Untuk. 

Gimana nih? Mudah bukan? Itulah cara membuat putu ayu gula merah yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
