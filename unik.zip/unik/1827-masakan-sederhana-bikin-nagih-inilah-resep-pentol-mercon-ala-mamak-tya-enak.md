---
description: "BIKIN NAGIH! Inilah Resep Pentol Mercon Ala Mamak Tya Enak"
title: "BIKIN NAGIH! Inilah Resep Pentol Mercon Ala Mamak Tya Enak"
slug: 1827-masakan-sederhana-bikin-nagih-inilah-resep-pentol-mercon-ala-mamak-tya-enak
date: 2020-04-08T17:10:58.147Z
image: https://img-global.cpcdn.com/recipes/937a2a644ba1dfbe/751x532cq70/pentol-mercon-ala-mamak-tya-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/937a2a644ba1dfbe/751x532cq70/pentol-mercon-ala-mamak-tya-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/937a2a644ba1dfbe/751x532cq70/pentol-mercon-ala-mamak-tya-foto-resep-utama.jpg
author: Jack Lane
ratingvalue: 4.4
reviewcount: 7
recipeingredient:
- "300 gram  Bakso Sapi"
- " Bumbu Halus"
- "8 siung bawang merah"
- "4 siung bawang putih"
- "40 buah cabe rawit"
- "2 butir kemiri"
- "1 buah tomat"
- " Pelengkap "
- "Secukupnya lengkuas digeprek"
- "1 lembar daun salam"
- "4 lembar daun jeruk"
- "secukupnya Garam Merica Kaldu sapi dan micin"
recipeinstructions:
- "Haluskan semua bahan bumbu halus"
- "Panaskan minyak dalam wajan, lalu tumis bumbu yang telah dihaluskan sampai matang. Jangan lupa masukkan lengkuas, daun jeruk dan daun salam"
- "Setelah itu masukkan bakso sapi kedalam tumisan bumbu. Tambahkan garam, merica, kaldu sapi dan micin secukupnya. Kalau ga suka micin boleh di skip micinnya"
- "Lalu masak hingga matang dan bumbu menyerap sempurna. Sajikan hangat² bersama nasi hangat. Selamat mencoba 🤤🤤🤤🤤🤤"
categories:
- Resep
tags:
- pentol
- mercon
- ala

katakunci: pentol mercon ala 
nutrition: 242 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT49M"
recipeyield: "4"
recipecategory: Lunch

---


![Pentol Mercon Ala Mamak Tya](https://img-global.cpcdn.com/recipes/937a2a644ba1dfbe/751x532cq70/pentol-mercon-ala-mamak-tya-foto-resep-utama.jpg)

Lagi mencari inspirasi resep pentol mercon ala mamak tya yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pentol mercon ala mamak tya yang enak harusnya sih punya aroma dan rasa yang dapat memancing selera kita.



Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari pentol mercon ala mamak tya, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tak perlu pusing kalau mau menyiapkan pentol mercon ala mamak tya yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Berikut ini ada beberapa tips dan trik praktis untuk membuat pentol mercon ala mamak tya yang siap dikreasikan. Anda bisa menyiapkan Pentol Mercon Ala Mamak Tya menggunakan 12 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Pentol Mercon Ala Mamak Tya:

1. Siapkan 300 gram ± Bakso Sapi
1. Ambil  Bumbu Halus
1. Sediakan 8 siung bawang merah
1. Ambil 4 siung bawang putih
1. Siapkan 40 buah cabe rawit
1. Gunakan 2 butir kemiri
1. Gunakan 1 buah tomat
1. Ambil  Pelengkap :
1. Ambil Secukupnya lengkuas digeprek
1. Sediakan 1 lembar daun salam
1. Gunakan 4 lembar daun jeruk
1. Sediakan secukupnya Garam, Merica, Kaldu sapi, dan micin




##### Cara meracik Pentol Mercon Ala Mamak Tya:

1. Haluskan semua bahan bumbu halus
1. Panaskan minyak dalam wajan, lalu tumis bumbu yang telah dihaluskan sampai matang. Jangan lupa masukkan lengkuas, daun jeruk dan daun salam
1. Setelah itu masukkan bakso sapi kedalam tumisan bumbu. Tambahkan garam, merica, kaldu sapi dan micin secukupnya. Kalau ga suka micin boleh di skip micinnya
1. Lalu masak hingga matang dan bumbu menyerap sempurna. Sajikan hangat² bersama nasi hangat. Selamat mencoba 🤤🤤🤤🤤🤤




Bagaimana? Gampang kan? Itulah cara menyiapkan pentol mercon ala mamak tya yang bisa Anda lakukan di rumah. Selamat mencoba!
