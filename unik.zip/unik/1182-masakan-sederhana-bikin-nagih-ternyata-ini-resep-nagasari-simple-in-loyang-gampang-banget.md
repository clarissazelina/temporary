---
description: "BIKIN NAGIH! Ternyata Ini Resep Nagasari Simple in Loyang Gampang Banget"
title: "BIKIN NAGIH! Ternyata Ini Resep Nagasari Simple in Loyang Gampang Banget"
slug: 1182-masakan-sederhana-bikin-nagih-ternyata-ini-resep-nagasari-simple-in-loyang-gampang-banget
date: 2020-09-11T17:56:09.412Z
image: https://img-global.cpcdn.com/recipes/c8d31155ed2b1c82/751x532cq70/nagasari-simple-in-loyang-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/c8d31155ed2b1c82/751x532cq70/nagasari-simple-in-loyang-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/c8d31155ed2b1c82/751x532cq70/nagasari-simple-in-loyang-foto-resep-utama.jpg
author: Stephen Shaw
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- "650 ml santan"
- "140 gr gula pasir"
- "2-3 lembar daun pandan"
- "1/2 sdt garam"
- "180 gr tepung beras 160 gr aja kalo mau lebih lunak"
- "75 gr tepung tapioka 60 gr aja untuk lebih lunak"
- "2-3 buah pisang saya pakai pisang nangka"
recipeinstructions:
- "Masak santan, gula, garam, daun pandan hingga mendidik sambil diaduk terus. Kemudian dinginkan pada suhu ruang."
- "Siapkan kukusan dan cetakan loyang. Campurkan tepung terigu dan tepung tapioka. Kemudian masukkan santan sedikit demi sedikit. Aduk dengan whisk hingga tercampur rata dan tidak ada yg menggumpal."
- "Potong-pisang untuk isian. Oles sedikit mentega pada loyang, khawatir lengket. Masukkan adonan pertama tipis, susun pisang lapisan pertama, tutup kukusan. tunggu agak mengental. Masukkan lagi adonan dan Pisang lapisan berikutnya. Ulangi hingga habis. Tunggu matang."
categories:
- Resep
tags:
- nagasari
- simple
- in

katakunci: nagasari simple in 
nutrition: 206 calories
recipecuisine: Indonesian
preptime: "PT36M"
cooktime: "PT40M"
recipeyield: "3"
recipecategory: Dessert

---


![Nagasari Simple in Loyang](https://img-global.cpcdn.com/recipes/c8d31155ed2b1c82/751x532cq70/nagasari-simple-in-loyang-foto-resep-utama.jpg)

Sedang mencari ide resep nagasari simple in loyang yang unik? Cara menyiapkannya memang susah-susah gampang. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal nagasari simple in loyang yang enak seharusnya mempunyai aroma dan cita rasa yang mampu memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari nagasari simple in loyang, mulai dari jenis bahan, kemudian pemilihan bahan segar, hingga cara membuat dan menghidangkannya. Tidak usah pusing jika ingin menyiapkan nagasari simple in loyang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat jadi sajian istimewa.




Berikut ini ada beberapa cara mudah dan praktis dalam mengolah nagasari simple in loyang yang siap dikreasikan. Anda bisa menyiapkan Nagasari Simple in Loyang memakai 7 bahan dan 3 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk meracik Nagasari Simple in Loyang:

1. Siapkan 650 ml santan
1. Gunakan 140 gr gula pasir
1. Siapkan 2-3 lembar daun pandan
1. Gunakan 1/2 sdt garam
1. Sediakan 180 gr tepung beras (160 gr aja kalo mau lebih lunak)
1. Gunakan 75 gr tepung tapioka (60 gr aja untuk lebih lunak)
1. Siapkan 2-3 buah pisang (saya pakai pisang nangka)




##### Langkah-langkah meracik Nagasari Simple in Loyang:

1. Masak santan, gula, garam, daun pandan hingga mendidik sambil diaduk terus. Kemudian dinginkan pada suhu ruang.
1. Siapkan kukusan dan cetakan loyang. Campurkan tepung terigu dan tepung tapioka. Kemudian masukkan santan sedikit demi sedikit. Aduk dengan whisk hingga tercampur rata dan tidak ada yg menggumpal.
1. Potong-pisang untuk isian. Oles sedikit mentega pada loyang, khawatir lengket. Masukkan adonan pertama tipis, susun pisang lapisan pertama, tutup kukusan. tunggu agak mengental. Masukkan lagi adonan dan Pisang lapisan berikutnya. Ulangi hingga habis. Tunggu matang.




Gimana nih? Gampang kan? Itulah cara membuat nagasari simple in loyang yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
