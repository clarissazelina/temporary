---
description: "TERUNGKAP! Inilah Cara Membuat Palai bada Enak"
title: "TERUNGKAP! Inilah Cara Membuat Palai bada Enak"
slug: 1318-masakan-sederhana-terungkap-inilah-cara-membuat-palai-bada-enak
date: 2020-07-07T05:54:40.193Z
image: https://img-global.cpcdn.com/recipes/32764b3b994373f2/751x532cq70/palai-bada-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/32764b3b994373f2/751x532cq70/palai-bada-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/32764b3b994373f2/751x532cq70/palai-bada-foto-resep-utama.jpg
author: Rodney Park
ratingvalue: 3.1
reviewcount: 13
recipeingredient:
- "1/2 ikan teri basah"
- "1/2 kelapa parut"
- "Segenggam daun kemangi"
- " Daun pisang untuk membungkus"
- " Bumbu"
- "15 buah cabe merah"
- "12 buah cabe rawit"
- "7 siung bawang merah"
- "5 siung bawang putih"
- "1 cm kunyit"
- "1 cm jahe"
- "1 sdm garam"
- "1/2 sdm gula pasir"
- "1 buah jeruk nipis"
recipeinstructions:
- "Bersihkan ikan teri basah dari kotoran, cuci bersih tiriskan. Beri perasan jeruk nipis"
- "Haluskan smua bumbu, campur dengan kelapa parut lalu remas2 biar bumbu dan kelapa merata, tes rasa bila dirasa sudah pas tambahkan ikan teri basah aduk rata"
- "Siapkan daun pisang yg sudah di lap, taruh daun kemangi lalu taruh 2 sendok adonan palai di atas daun pisang lalu bungkus seperti lontong dan sematkan kedua ujungnya dengan lidi"
- "Bakar diatas teflon dengan api kecil,, sesekali dibalik supaya matang merata,, (saya sampai 45 menit)"
- "Palai siap disajikan menemani nasi hangat"
categories:
- Resep
tags:
- palai
- bada

katakunci: palai bada 
nutrition: 247 calories
recipecuisine: Indonesian
preptime: "PT38M"
cooktime: "PT46M"
recipeyield: "3"
recipecategory: Dessert

---


![Palai bada](https://img-global.cpcdn.com/recipes/32764b3b994373f2/751x532cq70/palai-bada-foto-resep-utama.jpg)

Sedang mencari ide resep palai bada yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal palai bada yang enak selayaknya punya aroma dan cita rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari palai bada, mulai dari jenis bahan, lalu pemilihan bahan segar, hingga cara mengolah dan menyajikannya. Tidak usah pusing kalau mau menyiapkan palai bada yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian istimewa.

Palai bada adalah salah satu hidangan yang berasal dari Sumatra Barat. Hidangan ini menggunakan ikan teri sebagai bahan utamanya, yang oleh penduduk setempat disebut dengan \"ikan bada\" atau \"maco bada\" (dalam bentuk ikan asin). Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\".


Nah, kali ini kita coba, yuk, ciptakan palai bada sendiri di rumah. Tetap dengan bahan sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Palai bada memakai 14 jenis bahan dan 5 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Palai bada:

1. Sediakan 1/2 ikan teri basah
1. Gunakan 1/2 kelapa parut
1. Siapkan Segenggam daun kemangi
1. Gunakan  Daun pisang untuk membungkus
1. Ambil  Bumbu
1. Gunakan 15 buah cabe merah
1. Siapkan 12 buah cabe rawit
1. Sediakan 7 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Gunakan 1 cm kunyit
1. Siapkan 1 cm jahe
1. Siapkan 1 sdm garam
1. Siapkan 1/2 sdm gula pasir
1. Ambil 1 buah jeruk nipis


Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. Palai bada, a Minangkabau dish made of fish, coconut and spices, wrapped in bananaleaf and \"barbecued\". On the left: palai bada balado; on the right: palai bada. 

##### Langkah-langkah membuat Palai bada:

1. Bersihkan ikan teri basah dari kotoran, cuci bersih tiriskan. Beri perasan jeruk nipis
1. Haluskan smua bumbu, campur dengan kelapa parut lalu remas2 biar bumbu dan kelapa merata, tes rasa bila dirasa sudah pas tambahkan ikan teri basah aduk rata
1. Siapkan daun pisang yg sudah di lap, taruh daun kemangi lalu taruh 2 sendok adonan palai di atas daun pisang lalu bungkus seperti lontong dan sematkan kedua ujungnya dengan lidi
1. Bakar diatas teflon dengan api kecil,, sesekali dibalik supaya matang merata,, (saya sampai 45 menit)
1. Palai siap disajikan menemani nasi hangat


Palai Bada (Pepes Teri Basah) terbuat dari ikan teri basah yang dicampur dengan parutan kelapa, serta beragam bumbu seperti daun kunyit, daun serei, lengkuas, asam, dan lainnya. Semua lagu disini hanya untuk review saja, Jika kamu suka lagu Palai Bada belilah CD original. Yo … palai bada, lamak rasonyo makan baduo Yo … palai bada, lamak rasonyo makan baduo. Urang Rao pai ka danau Ambiak rumpuik si bilang-bilang Yo kok tuan indak picayo Bali sabungkuih baok. Palai Bada sprot met kruiden gegrild in bananenblad. 

Gimana nih? Gampang kan? Itulah cara membuat palai bada yang bisa Anda lakukan di rumah. Selamat mencoba!
