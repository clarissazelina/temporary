---
description: "BIKIN NGILER! Inilah Resep Rahasia 30. Cenil Pelangi Enak"
title: "BIKIN NGILER! Inilah Resep Rahasia 30. Cenil Pelangi Enak"
slug: 1406-masakan-sederhana-bikin-ngiler-inilah-resep-rahasia-30-cenil-pelangi-enak
date: 2020-09-21T18:36:44.642Z
image: https://img-global.cpcdn.com/recipes/808b30cb0e6db042/751x532cq70/30-cenil-pelangi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/808b30cb0e6db042/751x532cq70/30-cenil-pelangi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/808b30cb0e6db042/751x532cq70/30-cenil-pelangi-foto-resep-utama.jpg
author: Mike Rhodes
ratingvalue: 3.2
reviewcount: 14
recipeingredient:
- "3 kg singkong"
- "3 bungkus nutrijel rasa melon jambu biji leci"
- "1 kg gula pasir"
- "3 gelas air"
- " pewarna sesuai selera"
- " Kelapa parut secukupnya"
recipeinstructions:
- "Kupas dan cuci bersih singkong kemudian parut singkong hingga halus. campurkan adonan singkong dengan 1kg gula pasir"
- "Bagi adonan menjadi 3bagian, beri nutrijel dan campurkan hingga rata (aku pakai nutrijel rasa, leci, jambu biji, melon)"
- "Beri pewarna sesuai selera dan beri air. Masing-masing adonan beri air 1 gelas. Kemudian aduk kembali hingga tercampur rata"
- "Siapkan loyang/wadah untuk mengkukus adonan. Kukus selama 30 menit (sampai matang)"
- "Jika sudah matang. Angkat lalu diamkan sampai dingin"
- "Kalau sudah dingin bisa di iris-iris, lalu campurkan dengan kelapa parut yg sudah di kukus"
- "Selalu ketagihan kalau buat ini, enak bgt, selamat mencoba:)"
categories:
- Resep
tags:
- 30
- cenil
- pelangi

katakunci: 30 cenil pelangi 
nutrition: 108 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT60M"
recipeyield: "4"
recipecategory: Lunch

---


![30. Cenil Pelangi](https://img-global.cpcdn.com/recipes/808b30cb0e6db042/751x532cq70/30-cenil-pelangi-foto-resep-utama.jpg)

Anda sedang mencari inspirasi resep 30. cenil pelangi yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal 30. cenil pelangi yang enak selayaknya mempunyai aroma dan rasa yang dapat memancing selera kita.



Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari 30. cenil pelangi, mulai dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menyajikannya. Tidak usah pusing jika hendak menyiapkan 30. cenil pelangi enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Di bawah ini ada beberapa cara mudah dan praktis yang dapat diterapkan untuk mengolah 30. cenil pelangi yang siap dikreasikan. Anda bisa menyiapkan 30. Cenil Pelangi memakai 6 bahan dan 7 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan untuk membuat 30. Cenil Pelangi:

1. Siapkan 3 kg singkong
1. Sediakan 3 bungkus nutrijel (rasa melon, jambu biji, leci)
1. Ambil 1 kg gula pasir
1. Gunakan 3 gelas air
1. Sediakan  pewarna (sesuai selera)
1. Siapkan  Kelapa parut (secukupnya)




##### Cara mengolah 30. Cenil Pelangi:

1. Kupas dan cuci bersih singkong kemudian parut singkong hingga halus. campurkan adonan singkong dengan 1kg gula pasir
1. Bagi adonan menjadi 3bagian, beri nutrijel dan campurkan hingga rata (aku pakai nutrijel rasa, leci, jambu biji, melon)
1. Beri pewarna sesuai selera dan beri air. Masing-masing adonan beri air 1 gelas. Kemudian aduk kembali hingga tercampur rata
1. Siapkan loyang/wadah untuk mengkukus adonan. Kukus selama 30 menit (sampai matang)
1. Jika sudah matang. Angkat lalu diamkan sampai dingin
1. Kalau sudah dingin bisa di iris-iris, lalu campurkan dengan kelapa parut yg sudah di kukus
1. Selalu ketagihan kalau buat ini, enak bgt, selamat mencoba:)




Bagaimana? Mudah bukan? Itulah cara membuat 30. cenil pelangi yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
