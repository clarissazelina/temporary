---
description: "BIKIN NGILER! Ternyata Ini Resep Glotak "
title: "BIKIN NGILER! Ternyata Ini Resep Glotak "
slug: 1314-masakan-sederhana-bikin-ngiler-ternyata-ini-resep-glotak
date: 2020-06-12T23:56:43.473Z
image: https://img-global.cpcdn.com/recipes/278c02f40dc2976e/751x532cq70/glotak-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/278c02f40dc2976e/751x532cq70/glotak-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/278c02f40dc2976e/751x532cq70/glotak-foto-resep-utama.jpg
author: Tillie Allen
ratingvalue: 5
reviewcount: 9
recipeingredient:
- "1 papan ampas tahu  menjes  gembus  dage tumbukhancurkan"
- "1/4 kg daging tetelan tulang sapi cekerkepalasayap ayam"
- "10 bh cabai hijau belah jadi 2"
- "20 bh cabai rawit sebagian utuh sebagian tumbuk kasar"
- " Santan encer boleh pakai boleh juga tidak sesuai selera"
- " Salam laos sereh"
- " Bumbu yang dihaluskan"
- "6 bh cabai merah"
- "3 bh bawang merah"
- "3 siung bawang putih"
- "1 sdt Ketumbar"
- "secukupnya Garam dan gula"
- " Minyak untuk menumis"
- " Bubuk kaldu jika perlu"
- " Pelengkap"
- " Taburan bawang merah goreng"
- " Krupuk mieantorpilus"
recipeinstructions:
- "Tumis bumbu yang dihaluskan tadi tambahkan pula potongan cabai hijau dan rawit, salam, laos, sereh sampai harum."
- "Masukkan daging. Tambahkan air supaya daging matang (tutup spya lbh cepat matang)."
- "Lalu masukkan ampas tahu/menjes/ gembus / dage."
- "Masukkan santan encer."
- "Masak hingga kuah mengental."
- "Glotak siap dihidangkan dengan krupuk mie sebagai cocolan. 😋😋😋"
categories:
- Resep
tags:
- glotak

katakunci: glotak 
nutrition: 255 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT58M"
recipeyield: "4"
recipecategory: Dinner

---


![Glotak](https://img-global.cpcdn.com/recipes/278c02f40dc2976e/751x532cq70/glotak-foto-resep-utama.jpg)

Sedang mencari ide resep glotak yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal glotak yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari glotak, pertama dari jenis bahan, kemudian pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan glotak enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.

Lokasinya sendiri berada di lereng Gunung Kawi. Glotak adalah makanan tradisional dari Tegal. Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya.


Nah, kali ini kita coba, yuk, buat glotak sendiri di rumah. Tetap berbahan sederhana, hidangan ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Glotak menggunakan 17 jenis bahan dan 6 langkah pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Glotak:

1. Gunakan 1 papan ampas tahu / menjes / gembus / dage, tumbuk/hancurkan
1. Ambil 1/4 kg daging tetelan/ tulang sapi/ ceker/kepala/sayap ayam
1. Ambil 10 bh cabai hijau, belah jadi 2
1. Siapkan 20 bh cabai rawit, sebagian utuh sebagian tumbuk kasar
1. Siapkan  Santan encer (boleh pakai, boleh juga tidak, sesuai selera)
1. Sediakan  Salam, laos, sereh
1. Ambil  Bumbu yang dihaluskan:
1. Sediakan 6 bh cabai merah
1. Gunakan 3 bh bawang merah
1. Ambil 3 siung bawang putih
1. Siapkan 1 sdt Ketumbar
1. Siapkan secukupnya Garam dan gula
1. Gunakan  Minyak untuk menumis
1. Ambil  Bubuk kaldu (jika perlu)
1. Ambil  Pelengkap:
1. Sediakan  Taburan bawang merah goreng
1. Sediakan  Krupuk mie/antor/pilus


Coban Glotak Wagir Malang, Keindahan Air Terjun Tersembunyi. Blog Diah Didi berisi resep masakan praktis yang mudah dipraktekkan di rumah. Coban Glotak, Track Tepat Bagi Jiwa Petualang. 

##### Langkah-langkah menyiapkan Glotak:

1. Tumis bumbu yang dihaluskan tadi tambahkan pula potongan cabai hijau dan rawit, salam, laos, sereh sampai harum.
1. Masukkan daging. Tambahkan air supaya daging matang (tutup spya lbh cepat matang).
1. Lalu masukkan ampas tahu/menjes/ gembus / dage.
1. Masukkan santan encer.
1. Masak hingga kuah mengental.
1. Glotak siap dihidangkan dengan krupuk mie sebagai cocolan. 😋😋😋




Gimana nih? Gampang kan? Itulah cara membuat glotak yang bisa Anda praktikkan di rumah. Semoga bermanfaat dan selamat mencoba!
