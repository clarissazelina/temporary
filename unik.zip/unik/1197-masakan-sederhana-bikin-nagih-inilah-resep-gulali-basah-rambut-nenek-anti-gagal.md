---
description: "BIKIN NAGIH! Inilah Resep Gulali Basah Rambut Nenek Anti Gagal"
title: "BIKIN NAGIH! Inilah Resep Gulali Basah Rambut Nenek Anti Gagal"
slug: 1197-masakan-sederhana-bikin-nagih-inilah-resep-gulali-basah-rambut-nenek-anti-gagal
date: 2020-05-21T11:33:36.313Z
image: https://img-global.cpcdn.com/recipes/16a9ec3c423f3763/751x532cq70/gulali-basah-rambut-nenek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/16a9ec3c423f3763/751x532cq70/gulali-basah-rambut-nenek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/16a9ec3c423f3763/751x532cq70/gulali-basah-rambut-nenek-foto-resep-utama.jpg
author: Sean Freeman
ratingvalue: 3.2
reviewcount: 6
recipeingredient:
- " Bahan A"
- "250 gr Tepung ketan atau tepung gandum atau tepung terigu atau tepung beras atau tepung jagung juga boleh"
- "2 sdm susu bubuk opsional"
- " Bahan B"
- "250 gr gula pasir"
- "200 ml air"
- " Pewarna makanan sesuai selera bisa dilewatkan"
- "1/4 sdt Citrun atau  sdt perasan jeruk nipis atau  sdt cuka"
recipeinstructions:
- "Sangrai bahan A sampai harum, matikan kompor. Selanjutnya tuang tepung terigu yang sudah disangrai tersebut ke atas wadah yang lebar seperti loyang untuk membuat kue. Taburkan dengan merata dan diamkan hingga panasnya menghilang. Sambil menunggu dingin, sekarang kita membuat adonan gulalinya."
- "Campurkan semua bahan B. Setelah itu masak menggunakan api sedang sambil terus diaduk sampai mendidih. Terus dimasak sampai berbusa dan agak kental kira-kira 8-10 menit. Tapi untuk sesi ini setelah mendidih, cukup aduk sesekali ya. Jadi kalau sudah mendidih jangan sering-sering diaduk agar gula tidak mengkristal."
- "TIPS: Untuk mengetahui apakah gulanya sudah cukup kental atau belum yaitu: ketika sudah mendidih dan berbusa. Matikan kompor, terus diaduk-aduk jika busanya cepat hilang berarti adonan masih cair jadi silahkan dimasak lagi. Tapi jika kompornya sudah mati, terus diaduk-aduk busanya lama menghilang berarti adonan sudah pas tingkat kekentalannya. Jadi bisa dikatakan sudah jadi Gulali."
- "Aduk hingga busa hilang dan menjadi bening. Angkat wajan tersebut lalu tuang adonan gulali panas ke wajan lain yang sudah ditempatkan diatas bak berisi air. Diamkan gulali hingga kental dan agak mengeras."
- "Setelah mengental dan agak mengeras ambil adonan secukupnya lalu bentuk melingkar seperti karet gelang. Lalu gulingkan ke atas tepung susu yang sudah disangrai tadi sambil terus lipat ulang dan dipilin ulang lalu ditarik. Jadi begitu terus hingga berbentuk menjadi seperti rambut nenek."
- "Seperti ini gambarannya..."
- "TIPS AND TRICK &gt;&gt; Penggunaaan susu bubuk itu opsional dan cukup sedikit saja. Jadi, penggunaan tepungnya tetep harus lebih banyak ya, karena jika kebanyakan menggunakan susu bubuk maka sebentar saja Gulali Rambut Neneknya jadi lengket dan menyatu lagi. Karena itu, kalau mau lebih awet dan kesat teksturnya silahkan dilewatkan saja penggunaan susu bubuknya."
- "Penggunaan citric acid harus sesuai takaran ya, karena jika kebanyakan ya hasilnya gulali jadi susah mengeras. Tapi jika dilewatkan juga Gulalinya jadi cepat mengeras. Karena itu pastikan sesuai takaran."
- "Karena ini jenis Gulali rambut nenek yang basah, bukan yang kering.. Jadi cara menyimpannya setelah dibentuk silahkan ditempatkan dimulut kita ya, alias langsung dimakan hehe.. tapi kalau mau dimakan nanti-nanti silahkan ditempatkan di wadah tertutup. Jika ingin membuat Rambut nenek jenis kering maka untuk lumurannya itu adonannya menggunakan campuran tepung dan minyak, tapi juga ada takarannya ya, ada tips dan triknya juga.Kapan-kapan saya bagikan juga yang versi Kering ya."
categories:
- Resep
tags:
- gulali
- basah
- rambut

katakunci: gulali basah rambut 
nutrition: 161 calories
recipecuisine: Indonesian
preptime: "PT12M"
cooktime: "PT54M"
recipeyield: "1"
recipecategory: Dinner

---


![Gulali Basah Rambut Nenek](https://img-global.cpcdn.com/recipes/16a9ec3c423f3763/751x532cq70/gulali-basah-rambut-nenek-foto-resep-utama.jpg)

Sedang mencari inspirasi resep gulali basah rambut nenek yang unik? Cara menyiapkannya memang tidak terlalu sulit namun tidak gampang juga. Kalau keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal gulali basah rambut nenek yang enak harusnya sih punya aroma dan cita rasa yang mampu memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari gulali basah rambut nenek, pertama dari jenis bahan, kemudian pemilihan bahan segar hingga cara mengolah dan menghidangkannya. Tak perlu pusing kalau hendak menyiapkan gulali basah rambut nenek enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat gulali basah rambut nenek sendiri di rumah. Tetap berbahan yang sederhana, hidangan ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Gulali Basah Rambut Nenek menggunakan 8 jenis bahan dan 9 tahap pembuatan. Berikut ini langkah-langkah untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam membuat Gulali Basah Rambut Nenek:

1. Siapkan  Bahan A
1. Gunakan 250 gr Tepung ketan, atau tepung gandum, atau tepung terigu atau tepung beras atau tepung jagung juga boleh
1. Siapkan 2 sdm. susu bubuk [opsional]
1. Gunakan  Bahan B
1. Gunakan 250 gr gula pasir
1. Ambil 200 ml air
1. Siapkan  Pewarna makanan sesuai selera [bisa dilewatkan]
1. Ambil 1/4 sdt Citrun atau ½ sdt perasan jeruk nipis atau ¼ sdt. cuka




##### Langkah-langkah membuat Gulali Basah Rambut Nenek:

1. Sangrai bahan A sampai harum, matikan kompor. Selanjutnya tuang tepung terigu yang sudah disangrai tersebut ke atas wadah yang lebar seperti loyang untuk membuat kue. Taburkan dengan merata dan diamkan hingga panasnya menghilang. Sambil menunggu dingin, sekarang kita membuat adonan gulalinya.
1. Campurkan semua bahan B. Setelah itu masak menggunakan api sedang sambil terus diaduk sampai mendidih. Terus dimasak sampai berbusa dan agak kental kira-kira 8-10 menit. Tapi untuk sesi ini setelah mendidih, cukup aduk sesekali ya. Jadi kalau sudah mendidih jangan sering-sering diaduk agar gula tidak mengkristal.
1. TIPS: Untuk mengetahui apakah gulanya sudah cukup kental atau belum yaitu: ketika sudah mendidih dan berbusa. Matikan kompor, terus diaduk-aduk jika busanya cepat hilang berarti adonan masih cair jadi silahkan dimasak lagi. Tapi jika kompornya sudah mati, terus diaduk-aduk busanya lama menghilang berarti adonan sudah pas tingkat kekentalannya. Jadi bisa dikatakan sudah jadi Gulali.
1. Aduk hingga busa hilang dan menjadi bening. Angkat wajan tersebut lalu tuang adonan gulali panas ke wajan lain yang sudah ditempatkan diatas bak berisi air. Diamkan gulali hingga kental dan agak mengeras.
1. Setelah mengental dan agak mengeras ambil adonan secukupnya lalu bentuk melingkar seperti karet gelang. Lalu gulingkan ke atas tepung susu yang sudah disangrai tadi sambil terus lipat ulang dan dipilin ulang lalu ditarik. Jadi begitu terus hingga berbentuk menjadi seperti rambut nenek.
1. Seperti ini gambarannya...
1. TIPS AND TRICK &gt;&gt; Penggunaaan susu bubuk itu opsional dan cukup sedikit saja. Jadi, penggunaan tepungnya tetep harus lebih banyak ya, karena jika kebanyakan menggunakan susu bubuk maka sebentar saja Gulali Rambut Neneknya jadi lengket dan menyatu lagi. Karena itu, kalau mau lebih awet dan kesat teksturnya silahkan dilewatkan saja penggunaan susu bubuknya.
1. Penggunaan citric acid harus sesuai takaran ya, karena jika kebanyakan ya hasilnya gulali jadi susah mengeras. Tapi jika dilewatkan juga Gulalinya jadi cepat mengeras. Karena itu pastikan sesuai takaran.
1. Karena ini jenis Gulali rambut nenek yang basah, bukan yang kering.. Jadi cara menyimpannya setelah dibentuk silahkan ditempatkan dimulut kita ya, alias langsung dimakan hehe.. tapi kalau mau dimakan nanti-nanti silahkan ditempatkan di wadah tertutup. Jika ingin membuat Rambut nenek jenis kering maka untuk lumurannya itu adonannya menggunakan campuran tepung dan minyak, tapi juga ada takarannya ya, ada tips dan triknya juga.Kapan-kapan saya bagikan juga yang versi Kering ya.




Bagaimana? Mudah bukan? Itulah cara membuat gulali basah rambut nenek yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
