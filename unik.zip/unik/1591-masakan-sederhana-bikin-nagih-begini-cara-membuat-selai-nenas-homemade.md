---
description: "BIKIN NAGIH! Begini Cara Membuat Selai Nenas Homemade "
title: "BIKIN NAGIH! Begini Cara Membuat Selai Nenas Homemade "
slug: 1591-masakan-sederhana-bikin-nagih-begini-cara-membuat-selai-nenas-homemade
date: 2020-05-25T20:33:56.978Z
image: https://img-global.cpcdn.com/recipes/84ef3d66fb453570/751x532cq70/selai-nenas-homemade-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/84ef3d66fb453570/751x532cq70/selai-nenas-homemade-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/84ef3d66fb453570/751x532cq70/selai-nenas-homemade-foto-resep-utama.jpg
author: Johanna Ramos
ratingvalue: 4.6
reviewcount: 15
recipeingredient:
- "2 buah Nanas"
- "250 gr Gula Pasir manis sesuai selera"
- "2 sdm Mentega Blueband"
- "3 lembar Daun pandanskip"
- "5 cm Kayu Manis"
recipeinstructions:
- "Kupas dan cuci beraih buah nenas kemudian parut."
- "Masak nenas dalam wajan beserta daun pandan lalu masak sampai meletupan-letup lalu masukan gula pasir, kayu manis sambil terus diaduk."
- "Masak terus selai nanas sampai matang dan air mulai mengering masukkan mentega lalu aduk-aduk. Dan masak terus sampai airnya benar-benar habis (disini saya tidak terlalu kering)."
- "Jika sudah matang angkat lalu pindahkan ke wadah lain dan dinginkan. Agar selai nanasnya sempurna dan mudah untuk dibulatkan saat digunakan masukkan kedalam kulkas selama 1 jam. Selamat mencoba 🥰"
categories:
- Resep
tags:
- selai
- nenas
- homemade

katakunci: selai nenas homemade 
nutrition: 151 calories
recipecuisine: Indonesian
preptime: "PT15M"
cooktime: "PT39M"
recipeyield: "1"
recipecategory: Lunch

---


![Selai Nenas Homemade](https://img-global.cpcdn.com/recipes/84ef3d66fb453570/751x532cq70/selai-nenas-homemade-foto-resep-utama.jpg)

Anda sedang mencari ide resep selai nenas homemade yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Kalau salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal selai nenas homemade yang enak selayaknya mempunyai aroma dan cita rasa yang bisa memancing selera kita.



Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari selai nenas homemade, pertama dari jenis bahan, kedua pemilihan bahan segar sampai cara membuat dan menghidangkannya. Tidak usah pusing kalau ingin menyiapkan selai nenas homemade enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini dapat menjadi suguhan istimewa.


Berikut ini ada beberapa tips dan trik praktis untuk membuat selai nenas homemade yang siap dikreasikan. Anda bisa membuat Selai Nenas Homemade menggunakan 5 jenis bahan dan 4 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan untuk mengolah Selai Nenas Homemade:

1. Sediakan 2 buah Nanas
1. Gunakan 250 gr Gula Pasir (manis sesuai selera)
1. Gunakan 2 sdm Mentega Blueband
1. Ambil 3 lembar Daun pandan/skip
1. Ambil 5 cm Kayu Manis




##### Langkah-langkah meracik Selai Nenas Homemade:

1. Kupas dan cuci beraih buah nenas kemudian parut.
1. Masak nenas dalam wajan beserta daun pandan lalu masak sampai meletupan-letup lalu masukan gula pasir, kayu manis sambil terus diaduk.
1. Masak terus selai nanas sampai matang dan air mulai mengering masukkan mentega lalu aduk-aduk. Dan masak terus sampai airnya benar-benar habis (disini saya tidak terlalu kering).
1. Jika sudah matang angkat lalu pindahkan ke wadah lain dan dinginkan. Agar selai nanasnya sempurna dan mudah untuk dibulatkan saat digunakan masukkan kedalam kulkas selama 1 jam. - Selamat mencoba 🥰




Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Selai Nenas Homemade yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berbisnis kuliner. Selamat mencoba!
