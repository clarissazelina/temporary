---
description: "WAJIB DICOBA! Inilah Cara Membuat Banana Hotdog Spesial"
title: "WAJIB DICOBA! Inilah Cara Membuat Banana Hotdog Spesial"
slug: 1437-masakan-sederhana-wajib-dicoba-inilah-cara-membuat-banana-hotdog-spesial
date: 2020-09-28T18:06:54.977Z
image: https://img-global.cpcdn.com/recipes/2acd2dd80efc90a3/751x532cq70/banana-hotdog-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2acd2dd80efc90a3/751x532cq70/banana-hotdog-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2acd2dd80efc90a3/751x532cq70/banana-hotdog-foto-resep-utama.jpg
author: Russell Russell
ratingvalue: 4.2
reviewcount: 3
recipeingredient:
- "6 buah pisang kepok"
- "250 gr tepung panirroti"
- "5 sdm tepung terigu"
- "1 sdm tepung beras"
- "2 sdm gula pasir"
- "1/4 sdt garam"
- "100 ml air matang"
- "secukupnya minyak utk menggoreng"
- " toping"
- "secukupnya meses coklat"
- "secukupnya meses warna warni"
- "secukupnya sprinkle"
- " selai coklat Nutella"
- "secukupnya keju parut"
- " SKM putih"
recipeinstructions:
- "Pertama siapkan bahan-bahan, untuk toping selera ya (saya pakai sesuai yang ada dirumah untuk toping)"
- "Kemudian kupas pisang kepok dari kulitnya. selanjutnya siapkan dalam wadah tepung terigu, tepung beras, tambahkan gula pasir dan garam. tuang air sedikit-sedikit dulu sambi diaduk-aduk agar mendapatkan kekentalan yang sesuai"
- "Adonan tepung basah hasilnya tidak encer dan tidak terlalu kental tetapi cukup kental saja (tes rasa untuk manis selera bisa ditambahkan/dikurangi). kemudian masukkan satu persatu pisang kepok dalam adonan tepung, lalu gulingkan dalam tepung panir yang sudah disiapkan dalam wadah. balut pisang dengan tepung panir sampai pisang tertutup tepung panir secara merata."
- "Hasil pisang kepok yang sudah dicelup adonan tepung basah lalu tepung panir seperti ini dan ulangi sampai pisang kepok habis."
- "Kemudian siapkan papan, ambil pisang satu persatu untuk di buat sayatan ditengah pisang seperti dibelah dua tetapi jangan sampai putus."
- "Setelah pisang dibelah dua tanpa putus, oles bagian dalam dengan adonan tepung basah, kemudian taburi dengan sedikit tepung panir agar bagian dalam pisang nantinya tetap renyah dan kriuk.ulangi seperti itu hingga semua pisang terbelah dan simpan sebentar dalam freezer kurang lebih 15 menit agar tepung panir betul2 melekat."
- "Setelah 15 menit keluarkan dari freezer dan siapkan wajan dan minyak goreng, gunakan api sedang cenderung kecil agar tidak cepat gosong dan tunggu sampai panas, kemudian goreng pisang sampai berwarna kuning kecoklatan, cukup dibalik satu kali agar tidak banyak menyerap minyak."
- "Setelah matang, angkat dan tiriskan, kemudian letakkan dalam wadah yang sudah diberi tissue agar sisa minyak terserap dalam tissue. siapkan bahan-bahan topping nya (topping selera sesuai yang ada dirumah masing-masing ya bebas saja)"
- "Selanjutnya ambil pisang satu persatu, oles bagian dalam pisang dengan selai coklat (saya pakai Nutella), kemudian letakkan keju dari bagian dalam sampai penuh (selera ya banyaknya) lalu tambahkan meses coklat."
- "Terakhir taburi dengan sprinkle warna warni biar cantikk😍. ulangi dengan cara sama dan toping sesuka hati🤗 (saya ada yang di isi meses saja tabur sprinkle dan siram SKM putih) Banana Hotdog siap disajikan untuk keluarga tercinta 🤗"
categories:
- Resep
tags:
- banana
- hotdog

katakunci: banana hotdog 
nutrition: 185 calories
recipecuisine: Indonesian
preptime: "PT14M"
cooktime: "PT32M"
recipeyield: "3"
recipecategory: Lunch

---


![Banana Hotdog](https://img-global.cpcdn.com/recipes/2acd2dd80efc90a3/751x532cq70/banana-hotdog-foto-resep-utama.jpg)

Lagi mencari ide resep banana hotdog yang unik? Cara membuatnya memang tidak terlalu sulit namun tidak gampang juga. Jika salah mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal banana hotdog yang enak harusnya sih memiliki aroma dan cita rasa yang dapat memancing selera kita.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari banana hotdog, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika mau menyiapkan banana hotdog yang enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.




Nah, kali ini kita coba, yuk, buat banana hotdog sendiri di rumah. Tetap berbahan sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuh kita. Anda dapat menyiapkan Banana Hotdog menggunakan 15 bahan dan 10 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan untuk mengolah Banana Hotdog:

1. Ambil 6 buah pisang kepok
1. Ambil 250 gr tepung panir/roti
1. Ambil 5 sdm tepung terigu
1. Sediakan 1 sdm tepung beras
1. Ambil 2 sdm gula pasir
1. Siapkan 1/4 sdt garam
1. Sediakan 100 ml air matang
1. Gunakan secukupnya minyak utk menggoreng
1. Gunakan  toping
1. Siapkan secukupnya meses coklat
1. Gunakan secukupnya meses warna warni
1. Gunakan secukupnya sprinkle
1. Siapkan  selai coklat Nutella
1. Sediakan secukupnya keju parut
1. Siapkan  SKM putih




##### Langkah-langkah menyiapkan Banana Hotdog:

1. Pertama siapkan bahan-bahan, untuk toping selera ya (saya pakai sesuai yang ada dirumah untuk toping)
1. Kemudian kupas pisang kepok dari kulitnya. selanjutnya siapkan dalam wadah tepung terigu, tepung beras, tambahkan gula pasir dan garam. tuang air sedikit-sedikit dulu sambi diaduk-aduk agar mendapatkan kekentalan yang sesuai
1. Adonan tepung basah hasilnya tidak encer dan tidak terlalu kental tetapi cukup kental saja (tes rasa untuk manis selera bisa ditambahkan/dikurangi). kemudian masukkan satu persatu pisang kepok dalam adonan tepung, lalu gulingkan dalam tepung panir yang sudah disiapkan dalam wadah. balut pisang dengan tepung panir sampai pisang tertutup tepung panir secara merata.
1. Hasil pisang kepok yang sudah dicelup adonan tepung basah lalu tepung panir seperti ini dan ulangi sampai pisang kepok habis.
1. Kemudian siapkan papan, ambil pisang satu persatu untuk di buat sayatan ditengah pisang seperti dibelah dua tetapi jangan sampai putus.
1. Setelah pisang dibelah dua tanpa putus, oles bagian dalam dengan adonan tepung basah, kemudian taburi dengan sedikit tepung panir agar bagian dalam pisang nantinya tetap renyah dan kriuk.ulangi seperti itu hingga semua pisang terbelah dan simpan sebentar dalam freezer kurang lebih 15 menit agar tepung panir betul2 melekat.
1. Setelah 15 menit keluarkan dari freezer dan siapkan wajan dan minyak goreng, gunakan api sedang cenderung kecil agar tidak cepat gosong dan tunggu sampai panas, kemudian goreng pisang sampai berwarna kuning kecoklatan, cukup dibalik satu kali agar tidak banyak menyerap minyak.
1. Setelah matang, angkat dan tiriskan, kemudian letakkan dalam wadah yang sudah diberi tissue agar sisa minyak terserap dalam tissue. siapkan bahan-bahan topping nya (topping selera sesuai yang ada dirumah masing-masing ya bebas saja)
1. Selanjutnya ambil pisang satu persatu, oles bagian dalam pisang dengan selai coklat (saya pakai Nutella), kemudian letakkan keju dari bagian dalam sampai penuh (selera ya banyaknya) lalu tambahkan meses coklat.
1. Terakhir taburi dengan sprinkle warna warni biar cantikk😍. ulangi dengan cara sama dan toping sesuka hati🤗 (saya ada yang di isi meses saja tabur sprinkle dan siram SKM putih) Banana Hotdog siap disajikan untuk keluarga tercinta 🤗




Gimana nih? Mudah bukan? Itulah cara menyiapkan banana hotdog yang bisa Anda lakukan di rumah. Selamat mencoba!
