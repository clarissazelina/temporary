---
description: "BIKIN NAGIH! Ternyata Ini Resep Rahasia Gulali Rambut Nenek Pasti Berhasil"
title: "BIKIN NAGIH! Ternyata Ini Resep Rahasia Gulali Rambut Nenek Pasti Berhasil"
slug: 1195-masakan-sederhana-bikin-nagih-ternyata-ini-resep-rahasia-gulali-rambut-nenek-pasti-berhasil
date: 2020-09-05T03:19:09.463Z
image: https://img-global.cpcdn.com/recipes/44f3d254ff856b13/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/44f3d254ff856b13/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/44f3d254ff856b13/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg
author: Alma McCormick
ratingvalue: 4.7
reviewcount: 15
recipeingredient:
- "60 gr gula pasir"
- "20 ml air"
- "1 1/2 sdt asam cuka aku pake jeruk nipis aja biar aman"
- "30 gr glucose liquid"
- "secukupnya Pewarna makanan"
- " Tepung ketan yang udah disangrai"
recipeinstructions:
- "Masukkan semua bahan jadi satu kedalam teflon"
- "Masak dengan api kecil kurleb 8 menit"
- "Tips: cara cek udah mateng atau blm tes pake air dingin. Kalo masih susah ditarik gitu berarti belum siap."
- "Kalo udh siap, taruh di wajan anti lengket. Aduk2 hingga dingin."
- "Kemudian lapisi plastik wrap, Dan diamkan sebentar hingga benar2 dingin."
- "Setelah dingin bentuk menjadi seperti donat, dan baluri dengan tepung ketan yang telah disangrai. Lipat dua menyilang dan baluri dengan tepung ketan lagi. Ulangi terus hingga sesuai dengan tekstur yang diinginkan."
- "Siap disantap."
categories:
- Resep
tags:
- gulali
- rambut
- nenek

katakunci: gulali rambut nenek 
nutrition: 250 calories
recipecuisine: Indonesian
preptime: "PT31M"
cooktime: "PT48M"
recipeyield: "1"
recipecategory: Dessert

---


![Gulali Rambut Nenek](https://img-global.cpcdn.com/recipes/44f3d254ff856b13/751x532cq70/gulali-rambut-nenek-foto-resep-utama.jpg)

Lagi mencari inspirasi resep gulali rambut nenek yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika salah mengolah maka hasilnya tidak akan memuaskan dan bahkan tidak sedap. Padahal gulali rambut nenek yang enak selayaknya memiliki aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari gulali rambut nenek, mulai dari jenis bahan, lalu pemilihan bahan segar, sampai cara membuat dan menyajikannya. Tidak usah pusing kalau hendak menyiapkan gulali rambut nenek enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi suguhan istimewa.




Nah, kali ini kita coba, yuk, siapkan gulali rambut nenek sendiri di rumah. Tetap berbahan yang sederhana, sajian ini bisa memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat membuat Gulali Rambut Nenek memakai 6 jenis bahan dan 7 tahap pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Gulali Rambut Nenek:

1. Ambil 60 gr gula pasir
1. Siapkan 20 ml air
1. Siapkan 1 1/2 sdt asam cuka (aku pake jeruk nipis aja biar aman)
1. Gunakan 30 gr glucose liquid
1. Siapkan secukupnya Pewarna makanan
1. Gunakan  Tepung ketan yang udah disangrai




##### Cara menyiapkan Gulali Rambut Nenek:

1. Masukkan semua bahan jadi satu kedalam teflon
1. Masak dengan api kecil kurleb 8 menit
1. Tips: cara cek udah mateng atau blm tes pake air dingin. Kalo masih susah ditarik gitu berarti belum siap.
1. Kalo udh siap, taruh di wajan anti lengket. Aduk2 hingga dingin.
1. Kemudian lapisi plastik wrap, Dan diamkan sebentar hingga benar2 dingin.
1. Setelah dingin bentuk menjadi seperti donat, dan baluri dengan tepung ketan yang telah disangrai. Lipat dua menyilang dan baluri dengan tepung ketan lagi. Ulangi terus hingga sesuai dengan tekstur yang diinginkan.
1. Siap disantap.




Bagaimana? Mudah bukan? Itulah cara menyiapkan gulali rambut nenek yang bisa Anda lakukan di rumah. Semoga bermanfaat dan selamat mencoba!
