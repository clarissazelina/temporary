---
description: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Glotak khas Tegal Anti Gagal"
title: "WAJIB DICOBA! Ternyata Ini Resep Rahasia Glotak khas Tegal Anti Gagal"
slug: 1568-masakan-sederhana-wajib-dicoba-ternyata-ini-resep-rahasia-glotak-khas-tegal-anti-gagal
date: 2020-06-07T06:06:16.344Z
image: https://img-global.cpcdn.com/recipes/5afdb0fbe99c02e2/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5afdb0fbe99c02e2/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/5afdb0fbe99c02e2/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
author: Claudia Wells
ratingvalue: 3.6
reviewcount: 7
recipeingredient:
- " Bumbu Glotak "
- "1/4 tempe gembus bisa pakai tempe biasa"
- "2 lembar daun salam"
- "1 batang serai"
- "1 batang lengkuas"
- "3 tulang ayam"
- "10 ceker ayam"
- "8 buah cabai hijau"
- "3 siung bawang merah"
- "7 gelas air ukuran sedang gelas belimbing"
- " Bumbu merah "
- "8 cabai merah"
- "10 cabai rawit"
- "5 siung bawang merah"
- "4 siung bawang putih"
- "2 sdt garam"
- "1 1/2 sdt masako"
- "1 1/2 sdt gula"
- "1/2 sdt ketumbar"
recipeinstructions:
- "Bersihkan biji pada cabai"
- "Rebus gambus/tempe dan tiriskan"
- "Blender bahan bumbu merah : cabai merah, cabai rawit, bawang merah & putih, garam, masako, gula, ketumbar"
- "Blender gambus / tempe yang sudah direbus"
- "Bersih serta rebus tulang dan ceker ayam dengan air"
- "Untuk membuat bumbu glotak, iris bawang merah tipis, iris miring cabai hijau, geprek serai dan lengkuas"
- "Tumis bawang merah dengan sedikit minyak terlebih dahulu"
- "Masukkan bumbu glotak seperti daun salam, serai & lengkuas yang sudah digeprek, cabai hijau"
- "Masukkan bumbu merah yang sudah diblender sambil diaduk - aduk"
- "Masukkan tulang daging dan ceker ayam serta air rebusan ke bumbu glotak"
- "Masukkan gambus / tempe yang sudah diblender halus"
- "Aduk - aduk hingga bumbu merata dan tunggu hingga 1/2 air berkurang sehingga bumbu meresap ke tulang ayam & ceker"
- "Tes rasa"
- "Angkat dan sajikan"
- "Glotak siap dinikmati. Bisa dinikmati dengan cocolan kerupuk atau taburan pilus"
categories:
- Resep
tags:
- glotak
- khas
- tegal

katakunci: glotak khas tegal 
nutrition: 290 calories
recipecuisine: Indonesian
preptime: "PT23M"
cooktime: "PT60M"
recipeyield: "1"
recipecategory: Lunch

---


![Glotak khas Tegal](https://img-global.cpcdn.com/recipes/5afdb0fbe99c02e2/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg)

Sedang mencari ide resep glotak khas tegal yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal glotak khas tegal yang enak selayaknya mempunyai aroma dan rasa yang bisa memancing selera kita.

Glotak salah satu kuliner unik khas Tegal. Karena bunyinya \' glotak-glotak \' maka disebutlah si makanan tradisional ini dengan nama glotak xD Glotak, banyak ditemuin di pasar-pasar tradisional. Glotak adalah makanan khas tegal, dengan bahan dasar Gembus/Dage.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari glotak khas tegal, pertama dari jenis bahan, lalu pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan glotak khas tegal yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian spesial.


Nah, kali ini kita coba, yuk, kreasikan glotak khas tegal sendiri di rumah. Tetap dengan bahan yang sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Glotak khas Tegal memakai 19 bahan dan 15 tahap pembuatan. Berikut ini cara untuk menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam meracik Glotak khas Tegal:

1. Sediakan  Bumbu Glotak :
1. Ambil 1/4 tempe gembus (bisa pakai tempe biasa)
1. Ambil 2 lembar daun salam
1. Siapkan 1 batang serai
1. Siapkan 1 batang lengkuas
1. Siapkan 3 tulang ayam
1. Gunakan 10 ceker ayam
1. Ambil 8 buah cabai hijau
1. Siapkan 3 siung bawang merah
1. Ambil 7 gelas air ukuran sedang (gelas belimbing)
1. Siapkan  Bumbu merah :
1. Ambil 8 cabai merah
1. Gunakan 10 cabai rawit
1. Siapkan 5 siung bawang merah
1. Gunakan 4 siung bawang putih
1. Gunakan 2 sdt garam
1. Siapkan 1 1/2 sdt masako
1. Sediakan 1 1/2 sdt gula
1. Gunakan 1/2 sdt ketumbar


Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya. Proses pemasakan jajanan glotak ini menyebabkan tulang ayam bergesekan dengan panci, sehingga menimbulkan suara glotak-glotak, sehingga jajanan ini pun dikenal dengan. Ke Tegal jangan sampai melewatkan jajanan khas yang sudah dikenal ratusan tahun silam ini ya. Berikut ini adalah beberapa makanan khas Tegal yang sering diburu pecinta kuliner. 

##### Cara membuat Glotak khas Tegal:

1. Bersihkan biji pada cabai
1. Rebus gambus/tempe dan tiriskan
1. Blender bahan bumbu merah : cabai merah, cabai rawit, bawang merah & putih, garam, masako, gula, ketumbar
1. Blender gambus / tempe yang sudah direbus
1. Bersih serta rebus tulang dan ceker ayam dengan air
1. Untuk membuat bumbu glotak, iris bawang merah tipis, iris miring cabai hijau, geprek serai dan lengkuas
1. Tumis bawang merah dengan sedikit minyak terlebih dahulu
1. Masukkan bumbu glotak seperti daun salam, serai & lengkuas yang sudah digeprek, cabai hijau
1. Masukkan bumbu merah yang sudah diblender sambil diaduk - aduk
1. Masukkan tulang daging dan ceker ayam serta air rebusan ke bumbu glotak
1. Masukkan gambus / tempe yang sudah diblender halus
1. Aduk - aduk hingga bumbu merata dan tunggu hingga 1/2 air berkurang sehingga bumbu meresap ke tulang ayam & ceker
1. Tes rasa
1. Angkat dan sajikan
1. Glotak siap dinikmati. Bisa dinikmati dengan cocolan kerupuk atau taburan pilus


Anda bisa mendapatkan sate kambing khas Tegal dengan mudah di seluruh kota Tegal. Glotak pada umumnya terbuat dari gembus yang dimasak dengan berbagai bumbu. Ada banyak warung makan di Tegal yang menjual Nasi Lengko, sehingga kamu bisa mencarinya dengan mudah. Itulah sejumlah makanan khas Tegal yang patut kamu ketahui. Dari makanan-makanan di atas, kita pun jadi tahu kalau Tegal itu punya banyak makanan khas, dan bukan hanya sekadar. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Glotak khas Tegal yang mudah di atas dapat membantu Anda menyiapkan makanan yang menarik untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Semoga bermanfaat dan selamat mencoba!
