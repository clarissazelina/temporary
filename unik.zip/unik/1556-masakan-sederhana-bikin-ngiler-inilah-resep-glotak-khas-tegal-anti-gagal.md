---
description: "BIKIN NGILER! Inilah Resep Glotak khas Tegal Anti Gagal"
title: "BIKIN NGILER! Inilah Resep Glotak khas Tegal Anti Gagal"
slug: 1556-masakan-sederhana-bikin-ngiler-inilah-resep-glotak-khas-tegal-anti-gagal
date: 2020-06-27T01:00:37.822Z
image: https://img-global.cpcdn.com/recipes/ba0a7d38b28f3be5/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/ba0a7d38b28f3be5/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/ba0a7d38b28f3be5/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg
author: Alice Shelton
ratingvalue: 3.6
reviewcount: 9
recipeingredient:
- "3 papan gembus"
- " Tulang sapi  ayam"
- " Ceker ayam"
- "8 buah cabai hijau iris serong"
- "7 siung bawang merah iris tipis"
- "2 lembar daun salam"
- "1 batang sereh digeprek"
- "1 ruas laos digeprek"
- " Bumbu merah halus"
- "8 buah cabai merah"
- "8 buah cabai rawit"
- "4 siung bawang merah"
- "5 siung bawang putih"
- "1,5 sdt garam"
- "1 sdt kaldu bubuk"
- "1 sdt gula"
recipeinstructions:
- "Rebus tulang sapi/ayam sampai lunak. Haluskan gembus. Siapkan bumbu yg sudah diiris. Dan bumbu merah yang sudah dihaluskan."
- "Panaskan minyak dengan api kecil. Masukan irisan bawang merah setelah wangi kemudian masukan irisan cabai hijau, laos, serai, dan daun salam. Tambahkan air rebusan tulang tadi."
- "Masukan tulang sapi/ ayam dan ceker. Biarkan sebentar. Masukan gembus yang sudah dihaluskan tadi. Cek rasa. Tunggu sampai air menyusut. Matikan kompor."
- "Glotak siap dihidangkan bersama kerupuk lebih mantap. Cocok dimakan saat siang hari bersama segelas es teh."
- "Selamat mencoba... 😀🤗"
categories:
- Resep
tags:
- glotak
- khas
- tegal

katakunci: glotak khas tegal 
nutrition: 190 calories
recipecuisine: Indonesian
preptime: "PT32M"
cooktime: "PT53M"
recipeyield: "4"
recipecategory: Dinner

---


![Glotak khas Tegal](https://img-global.cpcdn.com/recipes/ba0a7d38b28f3be5/751x532cq70/glotak-khas-tegal-foto-resep-utama.jpg)

Sedang mencari inspirasi resep glotak khas tegal yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal glotak khas tegal yang enak seharusnya mempunyai aroma dan rasa yang mampu memancing selera kita.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari glotak khas tegal, pertama dari jenis bahan, kemudian pemilihan bahan segar, sampai cara mengolah dan menyajikannya. Tak perlu pusing jika ingin menyiapkan glotak khas tegal enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu menjadi suguhan istimewa.

Glotak salah satu kuliner unik khas Tegal. Karena bunyinya \' glotak-glotak \' maka disebutlah si makanan tradisional ini dengan nama glotak xD Glotak, banyak ditemuin di pasar-pasar tradisional. Glotak adalah makanan khas tegal, dengan bahan dasar Gembus/Dage.


Nah, kali ini kita coba, yuk, siapkan glotak khas tegal sendiri di rumah. Tetap berbahan yang sederhana, sajian ini dapat memberi manfaat dalam membantu menjaga kesehatan tubuhmu sekeluarga. Anda dapat menyiapkan Glotak khas Tegal memakai 16 bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam membuat Glotak khas Tegal:

1. Sediakan 3 papan gembus
1. Sediakan  Tulang sapi / ayam
1. Ambil  Ceker ayam
1. Sediakan 8 buah cabai hijau iris serong
1. Sediakan 7 siung bawang merah iris tipis
1. Ambil 2 lembar daun salam
1. Gunakan 1 batang sereh digeprek
1. Sediakan 1 ruas laos digeprek
1. Siapkan  Bumbu merah halus:
1. Sediakan 8 buah cabai merah
1. Sediakan 8 buah cabai rawit
1. Sediakan 4 siung bawang merah
1. Siapkan 5 siung bawang putih
1. Ambil 1,5 sdt garam
1. Ambil 1 sdt kaldu bubuk
1. Sediakan 1 sdt gula


Lihat juga resep Glotak Khas Tegal, Glotak enak lainnya. Proses pemasakan jajanan glotak ini menyebabkan tulang ayam bergesekan dengan panci, sehingga menimbulkan suara glotak-glotak, sehingga jajanan ini pun dikenal dengan. Ke Tegal jangan sampai melewatkan jajanan khas yang sudah dikenal ratusan tahun silam ini ya. Berikut ini adalah beberapa makanan khas Tegal yang sering diburu pecinta kuliner. 

##### Cara membuat Glotak khas Tegal:

1. Rebus tulang sapi/ayam sampai lunak. Haluskan gembus. Siapkan bumbu yg sudah diiris. Dan bumbu merah yang sudah dihaluskan.
1. Panaskan minyak dengan api kecil. Masukan irisan bawang merah setelah wangi kemudian masukan irisan cabai hijau, laos, serai, dan daun salam. Tambahkan air rebusan tulang tadi.
1. Masukan tulang sapi/ ayam dan ceker. Biarkan sebentar. Masukan gembus yang sudah dihaluskan tadi. Cek rasa. Tunggu sampai air menyusut. Matikan kompor.
1. Glotak siap dihidangkan bersama kerupuk lebih mantap. Cocok dimakan saat siang hari bersama segelas es teh.
1. Selamat mencoba... 😀🤗


Anda bisa mendapatkan sate kambing khas Tegal dengan mudah di seluruh kota Tegal. Glotak pada umumnya terbuat dari gembus yang dimasak dengan berbagai bumbu. Ada banyak warung makan di Tegal yang menjual Nasi Lengko, sehingga kamu bisa mencarinya dengan mudah. Itulah sejumlah makanan khas Tegal yang patut kamu ketahui. Dari makanan-makanan di atas, kita pun jadi tahu kalau Tegal itu punya banyak makanan khas, dan bukan hanya sekadar. 

Gimana nih? Mudah bukan? Itulah cara membuat glotak khas tegal yang bisa Anda lakukan di rumah. Selamat mencoba!
