---
description: "BIKIN NAGIH! Inilah Resep Rahasia Sagon Bakar "
title: "BIKIN NAGIH! Inilah Resep Rahasia Sagon Bakar "
slug: 1442-masakan-sederhana-bikin-nagih-inilah-resep-rahasia-sagon-bakar
date: 2020-07-01T23:18:51.608Z
image: https://img-global.cpcdn.com/recipes/2f51517a1f02084f/751x532cq70/sagon-bakar-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/2f51517a1f02084f/751x532cq70/sagon-bakar-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/2f51517a1f02084f/751x532cq70/sagon-bakar-foto-resep-utama.jpg
author: Gussie Tucker
ratingvalue: 4.4
reviewcount: 10
recipeingredient:
- "500 gr tepung sagukanji"
- "250 gr kelapa setengah tua parut"
- "200 gr gula haluspasir yg halus"
- "1/2 sdt garam"
- " Vanili"
recipeinstructions:
- "Sangrai tepung sagu sampai keliatan kering/ringan. Biarkan sebentar sampai dingin"
- "Campur semua bahan sampai rata."
- "Coba gumpal adonan, kalau tidak pecah berarti adonan siap dicetak. Klo masih pecah tambahkan susu kental atau santan"
- "Lalu cetak"
- "Panggang sampai mateng"
categories:
- Resep
tags:
- sagon
- bakar

katakunci: sagon bakar 
nutrition: 219 calories
recipecuisine: Indonesian
preptime: "PT21M"
cooktime: "PT36M"
recipeyield: "4"
recipecategory: Dessert

---


![Sagon Bakar](https://img-global.cpcdn.com/recipes/2f51517a1f02084f/751x532cq70/sagon-bakar-foto-resep-utama.jpg)

Lagi mencari inspirasi resep sagon bakar yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan bahkan tidak sedap. Padahal sagon bakar yang enak seharusnya punya aroma dan cita rasa yang bisa memancing selera kita.

Ada beberapa hal yang sedikit banyak mempengaruhi kualitas rasa dari sagon bakar, mulai dari jenis bahan, selanjutnya pemilihan bahan segar, hingga cara mengolah dan menghidangkannya. Tak perlu pusing jika hendak menyiapkan sagon bakar yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi sajian spesial.

Sagon Bakar Ciaul sangat dikenal karena mempunyai Cita rasa, Gurih, Renyah, dan Lakersnya (SANGAT BERBEDA DARI SAGON BIASANYA & Lainnya). Sagon Bakar \"CIAUL\" terbuat dari bahan-bahan yang berkualitas,sehingga kue yang kami Produksi ini memiliki keunggulan tekstur dan rasa dibandingkan dengan kue yang sejenisnya. Resep Kue Kering Sagon Kelapa Bakar Ketan Sederhana Spesial Renyah Gurih Asli Enak.


Berikut ini ada beberapa cara mudah dan praktis untuk membuat sagon bakar yang siap dikreasikan. Anda dapat membuat Sagon Bakar menggunakan 5 jenis bahan dan 5 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Sagon Bakar:

1. Ambil 500 gr tepung sagu/kanji
1. Siapkan 250 gr kelapa setengah tua (parut)
1. Siapkan 200 gr gula halus/pasir yg halus
1. Ambil 1/2 sdt garam
1. Gunakan  Vanili


Cari produk Makanan Instan Kaleng lainnya di Tokopedia. Sagon inggih punika salah satunggaling tetedhan tradhisional khas Jawa Tengah. Ing wekdal rumiyin, kathah tiyang ingkang remen damel sagon kanthi bahan-bahan ingkang prasaja tanpa bahan pengawèt. Онлайн видео TUTORIAL IBU IRMA SAGON BAKAR \'CARA MEMBUAT DODOL AGAR\' — смотреть на imperiya.by. Bar in Ho Chi Minh City, Vietnam. 

##### Langkah-langkah membuat Sagon Bakar:

1. Sangrai tepung sagu sampai keliatan kering/ringan. Biarkan sebentar sampai dingin
1. Campur semua bahan sampai rata.
1. Coba gumpal adonan, kalau tidak pecah berarti adonan siap dicetak. Klo masih pecah tambahkan susu kental atau santan
1. Lalu cetak
1. Panggang sampai mateng


Sagon bakar dan sagon serbuk yang menjadi makanan ringan pada zaman dahulu telah. Sagon bakar ini berbahan dasar kelapa parut ini menghasilkan rasa yang sangat gurih apalagi ditambah dengan kacang tanah yang juga memiliki rasa gurih. Selain mochi, sagon bakar adalah camilan khas Sukabumi lainnya. Sagon bakar terbuat dari kelapa, aci, dan bahan lainnya. Cocok banget jadi teman ngopi! owl:sameAs. dbpedia-id:Sagon_Bakar. 

Gimana nih? Gampang kan? Itulah cara membuat sagon bakar yang bisa Anda lakukan di rumah. Selamat mencoba!
