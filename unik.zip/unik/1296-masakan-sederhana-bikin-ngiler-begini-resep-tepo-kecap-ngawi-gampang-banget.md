---
description: "BIKIN NGILER! Begini Resep Tepo Kecap Ngawi Gampang Banget"
title: "BIKIN NGILER! Begini Resep Tepo Kecap Ngawi Gampang Banget"
slug: 1296-masakan-sederhana-bikin-ngiler-begini-resep-tepo-kecap-ngawi-gampang-banget
date: 2020-07-18T14:55:36.498Z
image: https://img-global.cpcdn.com/recipes/63c907c9a0a43d20/751x532cq70/tepo-kecap-ngawi-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/63c907c9a0a43d20/751x532cq70/tepo-kecap-ngawi-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/63c907c9a0a43d20/751x532cq70/tepo-kecap-ngawi-foto-resep-utama.jpg
author: Jean Barnett
ratingvalue: 3.4
reviewcount: 6
recipeingredient:
- " Bahan"
- "1 buah lontong gak ada tepo"
- "1 iris tahu"
- "1 iris tempe"
- "1 lembar kubis"
- "Sejumput cambah"
- "secukupnya Seledri"
- " Bumbu Halus"
- "1 buah bawang putih"
- "2 cabe menyesuaikan"
- "Sejimpit garam"
- "2 sdm Kacang tanah"
- "1 sdm gula bisa ditambah"
- "secukupnya Kecap"
recipeinstructions:
- "Potong lontong, taruh di piring"
- "Iris kubis tata di atas lontong"
- "Goreng tahu dan tempe lalu iris dan tarus di atas kubis"
- "Rebus kecambah atau bisa cukup disiram air panas, tiriskan, lalu taruh di atas tahu tempe"
- "Goreng bawang putih, cabe, dan kacang tanah"
- "Uleg bawang putih, cabe, dan garam. Lalu tambahkan gula dan air secukupnya"
- "Siramkan sambal di atas ke tatanan makanan tadi dan kucuri kecap"
- "Iris seledri lalu taburkan"
- "Bisa ditambah kuah yg terdiri dr air mendidih, gula merah, salam dan laos. Bila tidak suka, begitu saja sudah enak. Bisa ditaburi bawang merah goreng."
categories:
- Resep
tags:
- tepo
- kecap
- ngawi

katakunci: tepo kecap ngawi 
nutrition: 287 calories
recipecuisine: Indonesian
preptime: "PT30M"
cooktime: "PT32M"
recipeyield: "4"
recipecategory: Dessert

---


![Tepo Kecap Ngawi](https://img-global.cpcdn.com/recipes/63c907c9a0a43d20/751x532cq70/tepo-kecap-ngawi-foto-resep-utama.jpg)

Lagi mencari ide resep tepo kecap ngawi yang unik? Cara membuatnya memang tidak susah dan tidak juga mudah. Jika keliru mengolah maka hasilnya akan hambar dan justru cenderung tidak enak. Padahal tepo kecap ngawi yang enak seharusnya punya aroma dan rasa yang mampu memancing selera kita.

Jangan lupa Subscribe, like, dan komen karena gratis:) Upload setiap hari Rabu dan Minggu. ID - Ngawi memiliki kuliner khas bernama tepo kecap. Olahan yang terdiri dari tahu, tempe, serta lontong ini paling enak dinikmati sebagai santapan di malam hari.

Banyak hal yang sedikit banyak mempengaruhi kualitas rasa dari tepo kecap ngawi, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tidak usah pusing jika hendak menyiapkan tepo kecap ngawi enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini mampu jadi sajian spesial.


Berikut ini ada beberapa tips dan trik praktis yang dapat diterapkan untuk mengolah tepo kecap ngawi yang siap dikreasikan. Anda bisa membuat Tepo Kecap Ngawi menggunakan 14 bahan dan 9 langkah pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang digunakan dalam membuat Tepo Kecap Ngawi:

1. Sediakan  Bahan:
1. Siapkan 1 buah lontong (gak ada tepo)
1. Sediakan 1 iris tahu
1. Gunakan 1 iris tempe
1. Sediakan 1 lembar kubis
1. Ambil Sejumput cambah
1. Sediakan secukupnya Seledri
1. Ambil  Bumbu Halus:
1. Ambil 1 buah bawang putih
1. Gunakan 2 cabe (menyesuaikan)
1. Siapkan Sejimpit garam
1. Sediakan 2 sdm Kacang tanah
1. Sediakan 1 sdm gula (bisa ditambah)
1. Ambil secukupnya Kecap


Kuahnya menggunakan campuran kecap, air asam, dan bumbu halus lainnya. Wisata Kuliner enak dan Populer di Ngawi - Anda pasti tahu kota Ngawi, Kota Ngawi terletak di Propinsi Jawa Timur bagian barat berbatasan dengan Propinsi Jawa Tengah. Tahu tepo merupakan salah satu kuliner khas Ngawi yang wajib dicoba ketika berkunjung. Nah, makanan yang satu ini sudah jadi legend di Ngawi. 

##### Cara membuat Tepo Kecap Ngawi:

1. Potong lontong, taruh di piring
1. Iris kubis tata di atas lontong
1. Goreng tahu dan tempe lalu iris dan tarus di atas kubis
1. Rebus kecambah atau bisa cukup disiram air panas, tiriskan, lalu taruh di atas tahu tempe
1. Goreng bawang putih, cabe, dan kacang tanah
1. Uleg bawang putih, cabe, dan garam. Lalu tambahkan gula dan air secukupnya
1. Siramkan sambal di atas ke tatanan makanan tadi dan kucuri kecap
1. Iris seledri lalu taburkan
1. Bisa ditambah kuah yg terdiri dr air mendidih, gula merah, salam dan laos. Bila tidak suka, begitu saja sudah enak. Bisa ditaburi bawang merah goreng.


Sate Ngawi tidak menggunakan banyak kecap untuk bumbunya. Jadi, rasanya pun tidak akan terlalu manis. Lalu wisata Ngawi apa saja yang wajib kamu kunjungi? Kuliner khas Ngawi yang pertama adalah Nasi Pecel ini. Makanan tradisional khas ini memiliki rasa yang gurih dan juga lezat. 

Terima kasih telah menggunakan resep yang kami tampilkan di sini. Besar harapan kami, olahan Tepo Kecap Ngawi yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman maupun menjadi inspirasi dalam berbisnis kuliner. Selamat mencoba!
