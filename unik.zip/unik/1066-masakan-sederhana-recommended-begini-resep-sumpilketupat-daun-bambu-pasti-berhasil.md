---
description: "RECOMMENDED! Begini Resep Sumpil(ketupat daun bambu) Pasti Berhasil"
title: "RECOMMENDED! Begini Resep Sumpil(ketupat daun bambu) Pasti Berhasil"
slug: 1066-masakan-sederhana-recommended-begini-resep-sumpilketupat-daun-bambu-pasti-berhasil
date: 2020-04-23T14:53:36.336Z
image: https://img-global.cpcdn.com/recipes/9f373a1ff6ccb395/751x532cq70/sumpilketupat-daun-bambu-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/9f373a1ff6ccb395/751x532cq70/sumpilketupat-daun-bambu-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/9f373a1ff6ccb395/751x532cq70/sumpilketupat-daun-bambu-foto-resep-utama.jpg
author: Theresa Erickson
ratingvalue: 4.8
reviewcount: 9
recipeingredient:
- "  30 lembar Daun bambu dgn bentuk lebarpanjang"
- "Secukupnya Air untuk merebus sumpil"
- "1/2 kg beras cuci bersih tiriskan"
- "Secukupnya lidi untuk menyemat"
recipeinstructions:
- "Siapkan beras yg sudah di cuci dan tiriskan,bersihkan daun bambu dengan kain lap,lalu gunting ujung dan pangkal daunnya"
- "Cara membungkusnya :Ambil selembar daun bambu yg sudah di bersihkan bentuk contong di bagian ujungnya isi dengan beras ±1 sdm (tergantung besar kecil daun bambunya),lipat kesamping gulung2 bentuk segitiga sampai pangkal daun lalu semat dengan lidi,usahakan jangan ada bagian yg sobek atau bocor ya moms,saya jadi ±40 Bks karena daun nya krg lebar..hihi"
- "Langkah terahir adalah merebusnya,saya merebus dengan panci presto ± 90 menit,saat merebus Sumpil dalam keadaan terendam air semua agar matang merata"
- "Selamat menikmati dengan menu2 kesukaan..khas lebaran..."
categories:
- Resep
tags:
- sumpilketupat
- daun
- bambu

katakunci: sumpilketupat daun bambu 
nutrition: 273 calories
recipecuisine: Indonesian
preptime: "PT17M"
cooktime: "PT45M"
recipeyield: "4"
recipecategory: Lunch

---


![Sumpil(ketupat daun bambu)](https://img-global.cpcdn.com/recipes/9f373a1ff6ccb395/751x532cq70/sumpilketupat-daun-bambu-foto-resep-utama.jpg)

Sedang mencari inspirasi resep sumpil(ketupat daun bambu) yang unik? Cara menyiapkannya memang tidak susah dan tidak juga mudah. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal sumpil(ketupat daun bambu) yang enak seharusnya punya aroma dan cita rasa yang dapat memancing selera kita.

Ketupat sumpil adalah salah satu masakan khas Indonesia, terutama di daerah Jawa Tengah. Ketupat sumpil sering kali dikenal sebagai makanan khas Kaliwungu, Kabupaten Kendal. Meskipun demikian makanan ini juga dikenal sebagai makanan khas dari Kabupaten Temanggung Oleh karena.

Ada beberapa hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari sumpil(ketupat daun bambu), pertama dari jenis bahan, kedua pemilihan bahan segar hingga cara membuat dan menyajikannya. Tak perlu pusing jika mau menyiapkan sumpil(ketupat daun bambu) enak di mana pun anda berada, karena asal sudah tahu triknya maka hidangan ini bisa menjadi sajian istimewa.


Nah, kali ini kita coba, yuk, buat sumpil(ketupat daun bambu) sendiri di rumah. Tetap dengan bahan sederhana, sajian ini dapat memberi manfaat untuk membantu menjaga kesehatan tubuhmu sekeluarga. Anda bisa membuat Sumpil(ketupat daun bambu) memakai 4 jenis bahan dan 4 langkah pembuatan. Berikut ini langkah-langkah dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang dibutuhkan dalam membuat Sumpil(ketupat daun bambu):

1. Sediakan  ± 30 lembar Daun bambu dgn bentuk lebar&panjang
1. Sediakan Secukupnya Air untuk merebus sumpil
1. Sediakan 1/2 kg beras cuci bersih tiriskan
1. Ambil Secukupnya lidi untuk menyemat


Untuk menikmati sate sumpil Anda dapat melakukan order sate sumpil melalui : Melalui Aplikasi GrabFoo. Kalau tadi batangnya, sekarang giliran daun bambu yang digunakan sebagai pembungkus makanan. Salah satu makanan khas Indonesia yang dibungkus daun bambu adalah ketupat sumpil khas Kaliwungu, Kendal, Jawa Tengah. Cara Membuat Ketupat Tahan Lama Dan Tidak Mudah Basi. 

##### Langkah-langkah meracik Sumpil(ketupat daun bambu):

1. Siapkan beras yg sudah di cuci dan tiriskan,bersihkan daun bambu dengan kain lap,lalu gunting ujung dan pangkal daunnya
1. Cara membungkusnya :Ambil selembar daun bambu yg sudah di bersihkan bentuk contong di bagian ujungnya isi dengan beras ±1 sdm (tergantung besar kecil daun bambunya),lipat kesamping gulung2 bentuk segitiga sampai pangkal daun lalu semat dengan lidi,usahakan jangan ada bagian yg sobek atau bocor ya moms,saya jadi ±40 Bks karena daun nya krg lebar..hihi
1. Langkah terahir adalah merebusnya,saya merebus dengan panci presto ± 90 menit,saat merebus Sumpil dalam keadaan terendam air semua agar matang merata
1. Selamat menikmati dengan menu2 kesukaan..khas lebaran...


Resep Kue Cucur Enak Lembut Dan Bersarang Anti Gagal. Sumpil adalah makanan tradisional yang terbuat dari nasi dan dibungkus berbentuk segitiga menggunakan daun bambu, mirip dengan ketupat. Nah, sumpil ini biasanya dimakan oleh warga Kaliwungu dicampur dengan sambal kelapa. Tapi saat ini makanan yang dihidangkan nggak hanya. Daun bambu, untuk bungkus ketupat sumpil. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Besar harapan kami, olahan Sumpil(ketupat daun bambu) yang mudah di atas dapat membantu Anda menyiapkan makanan yang lezat untuk keluarga/teman ataupun menjadi ide bagi Anda yang berkeinginan untuk berbisnis kuliner. Semoga bermanfaat dan selamat mencoba!
