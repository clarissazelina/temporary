---
description: "BIKIN NAGIH! Inilah Resep Rahasia Pentol pedas mercon Anti Gagal"
title: "BIKIN NAGIH! Inilah Resep Rahasia Pentol pedas mercon Anti Gagal"
slug: 1812-masakan-sederhana-bikin-nagih-inilah-resep-rahasia-pentol-pedas-mercon-anti-gagal
date: 2020-04-18T21:43:48.146Z
image: https://img-global.cpcdn.com/recipes/a895fffb3c48fa5c/751x532cq70/pentol-pedas-mercon-foto-resep-utama.jpg
thumbnail: https://img-global.cpcdn.com/recipes/a895fffb3c48fa5c/751x532cq70/pentol-pedas-mercon-foto-resep-utama.jpg
cover: https://img-global.cpcdn.com/recipes/a895fffb3c48fa5c/751x532cq70/pentol-pedas-mercon-foto-resep-utama.jpg
author: Wesley Bishop
ratingvalue: 4.5
reviewcount: 8
recipeingredient:
- "30 biji pentol"
- "30 biji cabe rebus"
- "5 biji bawang putih uleg"
- "5 lembar daun jeruk disobek2 ya"
- "1/2 sdt garam"
- "1 sdt gula"
- "1/2 lada bubuk"
- " Roycomicin"
- " Air"
recipeinstructions:
- "Pertama rebus cabe cabean(biar pedes banged n tekstur warnanya cantik)setelah direbus blender kasar cabe."
- "Uleg bawang putih,kemudian siapkan wajan beri minyak sedikit untuk menumis.tumis bawang putih yang d uleg tadi setelah aroma harum masukan cabe yg d blender tadi dan masukan daun jeruk yg di sobek2."
- "Beri lada gula garam micib royco,kemudian tambahkan air.setelah harum masukan pentol lalu aduk tes rasa. SAJIKAN ❣️"
categories:
- Resep
tags:
- pentol
- pedas
- mercon

katakunci: pentol pedas mercon 
nutrition: 275 calories
recipecuisine: Indonesian
preptime: "PT11M"
cooktime: "PT30M"
recipeyield: "3"
recipecategory: Dinner

---


![Pentol pedas mercon](https://img-global.cpcdn.com/recipes/a895fffb3c48fa5c/751x532cq70/pentol-pedas-mercon-foto-resep-utama.jpg)

Sedang mencari inspirasi resep pentol pedas mercon yang unik? Cara menyiapkannya memang susah-susah gampang. Kalau keliru mengolah maka hasilnya tidak akan memuaskan dan justru cenderung tidak enak. Padahal pentol pedas mercon yang enak seharusnya memiliki aroma dan cita rasa yang bisa memancing selera kita.

Tutorial cara membuat pentol pedas mercon homemade Editing by @riqbishaa_ Jangan lupa like , comment and subscribe !!! follow instagram. Penggemar pedas ni wajib banget nyobain buat pentol pedas level bunuh diri ni gais. Bantu dukung Channel ini dengan klik tombol.

Banyak hal yang sedikit banyak berpengaruh terhadap kualitas rasa dari pentol pedas mercon, mulai dari jenis bahan, lalu pemilihan bahan segar sampai cara mengolah dan menghidangkannya. Tak perlu pusing jika mau menyiapkan pentol pedas mercon yang enak di rumah, karena asal sudah tahu triknya maka hidangan ini bisa jadi suguhan spesial.


Di bawah ini ada beberapa cara mudah dan praktis untuk membuat pentol pedas mercon yang siap dikreasikan. Anda bisa menyiapkan Pentol pedas mercon menggunakan 9 bahan dan 3 tahap pembuatan. Berikut ini cara dalam menyiapkan hidangannya.

##### Bahan-bahan dan bumbu yang diperlukan dalam meracik Pentol pedas mercon:

1. Siapkan 30 biji pentol
1. Gunakan 30 biji cabe (rebus)
1. Sediakan 5 biji bawang putih (uleg)
1. Gunakan 5 lembar daun jeruk (disobek2 ya)
1. Sediakan 1/2 sdt garam
1. Ambil 1 sdt gula
1. Ambil 1/2 lada bubuk
1. Ambil  Royco,micin
1. Siapkan  Air


Our technical engineering, chemical production and development is based in Germany while our service teams are working world. Lihat juga resep Pentol sapi lowcarb,Cocok untuk diet keto/debm enak lainnya! Pentol mercon pedasnya meledak ledak dımulut l ındonesıa street food. The Legend of Pentol Mercon menawarkan menu pentol dgn aneka saus seperti saus tomat, blackpaper, barbeque, saus kacang & sambal super pedas. 

##### Langkah-langkah mengolah Pentol pedas mercon:

1. Pertama rebus cabe cabean(biar pedes banged n tekstur warnanya cantik)setelah direbus blender kasar cabe.
1. Uleg bawang putih,kemudian siapkan wajan beri minyak sedikit untuk menumis.tumis bawang putih yang d uleg tadi setelah aroma harum masukan cabe yg d blender tadi dan masukan daun jeruk yg di sobek2.
1. Beri lada gula garam micib royco,kemudian tambahkan air.setelah harum masukan pentol lalu aduk tes rasa. SAJIKAN ❣️


Nah, salah satu jajanan kaki lima yang lagi kekinian adalah pentol mercon. Jajanan bulat abang-abang gerobak dengan bumbu super pedas ini memang paling dicari kalangan anak muda. Tekstur pentol yang kenyal dan ditambah dengan rasa bumbu mercon yang super pedas membuat Resep Bakso Pentol Mercon. TRIBUNNEWS,COM - Berikut ini resep dan cara membuat bakso cilok atau pentol mercon yang mudah dan anti gagal. Masakan ini bisa dilakukan di rumah dengan bahan dan alat sederhana. 

Terima kasih telah membaca resep yang kami tampilkan di halaman ini. Harapan kami, olahan Pentol pedas mercon yang mudah di atas dapat membantu Anda menyiapkan makanan yang enak untuk keluarga/teman ataupun menjadi ide untuk berjualan makanan. Selamat mencoba!
